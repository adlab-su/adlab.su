// Manifest V3 Service Worker
import { storage } from './js/storage.js';
import { isInternalOrNewTabUrl } from './js/utils.js';

// Setup Context Menus with mutex locking to prevent duplicate id race conditions
let isUpdatingMenus = false;
let pendingMenuUpdate = false;

async function updateContextMenus() {
  if (typeof chrome === 'undefined' || !chrome.contextMenus) return;
  if (isUpdatingMenus) {
    pendingMenuUpdate = true;
    return;
  }
  isUpdatingMenus = true;
  pendingMenuUpdate = false;

  try {
    // 1. Remove all existing menus cleanly
    await new Promise((resolve) => {
      chrome.contextMenus.removeAll(() => {
        if (chrome.runtime.lastError) {
          const _ = chrome.runtime.lastError; // Explicitly consume to prevent unchecked error
        }
        resolve();
      });
    });

    // 2. Fetch fresh state
    const state = await storage.getState();

    // 3. Create root context menu item
    const rootMenuTitle = (chrome.i18n && chrome.i18n.getMessage('contextMenuAddPage'))
      || (state.settings?.language === 'en' ? 'Add page to Tablo Tab' : 'Добавить страницу в Tablo Tab');

    await new Promise((resolve) => {
      chrome.contextMenus.create({
        id: 'sd_add_page',
        title: rootMenuTitle,
        contexts: ['page', 'link']
      }, () => {
        if (chrome.runtime.lastError) {
          const _ = chrome.runtime.lastError;
        }
        resolve();
      });
    });

    // 4. Create child menu items for desktops sequentially
    if (state.folders && state.folders.ids) {
      for (const fId of state.folders.ids) {
        const folder = state.folders.byId[fId];
        if (folder) {
          await new Promise((resolve) => {
            chrome.contextMenus.create({
              id: `sd_add_to_${fId}`,
              parentId: 'sd_add_page',
              title: folder.name,
              contexts: ['page', 'link']
            }, () => {
              if (chrome.runtime.lastError) {
                const _ = chrome.runtime.lastError;
              }
              resolve();
            });
          });
        }
      }
    }
  } catch (err) {
    // Suppress context menu creation errors
  } finally {
    isUpdatingMenus = false;
    if (pendingMenuUpdate) {
      updateContextMenus();
    }
  }
}

// Handle Context Menu clicks
if (chrome.contextMenus && chrome.contextMenus.onClicked) {
  chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    const targetUrl = info.linkUrl || info.pageUrl || tab?.url;
    const targetTitle = tab?.title || targetUrl;
    if (!targetUrl || isInternalOrNewTabUrl(targetUrl)) {
      if (chrome.action && chrome.action.setBadgeText) {
        chrome.action.setBadgeText({ text: '✕' });
        chrome.action.setBadgeBackgroundColor({ color: '#e81123' });
        setTimeout(() => chrome.action.setBadgeText({ text: '' }), 2000);
      }
      return;
    }

    const state = await storage.getState();
    let targetFolderId = state.activeFolderId;

    if (info.menuItemId.startsWith('sd_add_to_')) {
      targetFolderId = info.menuItemId.replace('sd_add_to_', '');
    }

    await storage.addDial({
      folderId: targetFolderId,
      name: targetTitle,
      url: targetUrl,
      faviconUrl: tab?.favIconUrl || ''
    });

    // Notify user via badge
    if (chrome.action && chrome.action.setBadgeText) {
      chrome.action.setBadgeText({ text: '✓' });
      chrome.action.setBadgeBackgroundColor({ color: '#27ae60' });
      setTimeout(() => chrome.action.setBadgeText({ text: '' }), 2000);
    }
  });
}

// Listen to storage changes to keep context menus fresh
storage.onStateChange(() => {
  updateContextMenus();
});

// Runtime message listener
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'captureTab' || request.action === 'captureWindowTab') {
    const winId = request.windowId || null;
    const doCapture = (attempts = 0) => {
      chrome.tabs.captureVisibleTab(winId, { format: 'jpeg', quality: 88 }, (dataUrl) => {
        if (chrome.runtime.lastError || !dataUrl) {
          const err = chrome.runtime.lastError ? chrome.runtime.lastError.message : 'No dataUrl returned';
          if (attempts < 2) {
            setTimeout(() => doCapture(attempts + 1), 350);
          } else {
            console.warn('captureVisibleTab error:', err);
            sendResponse({ error: err, dataUrl: null });
          }
        } else {
          sendResponse({ dataUrl });
        }
      });
    };
    doCapture();
    return true; // async response
  }

  if (request.action === 'openBatchTabs') {
    const urls = request.urls || [];
    const inNewWindow = request.inNewWindow || false;

    if (inNewWindow) {
      chrome.windows.create({ url: urls[0] }, (win) => {
        for (let i = 1; i < urls.length; i++) {
          chrome.tabs.create({ windowId: win.id, url: urls[i], active: false });
        }
      });
    } else {
      urls.forEach(url => chrome.tabs.create({ url, active: false }));
    }
    sendResponse({ success: true });
    return true;
  }
});

// Extension install/startup
chrome.runtime.onInstalled.addListener(async () => {
  await storage.init();
  updateContextMenus();
});

chrome.runtime.onStartup.addListener(async () => {
  await storage.init();
  updateContextMenus();
});
