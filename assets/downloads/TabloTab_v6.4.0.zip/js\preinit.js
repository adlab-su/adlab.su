// Speed Dial Pre-initialization
// Executes synchronously in <head> before page paint to prevent layout shifts or flicker
try {
  if (localStorage.getItem('sd_pref_hide_search') === '1') {
    document.documentElement.classList.add('hide-searchbar-initial');
  }
} catch (e) {}
