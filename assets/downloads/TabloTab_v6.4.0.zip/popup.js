// Speed Dial Action Popup Logic
import { storage } from './js/storage.js';
import { getFaviconUrl, getContrastTextColor, sanitizeUrl, extractDomain, resizeScreenshot, getLetterBadgeInfo, checkFaviconValid, isKnownBadFavicon, isKnownValidFavicon, markBadFavicon, isInternalOrNewTabUrl, resolveTheme, downloadJsonFile, getBrandColorForUrl, extractDominantColorFromImage } from './js/utils.js';
import { t, initI18n, applyI18n, getLanguage } from './js/i18n.js';

let currentTab = null;
let currentBgColor = '#2d2d2d';
let currentTileType = 'screenshot'; // 'screenshot' or 'logo'
let currentScreenshot = '';
let currentFavicon = '';
let isSpeedDialTab = false;

document.addEventListener('DOMContentLoaded', async () => {
  const state = await storage.getState();

  initI18n(state.settings?.language || 'auto');
  applyI18n();

  // Apply Theme and Style to Popup
  const applyPopupTheme = () => {
    const resolved = resolveTheme(state.settings?.theme || 'system');
    document.documentElement.setAttribute('data-theme', resolved);
  };
  const applyPopupStyle = () => {
    const styleSetting = state.settings?.style || 'w11';
    document.documentElement.setAttribute('data-style', styleSetting);
  };
  applyPopupTheme();
  applyPopupStyle();

  if (typeof window !== 'undefined' && window.matchMedia) {
    window.matchMedia('(prefers-color-scheme: light)').addEventListener('change', () => {
      storage.getState().then(st => {
        if ((st.settings?.theme || 'system') === 'system') {
          applyPopupTheme();
        }
      });
    });
  }
  
  // Elements
  const speedDialHub = document.getElementById('speedDialHub');
  const hubActiveDesktopBadge = document.getElementById('hubActiveDesktopBadge');
  const hubDesktopsList = document.getElementById('hubDesktopsList');
  const hubBtnAddDial = document.getElementById('hubBtnAddDial');
  const hubBtnBackup = document.getElementById('hubBtnBackup');
  const hubBtnOpenAllSettings = document.getElementById('hubBtnOpenAllSettings');

  const previewSection = document.getElementById('previewSection');
  const formBody = document.getElementById('formBody');
  const urlValidationMsg = document.getElementById('urlValidationMsg');
  const inputFolder = document.getElementById('inputFolder');
  const inputTitle = document.getElementById('inputTitle');
  const inputUrl = document.getElementById('inputUrl');
  const previewThumbArea = document.getElementById('previewThumbArea');
  const previewScreenshot = document.getElementById('previewScreenshot');
  const previewLogoWrap = document.getElementById('previewLogoWrap');
  const previewFavicon = document.getElementById('previewFavicon');
  const previewFooterFavicon = document.getElementById('previewFooterFavicon');
  const previewName = document.getElementById('previewName');
  const previewDomain = document.getElementById('previewDomain');
  const colorPalette = document.getElementById('colorPalette');
  const colorPaletteGroup = document.getElementById('colorPaletteGroup');
  const inputCustomColor = document.getElementById('inputCustomColor');
  const btnSaveDial = document.getElementById('btnSaveDial');
  const btnOpenNewTab = document.getElementById('btnOpenNewTab');
  const btnQuickAddFolder = document.getElementById('btnQuickAddFolder');
  const newFolderModal = document.getElementById('newFolderModal');
  const newFolderName = document.getElementById('newFolderName');
  const btnCancelNewFolder = document.getElementById('btnCancelNewFolder');
  const btnConfirmNewFolder = document.getElementById('btnConfirmNewFolder');

  const bookmarkingFormSection = document.getElementById('bookmarkingFormSection');

  function showSpeedDialHub() {
    isSpeedDialTab = true;
    speedDialHub?.classList.remove('hidden');
    if (speedDialHub) speedDialHub.style.display = 'flex';
    bookmarkingFormSection?.classList.add('hidden');
    if (bookmarkingFormSection) bookmarkingFormSection.style.display = 'none';
  }

  function showBookmarkingForm() {
    isSpeedDialTab = false;
    speedDialHub?.classList.add('hidden');
    if (speedDialHub) speedDialHub.style.display = 'none';
    bookmarkingFormSection?.classList.remove('hidden');
    if (bookmarkingFormSection) bookmarkingFormSection.style.display = 'block';
  }

  function isSpeedDialPage(tab) {
    if (!tab) return true;
    const url = (tab.url || '').toLowerCase().trim();
    const title = (tab.title || '').toLowerCase().trim();
    if (!url || url === 'about:blank') return true;
    if (url.startsWith('chrome://newtab') || url.startsWith('chrome-extension://') || url.includes('newtab.html')) return true;
    if (url.startsWith('edge://newtab') || url.startsWith('thorium://newtab')) return true;
    if (isInternalOrNewTabUrl(url)) return true;
    if (title === 'новая вкладка' || title === 'новая страница' || title === 'экспресс-панель' || title.includes('speed dial') || title.includes('tablo tab')) return true;
    return false;
  }

  // Render Speed Dial Control Hub (When on Speed Dial newtab page)
  async function renderSpeedDialHub() {
    showSpeedDialHub();
    const currentState = await storage.getState();

    // Active Desktop Status
    const activeFolder = currentState.folders.byId[currentState.activeFolderId];
    const count = activeFolder ? (activeFolder.dialIds || []).length : 0;
    const dialWord = getLanguage() === 'ru'
      ? ((count === 1) ? 'закладка' : ((count >= 2 && count <= 4) ? 'закладки' : 'закладок'))
      : ((count === 1) ? 'tile' : 'tiles');
    if (hubActiveDesktopBadge) {
      const defaultDeskName = getLanguage() === 'ru' ? 'Стол' : 'Desktop';
      hubActiveDesktopBadge.textContent = `${activeFolder?.name || defaultDeskName} · ${count} ${dialWord}`;
    }

    // Desktop Buttons
    if (hubDesktopsList) {
      hubDesktopsList.innerHTML = '';
      currentState.folders.ids.forEach(fId => {
        const folder = currentState.folders.byId[fId];
        if (!folder) return;
        const pill = document.createElement('button');
        pill.type = 'button';
        pill.className = `hub-desktop-pill ${fId === currentState.activeFolderId ? 'active' : ''}`;
        pill.textContent = folder.name;
        pill.addEventListener('click', async () => {
          await storage.setActiveFolderId(fId);
          state.activeFolderId = fId;
          renderSpeedDialHub();
          chrome.runtime.sendMessage({ action: 'switchDesktop', folderId: fId });
        });
        hubDesktopsList.appendChild(pill);
      });

      const addBtn = document.createElement('button');
      addBtn.type = 'button';
      addBtn.className = 'hub-desktop-add-btn';
      addBtn.title = t('btnNewDesktopTitle');
      addBtn.textContent = '+';
      addBtn.addEventListener('click', () => {
        newFolderModal?.classList.remove('hidden');
        newFolderName.value = '';
        newFolderName?.focus();
      });
      hubDesktopsList.appendChild(addBtn);
    }

    // Appearance: Theme Toggles
    const currentTheme = currentState.settings?.theme || 'system';
    document.querySelectorAll('#hubThemeControl .segment-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.theme === currentTheme);
      btn.onclick = async () => {
        document.querySelectorAll('#hubThemeControl .segment-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const theme = btn.dataset.theme;
        await storage.updateSettings({ theme });
        state.settings.theme = theme;
        applyPopupTheme();
        chrome.runtime.sendMessage({ action: 'themeChanged', theme });
      };
    });

    // Appearance: Style Toggles (Windows 11 vs Windows 10)
    const currentStyle = currentState.settings?.style || 'w11';
    document.querySelectorAll('#hubStyleControl .segment-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.style === currentStyle);
      btn.onclick = async () => {
        document.querySelectorAll('#hubStyleControl .segment-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const style = btn.dataset.style;
        await storage.updateSettings({ style });
        state.settings.style = style;
        applyPopupStyle();
        chrome.runtime.sendMessage({ action: 'styleChanged', style });
      };
    });
  }

  // Quick Action Buttons
  hubBtnAddDial?.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'openAddDialModal' }, (resp) => {
      if (chrome.runtime.lastError || !resp) {
        chrome.tabs.create({ url: chrome.runtime.getURL('newtab.html?openAddDial=true') });
      }
      window.close();
    });
  });

  hubBtnBackup?.addEventListener('click', () => {
    const backup = storage.exportBackup();
    downloadJsonFile(backup, 'SpeedDial_Backup.json');
  });

  hubBtnOpenAllSettings?.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'openSettingsModal' }, (resp) => {
      if (chrome.runtime.lastError || !resp) {
        chrome.tabs.create({ url: chrome.runtime.getURL('newtab.html?openSettings=true') });
      }
      window.close();
    });
  });

  // Populate Folders / Desktops
  function renderFolderSelect(selectedId) {
    inputFolder.innerHTML = '';
    state.folders.ids.forEach(id => {
      const folder = state.folders.byId[id];
      if (folder) {
        const opt = document.createElement('option');
        opt.value = id;
        opt.textContent = folder.name;
        if (id === (selectedId || state.activeFolderId)) {
          opt.selected = true;
        }
        inputFolder.appendChild(opt);
      }
    });
  }
  renderFolderSelect();

  // Query Current Tab and route to Hub or Bookmark form
  if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.query) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0]) {
        currentTab = tabs[0];

        if (isSpeedDialPage(currentTab)) {
          renderSpeedDialHub();
          return;
        }

        showBookmarkingForm();

        const tabUrl = currentTab.url || '';
        const tabTitle = currentTab.title || (getLanguage() === 'ru' ? 'Новая страница' : 'New Page');

        inputTitle.value = tabTitle;
        inputUrl.value = tabUrl;
        currentFavicon = getFaviconUrl(tabUrl, currentTab.favIconUrl);

        // Auto-assign authentic brand color or extract dominant color from favicon
        const brand = getBrandColorForUrl(tabUrl, tabTitle);
        if (brand) {
          currentBgColor = brand.bgcolor;
          inputCustomColor.value = currentBgColor;
          colorPalette.querySelectorAll('.color-swatch').forEach(s => {
            s.classList.toggle('active', s.dataset.color.toLowerCase() === currentBgColor.toLowerCase());
          });
        } else {
          const letterInfo = getLetterBadgeInfo(tabTitle, tabUrl);
          currentBgColor = letterInfo.bgColor;
          inputCustomColor.value = currentBgColor;
          if (currentFavicon) {
            extractDominantColorFromImage(currentFavicon).then(extracted => {
              if (extracted) {
                currentBgColor = extracted;
                inputCustomColor.value = currentBgColor;
                updatePreview();
              }
            });
          }
        }

        updatePreview();

        // Auto-capture screenshot of the active tab in high resolution (Retina 560x420)
        chrome.runtime.sendMessage({ action: 'captureTab' }, async (response) => {
          if (response && response.dataUrl) {
            currentScreenshot = await resizeScreenshot(response.dataUrl, 560, 420);
            updatePreview();
          }
        });
      } else {
        renderSpeedDialHub();
      }
    });
  } else {
    renderSpeedDialHub();
  }

  // Update Live Preview
  function updatePreview() {
    const title = inputTitle.value.trim() || (getLanguage() === 'ru' ? 'Сайт' : 'Website');
    const url = inputUrl.value.trim();
    const domain = extractDomain(url) || 'example.com';
    const letterInfo = getLetterBadgeInfo(title, url);

    previewName.textContent = title;
    previewDomain.textContent = domain;

    const favUrl = currentFavicon || getFaviconUrl(url);

    const showFooterLetterBadge = () => {
      previewFooterFavicon.style.display = 'none';
      let badge = previewFooterFavicon.parentElement.querySelector('.dial-footer-letter-badge');
      if (!badge) {
        badge = document.createElement('div');
        badge.className = 'dial-footer-letter-badge';
        previewFooterFavicon.parentElement.prepend(badge);
      }
      badge.style.display = 'flex';
      badge.style.backgroundColor = letterInfo.bgColor;
      badge.textContent = letterInfo.letter;
    };

    // Footer favicon / letter badge
    if (!favUrl || isKnownBadFavicon(url)) {
      showFooterLetterBadge();
    } else {
      const existingBadge = previewFooterFavicon.parentElement.querySelector('.dial-footer-letter-badge');
      if (isKnownValidFavicon(url)) {
        if (existingBadge) existingBadge.style.display = 'none';
        previewFooterFavicon.style.display = 'block';
        previewFooterFavicon.src = favUrl;
      } else {
        showFooterLetterBadge();
        checkFaviconValid(url, favUrl).then(isValid => {
          if (isValid) {
            if (existingBadge) existingBadge.style.display = 'none';
            previewFooterFavicon.style.display = 'block';
            previewFooterFavicon.src = favUrl;
          } else {
            showFooterLetterBadge();
            currentFavicon = '';
          }
        });
      }
      previewFooterFavicon.onerror = () => {
        if (!previewFooterFavicon.dataset.triedDdg && domain) {
          previewFooterFavicon.dataset.triedDdg = '1';
          previewFooterFavicon.src = `https://icons.duckduckgo.com/ip3/${encodeURIComponent(domain)}.ico`;
          return;
        }
        markBadFavicon(url);
        currentFavicon = '';
        showFooterLetterBadge();
      };
    }

    const showLogoLetterBadge = () => {
      previewFavicon.style.display = 'none';
      let logoBadge = previewLogoWrap.querySelector('.dial-logo-letter-badge');
      if (!logoBadge) {
        logoBadge = document.createElement('div');
        logoBadge.className = 'dial-logo-letter-badge';
        previewLogoWrap.appendChild(logoBadge);
      }
      logoBadge.style.display = 'flex';
      logoBadge.style.backgroundColor = letterInfo.bgColor;
      logoBadge.textContent = letterInfo.letter;
    };

    // Logo area icon / letter badge
    if (!favUrl || isKnownBadFavicon(url)) {
      showLogoLetterBadge();
    } else {
      const existingLogoBadge = previewLogoWrap.querySelector('.dial-logo-letter-badge');
      if (isKnownValidFavicon(url)) {
        if (existingLogoBadge) existingLogoBadge.style.display = 'none';
        previewFavicon.style.display = 'block';
        previewFavicon.src = favUrl;
      } else {
        showLogoLetterBadge();
        checkFaviconValid(url, favUrl).then(isValid => {
          if (isValid) {
            if (existingLogoBadge) existingLogoBadge.style.display = 'none';
            previewFavicon.style.display = 'block';
            previewFavicon.src = favUrl;
          } else {
            showLogoLetterBadge();
            currentFavicon = '';
          }
        });
      }
      previewFavicon.onerror = () => {
        if (!previewFavicon.dataset.triedDdg && domain) {
          previewFavicon.dataset.triedDdg = '1';
          previewFavicon.src = `https://icons.duckduckgo.com/ip3/${encodeURIComponent(domain)}.ico`;
          return;
        }
        markBadFavicon(url);
        currentFavicon = '';
        showLogoLetterBadge();
      };
    }

    if (currentTileType === 'screenshot' && currentScreenshot) {
      previewScreenshot.src = currentScreenshot;
      previewScreenshot.style.display = 'block';
      previewLogoWrap.style.display = 'none';
      previewThumbArea.style.backgroundColor = '#18181b';
      if (colorPaletteGroup) colorPaletteGroup.classList.add('hidden');
    } else {
      previewScreenshot.style.display = 'none';
      previewLogoWrap.style.display = 'flex';
      previewThumbArea.style.backgroundColor = currentBgColor;
      if (colorPaletteGroup) colorPaletteGroup.classList.remove('hidden');
    }
  }

  // Input listeners
  inputTitle.addEventListener('input', updatePreview);
  inputUrl.addEventListener('input', () => {
    const rawVal = inputUrl.value.trim();
    if (isInternalOrNewTabUrl(rawVal)) {
      urlValidationMsg?.classList.remove('hidden');
      btnSaveDial.disabled = true;
      btnSaveDial.style.opacity = '0.4';
      btnSaveDial.style.cursor = 'not-allowed';
      btnSaveDial.querySelector('.btn-text').textContent = t('popupCannotAddSelf');
    } else {
      urlValidationMsg?.classList.add('hidden');
      btnSaveDial.disabled = false;
      btnSaveDial.style.opacity = '1';
      btnSaveDial.style.cursor = 'pointer';
      btnSaveDial.querySelector('.btn-text').textContent = t('popupSaveSite');
    }
    currentFavicon = getFaviconUrl(rawVal);
    const brand = getBrandColorForUrl(rawVal, inputTitle.value.trim());
    if (brand) {
      currentBgColor = brand.bgcolor;
      inputCustomColor.value = currentBgColor;
      colorPalette.querySelectorAll('.color-swatch').forEach(s => {
        s.classList.toggle('active', s.dataset.color.toLowerCase() === currentBgColor.toLowerCase());
      });
    } else if (currentFavicon) {
      extractDominantColorFromImage(currentFavicon).then(extracted => {
        if (extracted) {
          currentBgColor = extracted;
          inputCustomColor.value = currentBgColor;
          updatePreview();
        }
      });
    }
    updatePreview();
  });

  // Color Swatches
  colorPalette.querySelectorAll('.color-swatch').forEach(swatch => {
    swatch.addEventListener('click', () => {
      colorPalette.querySelectorAll('.color-swatch').forEach(s => s.classList.remove('active'));
      swatch.classList.add('active');
      currentBgColor = swatch.dataset.color;
      inputCustomColor.value = currentBgColor;
      updatePreview();
    });
  });

  inputCustomColor.addEventListener('input', (e) => {
    colorPalette.querySelectorAll('.color-swatch').forEach(s => s.classList.remove('active'));
    currentBgColor = e.target.value;
    updatePreview();
  });

  // Segmented Buttons (Tile Type: Screenshot vs Logo)
  document.querySelectorAll('#tileTypeControl .segment-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('#tileTypeControl .segment-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentTileType = btn.dataset.type;
      updatePreview();
    });
  });

  // Quick Add Desktop Modal
  btnQuickAddFolder.addEventListener('click', () => {
    newFolderModal.classList.remove('hidden');
    newFolderName.value = '';
    newFolderName.focus();
  });

  btnCancelNewFolder.addEventListener('click', () => {
    newFolderModal.classList.add('hidden');
  });

  btnConfirmNewFolder.addEventListener('click', async () => {
    const name = newFolderName.value.trim();
    if (name) {
      const newF = await storage.addFolder(name, 'folder');
      renderFolderSelect(newF.id);
      newFolderModal.classList.add('hidden');
      if (isSpeedDialTab) {
        renderSpeedDialHub();
      }
    }
  });

  newFolderName.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') btnConfirmNewFolder.click();
    if (e.key === 'Escape') btnCancelNewFolder.click();
  });

  // Save Dial
  btnSaveDial.addEventListener('click', async () => {
    const rawUrl = inputUrl.value.trim();
    if (isInternalOrNewTabUrl(rawUrl)) {
      urlValidationMsg?.classList.remove('hidden');
      return;
    }
    const url = sanitizeUrl(rawUrl);
    const name = inputTitle.value.trim() || (getLanguage() === 'ru' ? 'Сайт' : 'Website');
    const folderId = inputFolder.value;

    if (!url || isInternalOrNewTabUrl(url)) {
      urlValidationMsg?.classList.remove('hidden');
      inputUrl.focus();
      return;
    }

    btnSaveDial.disabled = true;
    btnSaveDial.classList.add('success');
    btnSaveDial.querySelector('.btn-text').textContent = '✓ ' + t('toastSaved');

    const noFavicon = !currentFavicon || isKnownBadFavicon(url);
    await storage.addDial({
      folderId,
      name,
      url,
      tileType: currentTileType,
      screenshotUrl: currentTileType === 'screenshot' ? currentScreenshot : '',
      bgcolor: currentBgColor,
      textColor: getContrastTextColor(currentBgColor),
      faviconUrl: noFavicon ? '' : currentFavicon,
      noFavicon
    });

    // Ensure cloud sync push is completed before popup closes
    await storage.syncToChromeStorageSync().catch(() => {});

    // Badge feedback
    if (chrome.action && chrome.action.setBadgeText) {
      chrome.action.setBadgeText({ text: '✓' });
      chrome.action.setBadgeBackgroundColor({ color: '#27ae60' });
      setTimeout(() => chrome.action.setBadgeText({ text: '' }), 2000);
    }

    setTimeout(() => {
      window.close();
    }, 600);
  });

  // Open New Tab
  btnOpenNewTab.addEventListener('click', () => {
    if (chrome.tabs && chrome.tabs.create) {
      chrome.tabs.create({ url: chrome.runtime.getURL('newtab.html') });
      window.close();
    }
  });

  updatePreview();
});
