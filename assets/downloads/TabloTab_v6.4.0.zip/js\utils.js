// Utility helper functions

export function generateId() {
  return 'tm_' + Date.now().toString(36) + '_' + Math.random().toString(36).substring(2, 7);
}

export function extractDomain(url) {
  if (!url || typeof url !== 'string') return '';
  try {
    const parsed = new URL(url.startsWith('http') ? url : 'https://' + url);
    return parsed.hostname.replace(/^www\./, '');
  } catch (e) {
    return url || '';
  }
}

const badFaviconDomains = new Set(['shui.hardisoft.ru', 'example.com']);
const validFaviconDomains = new Set();

export function isKnownBadFavicon(url) {
  const domain = extractDomain(url);
  return domain ? badFaviconDomains.has(domain) : false;
}

export function isKnownValidFavicon(url) {
  const domain = extractDomain(url);
  return domain ? validFaviconDomains.has(domain) : false;
}

export function markBadFavicon(url) {
  const domain = extractDomain(url);
  if (domain) {
    badFaviconDomains.add(domain);
    validFaviconDomains.delete(domain);
  }
}

export function markValidFavicon(url) {
  const domain = extractDomain(url);
  if (domain) {
    validFaviconDomains.add(domain);
    badFaviconDomains.delete(domain);
  }
}

export async function checkFaviconValid(url, explicitFavicon = '') {
  const domain = extractDomain(url);
  if (!domain) return false;
  if (badFaviconDomains.has(domain)) return false;
  if (validFaviconDomains.has(domain)) return true;

  const checkUrl = explicitFavicon && !explicitFavicon.includes('google.com/s2/favicons')
    ? explicitFavicon
    : `https://www.google.com/s2/favicons?domain=${encodeURIComponent(domain)}&sz=128`;

  try {
    let res = await fetch(checkUrl, { method: 'GET', cache: 'force-cache' });
    // Google S2 returns 404 when no favicon exists! Try DuckDuckGo before marking bad
    if (!res.ok || res.status === 404) {
      if (!explicitFavicon || explicitFavicon.includes('google.com/s2/favicons')) {
        try {
          const ddgRes = await fetch(`https://icons.duckduckgo.com/ip3/${encodeURIComponent(domain)}.ico`, { method: 'GET', cache: 'force-cache' });
          if (ddgRes.ok && ddgRes.status !== 404) {
            const ddgBlob = await ddgRes.blob();
            if (ddgBlob.size !== 1478 && ddgBlob.size > 70) {
              validFaviconDomains.add(domain);
              return true;
            }
          }
        } catch (e) {
          // ignore DDG error
        }
      }
      badFaviconDomains.add(domain);
      return false;
    }
    const blob = await res.blob();
    // Default fallback globe is exactly 726 bytes, DuckDuckGo fallback is 1478 bytes, empty/1x1 is <= 70 bytes
    if (blob.size === 726 || blob.size === 1478 || blob.size <= 70) {
      badFaviconDomains.add(domain);
      return false;
    }
    validFaviconDomains.add(domain);
    return true;
  } catch (e) {
    badFaviconDomains.add(domain);
    return false;
  }
}

export function getFaviconUrl(url, explicitFavicon = '', noFavicon = false) {
  if (noFavicon) return '';
  const domain = extractDomain(url);
  if (!domain || badFaviconDomains.has(domain)) return '';

  if (explicitFavicon) {
    if (
      !explicitFavicon.includes('blank_favicon') &&
      !explicitFavicon.includes('tabmark.me') &&
      !explicitFavicon.includes('shikimori.one') &&
      !explicitFavicon.includes('printables.com') &&
      !explicitFavicon.includes('localhost')
    ) {
      return explicitFavicon;
    }
  }

  return `https://www.google.com/s2/favicons?domain=${encodeURIComponent(domain)}&sz=128`;
}

export function getContrastTextColor(hexColor) {
  if (!hexColor || hexColor === 'transparent') return '#ffffff';
  
  let color = hexColor.replace('#', '');
  if (color.length === 3) {
    color = color.split('').map(c => c + c).join('');
  }
  
  const r = parseInt(color.substring(0, 2), 16) || 0;
  const g = parseInt(color.substring(2, 4), 16) || 0;
  const b = parseInt(color.substring(4, 6), 16) || 0;
  
  // Perceived luminance formula
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return luminance > 0.65 ? '#1a1a1a' : '#ffffff';
}

export function hexToRgba(hexColor, alpha = 1) {
  if (!hexColor || typeof hexColor !== 'string') return `rgba(0, 120, 215, ${alpha})`;
  let color = hexColor.replace('#', '').trim();
  if (color.length === 3) {
    color = color.split('').map(c => c + c).join('');
  }
  const num = parseInt(color, 16);
  if (isNaN(num)) return `rgba(0, 120, 215, ${alpha})`;
  const r = (num >> 16) & 255;
  const g = (num >> 8) & 255;
  const b = num & 255;
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

export function downloadJsonFile(data, filename = 'SpeedDial_Backup.json') {
  const jsonStr = typeof data === 'string' ? data : JSON.stringify(data, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function readJsonFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const parsed = JSON.parse(e.target.result);
        resolve(parsed);
      } catch (err) {
        reject(new Error('Неверный формат JSON файла'));
      }
    };
    reader.onerror = () => reject(new Error('Ошибка чтения файла'));
    reader.readAsText(file);
  });
}

export function sanitizeUrl(url) {
  let cleaned = (url || '').trim();
  if (!cleaned) return '';
  if (!/^https?:\/\//i.test(cleaned)) {
    cleaned = 'https://' + cleaned;
  }
  return cleaned;
}

export function debounce(func, wait = 300) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

export function resizeScreenshot(dataUrl, targetWidth = 560, targetHeight = 420) {
  return new Promise((resolve) => {
    if (!dataUrl) return resolve('');
    if (typeof document === 'undefined') return resolve(dataUrl);
    const img = new Image();
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = targetWidth;
        canvas.height = targetHeight;
        const ctx = canvas.getContext('2d');
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';

        // Draw top-anchored cropped image
        const targetAspect = targetWidth / targetHeight;
        let sWidth = img.width;
        let sHeight = img.width / targetAspect;
        if (sHeight > img.height) {
          sHeight = img.height;
          sWidth = img.height * targetAspect;
        }

        ctx.drawImage(img, 0, 0, sWidth, sHeight, 0, 0, targetWidth, targetHeight);
        resolve(canvas.toDataURL('image/jpeg', 0.86));
      } catch (e) {
        resolve(dataUrl);
      }
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
}

const LETTER_COLORS = [
  '#0078d7', // Windows blue
  '#107c41', // Emerald green
  '#d83b01', // Windows orange
  '#e53935', // Crimson red
  '#9146ff', // Twitch purple
  '#008272', // Teal
  '#5c2d91', // Deep purple
  '#004e8c', // Cobalt blue
  '#b4009e', // Magenta
  '#2d7d9a', // Steel cyan
  '#515c6b', // Slate
  '#c239b3'  // Orchid
];

export function getLetterBadgeInfo(name, url) {
  let str = (name || '').trim();
  if (!str || str.toLowerCase() === 'сайт') {
    const domain = extractDomain(url) || '';
    str = domain.replace(/^www\./i, '');
  }
  let letter = '?';
  const match = str.match(/[a-zA-Zа-яА-Я0-9]/);
  if (match) {
    letter = match[0].toUpperCase();
  } else if (str.length > 0) {
    letter = str.charAt(0).toUpperCase();
  }

  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash * 31 + str.charCodeAt(i)) % LETTER_COLORS.length;
  }
  const bgColor = LETTER_COLORS[Math.abs(hash)];

  return { letter, bgColor };
}

export function isInternalOrNewTabUrl(url) {
  if (!url) return false;
  const lower = url.trim().toLowerCase();
  return (
    lower.startsWith('chrome://') ||
    lower.startsWith('chrome-extension://') ||
    lower.startsWith('edge://') ||
    lower.startsWith('thorium://') ||
    lower.startsWith('about:') ||
    lower.startsWith('view-source:') ||
    lower.startsWith('devtools://') ||
    lower.includes('newtab.html')
  );
}

export function resolveTheme(themeSetting) {
  if (themeSetting === 'light') return 'light';
  if (themeSetting === 'dark') return 'dark';
  // 'system'
  if (typeof window !== 'undefined' && window.matchMedia) {
    return window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
  }
  return 'dark';
}

export const BRAND_RULES = [
  // E-Commerce & Marketplaces
  { domains: ['wildberries.ru', 'wb.ru'], names: ['wildberries', 'вайлдберриз', 'вайлдберрис', 'вб'], bgcolor: '#cb11ab', textColor: '#ffffff' },
  { domains: ['ozon.ru'], names: ['ozon', 'озон'], bgcolor: '#005bff', textColor: '#ffffff' },
  { domains: ['aliexpress.ru', 'aliexpress.com', 'shopnow.pub'], names: ['aliexpress', 'алиэкспресс', 'али'], bgcolor: '#e62e04', textColor: '#ffffff' },
  { domains: ['avito.ru'], names: ['avito', 'авито'], bgcolor: '#00aaff', textColor: '#ffffff' },
  { domains: ['pepper.ru'], names: ['pepper', 'пеппер'], bgcolor: '#ff5a00', textColor: '#ffffff' },
  { domains: ['megamarket.ru'], names: ['мегамаркет', 'megamarket'], bgcolor: '#5c2d91', textColor: '#ffffff' },
  { domains: ['dns-shop.ru'], names: ['dns', 'днс'], bgcolor: '#ec6608', textColor: '#ffffff' },
  { domains: ['mvideo.ru'], names: ['мвидео', 'м.видео', 'mvideo'], bgcolor: '#e31e24', textColor: '#ffffff' },
  { domains: ['eldorado.ru'], names: ['эльдорадо', 'eldorado'], bgcolor: '#e31e24', textColor: '#ffffff' },
  { domains: ['citilink.ru'], names: ['ситилинк', 'citilink'], bgcolor: '#f25b2a', textColor: '#ffffff' },
  { domains: ['lamoda.ru'], names: ['ламода', 'lamoda'], bgcolor: '#111111', textColor: '#ffffff' },
  { domains: ['samokat.ru'], names: ['самокат', 'samokat'], bgcolor: '#ff335f', textColor: '#ffffff' },
  { domains: ['dodopizza.ru'], names: ['додо', 'dodo pizza', 'dodopizza'], bgcolor: '#ff6900', textColor: '#ffffff' },
  { domains: ['delivery-club.ru', 'market-delivery.yandex.ru'], names: ['delivery club', 'маркет деливери'], bgcolor: '#00b956', textColor: '#ffffff' },

  // Social & Messengers
  { domains: ['vk.com', 'vkvideo.ru', 'vkplay.ru'], names: ['вконтакте', 'вк', 'vk'], bgcolor: '#0077ff', textColor: '#ffffff' },
  { domains: ['t.me', 'telegram.org', 'web.telegram.org'], names: ['telegram', 'телеграм', 'телега'], bgcolor: '#24a1de', textColor: '#ffffff' },
  { domains: ['youtube.com', 'youtu.be'], names: ['youtube', 'ютуб'], bgcolor: '#e53935', textColor: '#ffffff' },
  { domains: ['rutube.ru'], names: ['rutube', 'рутуб'], bgcolor: '#0d141e', textColor: '#ffffff' },
  { domains: ['twitch.tv'], names: ['twitch', 'твич'], bgcolor: '#9146ff', textColor: '#ffffff' },
  { domains: ['discord.com'], names: ['discord', 'дискорд'], bgcolor: '#5865f2', textColor: '#ffffff' },
  { domains: ['reddit.com'], names: ['reddit', 'реддит'], bgcolor: '#ff4500', textColor: '#ffffff' },
  { domains: ['x.com', 'twitter.com'], names: ['twitter', 'твиттер'], bgcolor: '#111111', textColor: '#ffffff' },
  { domains: ['instagram.com'], names: ['instagram', 'инстаграм'], bgcolor: '#e1306c', textColor: '#ffffff' },
  { domains: ['facebook.com'], names: ['facebook', 'фейсбук'], bgcolor: '#1877f2', textColor: '#ffffff' },
  { domains: ['tiktok.com'], names: ['tiktok', 'тикток'], bgcolor: '#010101', textColor: '#ffffff' },
  { domains: ['pinterest.com'], names: ['pinterest', 'пинтерест'], bgcolor: '#e60023', textColor: '#ffffff' },

  // Search & Portals & Mail
  { domains: ['yandex.ru', 'ya.ru', 'dzen.ru'], names: ['яндекс', 'yandex', 'дзен', 'dzen'], bgcolor: '#fc3f1d', textColor: '#ffffff' },
  { domains: ['disk.yandex.ru'], names: ['яндекс.диск', 'яндекс диск', 'yandex disk'], bgcolor: '#ffcc00', textColor: '#1a1a1a' },
  { domains: ['mail.yandex.ru'], names: ['яндекс.почта', 'яндекс почта'], bgcolor: '#fc3f1d', textColor: '#ffffff' },
  { domains: ['market.yandex.ru'], names: ['яндекс маркет', 'яндекс.маркет'], bgcolor: '#fc3f1d', textColor: '#ffffff' },
  { domains: ['maps.yandex.ru'], names: ['яндекс карты', 'яндекс.карты'], bgcolor: '#fc3f1d', textColor: '#ffffff' },
  { domains: ['music.yandex.ru'], names: ['яндекс музыка', 'яндекс.музыка'], bgcolor: '#ffcc00', textColor: '#1a1a1a' },
  { domains: ['mail.ru'], names: ['mail.ru', 'мэйл'], bgcolor: '#005ff9', textColor: '#ffffff' },
  { domains: ['google.com', 'google.ru'], names: ['google', 'гугл'], bgcolor: '#4285f4', textColor: '#ffffff' },
  { domains: ['mail.google.com'], names: ['gmail', 'джимейл'], bgcolor: '#ea4335', textColor: '#ffffff' },

  // Banking & Finance
  { domains: ['sberbank.ru', 'sber.ru'], names: ['сбербанк', 'сбер', 'sberbank', 'sber'], bgcolor: '#21a038', textColor: '#ffffff' },
  { domains: ['tbank.ru', 'tinkoff.ru'], names: ['т-банк', 'тинькофф', 't-bank', 'tinkoff'], bgcolor: '#ffdd2d', textColor: '#1a1a1a' },
  { domains: ['alfabank.ru'], names: ['альфа-банк', 'альфа', 'alfabank'], bgcolor: '#ef3124', textColor: '#ffffff' },
  { domains: ['vtb.ru'], names: ['втб', 'vtb'], bgcolor: '#002882', textColor: '#ffffff' },

  // Cinema, Entertainment & Media
  { domains: ['kinopoisk.ru'], names: ['кинопоиск', 'kinopoisk'], bgcolor: '#ff6600', textColor: '#ffffff' },
  { domains: ['ivi.ru'], names: ['ivi', 'иви'], bgcolor: '#ea1542', textColor: '#ffffff' },
  { domains: ['okko.tv'], names: ['okko', 'окко'], bgcolor: '#500b75', textColor: '#ffffff' },
  { domains: ['kion.ru'], names: ['kion', 'кион'], bgcolor: '#8c19ff', textColor: '#ffffff' },
  { domains: ['premier.one'], names: ['premier', 'премьер'], bgcolor: '#00a4ff', textColor: '#ffffff' },
  { domains: ['spotify.com'], names: ['spotify', 'спотифай'], bgcolor: '#1db954', textColor: '#ffffff' },
  { domains: ['netflix.com'], names: ['netflix', 'нетфликс'], bgcolor: '#e50914', textColor: '#ffffff' },
  { domains: ['shikimori.one', 'shikimori.me'], names: ['shikimori', 'шикимори'], bgcolor: '#343434', textColor: '#ffffff' },

  // Tech, Dev, AI & 3D Printing
  { domains: ['chatgpt.com', 'openai.com'], names: ['chatgpt', 'чатгпт', 'openai'], bgcolor: '#10a37f', textColor: '#ffffff' },
  { domains: ['github.com'], names: ['github', 'гитхаб'], bgcolor: '#24292e', textColor: '#ffffff' },
  { domains: ['gitlab.com'], names: ['gitlab', 'гитлаб'], bgcolor: '#fc6d26', textColor: '#ffffff' },
  { domains: ['habr.com'], names: ['habr', 'хабр'], bgcolor: '#548eaa', textColor: '#ffffff' },
  { domains: ['4pda.to', '4pda.ru'], names: ['4pda'], bgcolor: '#0072bc', textColor: '#ffffff' },
  { domains: ['steampowered.com', 'steamcommunity.com'], names: ['steam', 'стим'], bgcolor: '#171a21', textColor: '#ffffff' },
  { domains: ['makerworld.com'], names: ['makerworld'], bgcolor: '#00ae42', textColor: '#ffffff' },
  { domains: ['printables.com'], names: ['printables'], bgcolor: '#fa6831', textColor: '#ffffff' },
  { domains: ['thingiverse.com'], names: ['thingiverse'], bgcolor: '#248bfb', textColor: '#ffffff' },
  { domains: ['devicespecifications.com'], names: ['devicespecifications'], bgcolor: '#1c1d22', textColor: '#ffffff' },
  { domains: ['admitad.com'], names: ['admitad'], bgcolor: '#5d3ebd', textColor: '#ffffff' },
  { domains: ['epn.bz'], names: ['epn'], bgcolor: '#e51937', textColor: '#ffffff' },

  // Services, Gov & Delivery
  { domains: ['gosuslugi.ru'], names: ['госуслуги', 'gosuslugi'], bgcolor: '#0d4cd3', textColor: '#ffffff' },
  { domains: ['uslugi.tatarstan.ru'], names: ['госуслуги рт', 'uslugi tatarstan'], bgcolor: '#00843d', textColor: '#ffffff' },
  { domains: ['backit.me'], names: ['backit', 'бэкит'], bgcolor: '#2b78ff', textColor: '#ffffff' },
  { domains: ['boxberry.ru'], names: ['boxberry', 'боксберри'], bgcolor: '#dc0046', textColor: '#ffffff' },
  { domains: ['cdek.ru'], names: ['сдэк', 'cdek'], bgcolor: '#00aa4f', textColor: '#ffffff' },
  { domains: ['pochta.ru'], names: ['почта россии', 'pochta'], bgcolor: '#0055a5', textColor: '#ffffff' },
  { domains: ['hh.ru'], names: ['headhunter', 'hh.ru', 'хэдхантер'], bgcolor: '#d6001c', textColor: '#ffffff' },
  { domains: ['superjob.ru'], names: ['superjob', 'суперджоб'], bgcolor: '#009966', textColor: '#ffffff' },
  { domains: ['2gis.ru'], names: ['2gis', '2гис', 'двагис'], bgcolor: '#00b956', textColor: '#ffffff' },
  { domains: ['cian.ru'], names: ['циан', 'cian'], bgcolor: '#0468ff', textColor: '#ffffff' },
  { domains: ['auto.ru'], names: ['auto.ru', 'авто.ру'], bgcolor: '#ee2d24', textColor: '#ffffff' },
  { domains: ['drom.ru'], names: ['drom.ru', 'дром'], bgcolor: '#e31e24', textColor: '#ffffff' },
  { domains: ['pikabu.ru'], names: ['pikabu', 'пикабу'], bgcolor: '#66b83f', textColor: '#ffffff' },
  { domains: ['rbc.ru'], names: ['рбк', 'rbc'], bgcolor: '#00a859', textColor: '#ffffff' },
  { domains: ['ria.ru'], names: ['риа', 'ria'], bgcolor: '#1d3e75', textColor: '#ffffff' },
  { domains: ['lenta.ru'], names: ['lenta.ru', 'лента'], bgcolor: '#292929', textColor: '#ffffff' },
  { domains: ['wikipedia.org'], names: ['wikipedia', 'википедия'], bgcolor: '#3366cc', textColor: '#ffffff' }
];

export function getBrandColorForUrl(url, name = '') {
  if (!url && !name) return null;
  const domain = extractDomain(url).toLowerCase();
  const nameLower = (name || '').toLowerCase().trim();

  for (const item of BRAND_RULES) {
    if (item.domains.some(d => domain === d || domain.endsWith('.' + d))) {
      return { bgcolor: item.bgcolor, textColor: item.textColor || getContrastTextColor(item.bgcolor) };
    }
    if (item.names && item.names.some(n => nameLower === n || (n.length >= 3 && nameLower.split(/\s+/).includes(n)))) {
      return { bgcolor: item.bgcolor, textColor: item.textColor || getContrastTextColor(item.bgcolor) };
    }
  }
  return null;
}

export async function extractDominantColorFromImage(imageUrl) {
  if (!imageUrl || typeof document === 'undefined') return null;
  try {
    let src = imageUrl;
    let objectUrl = null;
    try {
      const res = await fetch(imageUrl, { cache: 'force-cache' });
      if (res.ok) {
        const blob = await res.blob();
        objectUrl = URL.createObjectURL(blob);
        src = objectUrl;
      }
    } catch (e) {
      // Fallback to direct src if fetch fails
    }

    return await new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        try {
          const canvas = document.createElement('canvas');
          const size = 32;
          canvas.width = size;
          canvas.height = size;
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, size, size);
          const data = ctx.getImageData(0, 0, size, size).data;

          const colorBuckets = {};
          for (let i = 0; i < data.length; i += 4) {
            const a = data[i + 3];
            if (a < 128) continue;
            const r = data[i];
            const g = data[i + 1];
            const b = data[i + 2];

            if (r > 240 && g > 240 && b > 240) continue; // Skip near white
            if (r < 25 && g < 25 && b < 25) continue;    // Skip near black

            const max = Math.max(r, g, b);
            const min = Math.min(r, g, b);
            const delta = max - min;
            if (delta < 20) continue; // Skip gray

            const qr = Math.round(r / 16) * 16;
            const qg = Math.round(g / 16) * 16;
            const qb = Math.round(b / 16) * 16;
            const key = `${qr},${qg},${qb}`;

            const saturation = delta / max;
            const weight = 1 + saturation * 2;
            colorBuckets[key] = (colorBuckets[key] || 0) + weight;
          }

          let bestKey = null;
          let maxScore = 0;
          for (const [k, score] of Object.entries(colorBuckets)) {
            if (score > maxScore) {
              maxScore = score;
              bestKey = k;
            }
          }

          if (bestKey && maxScore > 2) {
            const [r, g, b] = bestKey.split(',').map(Number);
            const hex = '#' + [r, g, b].map(x => {
              const clamped = Math.max(0, Math.min(255, x));
              return clamped.toString(16).padStart(2, '0');
            }).join('');
            resolve(hex);
          } else {
            resolve(null);
          }
        } catch (err) {
          resolve(null);
        } finally {
          if (objectUrl) URL.revokeObjectURL(objectUrl);
        }
      };
      img.onerror = () => {
        if (objectUrl) URL.revokeObjectURL(objectUrl);
        resolve(null);
      };
      img.src = src;
    });
  } catch (e) {
    return null;
  }
}

export async function resolveDialColor(url, name = '', faviconUrl = '') {
  const brand = getBrandColorForUrl(url, name);
  if (brand) {
    return {
      bgcolor: brand.bgcolor,
      textColor: brand.textColor || getContrastTextColor(brand.bgcolor),
      source: 'brand'
    };
  }

  const fav = faviconUrl || getFaviconUrl(url);
  if (fav && !isKnownBadFavicon(url)) {
    const dominant = await extractDominantColorFromImage(fav);
    if (dominant) {
      return {
        bgcolor: dominant,
        textColor: getContrastTextColor(dominant),
        source: 'favicon'
      };
    }
  }

  const letterInfo = getLetterBadgeInfo(name, url);
  return {
    bgcolor: letterInfo.bgColor,
    textColor: '#ffffff',
    source: 'letter'
  };
}


