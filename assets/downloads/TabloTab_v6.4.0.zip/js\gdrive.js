// Google Drive Cloud Sync Module
import { storage } from './storage.js';

const BACKUP_FILENAME = 'SpeedDial_Backup.json';
const DRIVE_FILE_SCOPE = 'https://www.googleapis.com/auth/drive.file';

class GoogleDriveSync {
  constructor() {
    this.accessToken = null;
    this.fileId = null;
  }

  async getAuthToken(interactive = true) {
    if (this.accessToken) {
      // Validate token
      const valid = await this.validateToken(this.accessToken);
      if (valid) return this.accessToken;
    }

    const state = await storage.getState();
    const customClientId = state.settings?.googleDrive?.clientId || '';

    // If chrome.identity is available and interactive flow is requested
    if (typeof chrome !== 'undefined' && chrome.identity && chrome.identity.launchWebAuthFlow) {
      if (!customClientId) {
        throw new Error('Укажите Google Client ID в настройках Google Диска');
      }

      const redirectUri = chrome.identity.getRedirectURL();
      const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?` +
        `client_id=${encodeURIComponent(customClientId)}&` +
        `response_type=token&` +
        `scope=${encodeURIComponent(DRIVE_FILE_SCOPE)}&` +
        `redirect_uri=${encodeURIComponent(redirectUri)}`;

      return new Promise((resolve, reject) => {
        chrome.identity.launchWebAuthFlow({ url: authUrl, interactive }, (redirectUrl) => {
          if (chrome.runtime.lastError || !redirectUrl) {
            reject(new Error(chrome.runtime.lastError?.message || 'Авторизация отменена пользователем'));
            return;
          }
          try {
            const url = new URL(redirectUrl);
            const params = new URLSearchParams(url.hash.substring(1));
            const token = params.get('access_token');
            if (token) {
              this.accessToken = token;
              this.updateConnectionStatus(true);
              resolve(token);
            } else {
              reject(new Error('Не удалось получить токен авторизации'));
            }
          } catch (e) {
            reject(e);
          }
        });
      });
    }

    throw new Error('Функция Google Identity недоступна в этом браузере');
  }

  async validateToken(token) {
    try {
      const res = await fetch(`https://www.googleapis.com/oauth2/v1/tokeninfo?access_token=${token}`);
      return res.ok;
    } catch {
      return false;
    }
  }

  async findBackupFile(token) {
    if (this.fileId) return this.fileId;
    const q = encodeURIComponent(`name='${BACKUP_FILENAME}' and trashed=false`);
    const res = await fetch(`https://www.googleapis.com/drive/v3/files?q=${q}&fields=files(id,name,modifiedTime)`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (!res.ok) throw new Error('Ошибка поиска файла на Google Диске: ' + res.statusText);
    const data = await res.json();
    if (data.files && data.files.length > 0) {
      this.fileId = data.files[0].id;
      return this.fileId;
    }
    return null;
  }

  async uploadBackup(interactive = true) {
    const token = await this.getAuthToken(interactive);
    const backupData = storage.exportBackup();
    const backupJson = JSON.stringify(backupData, null, 2);

    let existingFileId = await this.findBackupFile(token);

    if (existingFileId) {
      // Update existing file
      const updateUrl = `https://www.googleapis.com/upload/drive/v3/files/${existingFileId}?uploadType=media`;
      const res = await fetch(updateUrl, {
        method: 'PATCH',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: backupJson
      });
      if (!res.ok) throw new Error('Не удалось обновить файл на Google Диске: ' + res.statusText);
    } else {
      // Create new file via multipart
      const metadata = {
        name: BACKUP_FILENAME,
        mimeType: 'application/json',
        description: 'Резервная копия рабочих столов и сайтов Speed Dial'
      };

      const boundary = '-------SpeedDialBoundary' + Math.random().toString(36).substring(2);
      const delimiter = '\r\n--' + boundary + '\r\n';
      const closeDelim = '\r\n--' + boundary + '--';

      const multipartRequestBody =
        delimiter +
        'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
        JSON.stringify(metadata) +
        delimiter +
        'Content-Type: application/json\r\n\r\n' +
        backupJson +
        closeDelim;

      const uploadUrl = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart';
      const res = await fetch(uploadUrl, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': `multipart/related; boundary=${boundary}`
        },
        body: multipartRequestBody
      });
      if (!res.ok) throw new Error('Не удалось создать файл на Google Диске: ' + res.statusText);
      const created = await res.json();
      this.fileId = created.id;
    }

    const state = await storage.getState();
    await storage.updateSettings({
      googleDrive: {
        ...state.settings.googleDrive,
        lastSynced: new Date().toISOString(),
        connected: true
      }
    });

    return { success: true, timestamp: new Date() };
  }

  async downloadBackup(interactive = true) {
    const token = await this.getAuthToken(interactive);
    const fileId = await this.findBackupFile(token);
    if (!fileId) {
      throw new Error('Резервная копия не найдена на вашем Google Диске');
    }

    const downloadUrl = `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`;
    const res = await fetch(downloadUrl, {
      headers: { Authorization: `Bearer ${token}` }
    });

    if (!res.ok) throw new Error('Не удалось загрузить файл из Google Диска: ' + res.statusText);
    const data = await res.json();

    await storage.importBackup(data);

    const state = await storage.getState();
    await storage.updateSettings({
      googleDrive: {
        ...state.settings.googleDrive,
        lastSynced: new Date().toISOString(),
        connected: true
      }
    });

    return { success: true, timestamp: new Date() };
  }

  async updateConnectionStatus(connected) {
    const state = await storage.getState();
    await storage.updateSettings({
      googleDrive: {
        ...state.settings.googleDrive,
        connected
      }
    });
  }

  disconnect() {
    this.accessToken = null;
    this.fileId = null;
    this.updateConnectionStatus(false);
  }
}

export const gdriveSync = new GoogleDriveSync();
