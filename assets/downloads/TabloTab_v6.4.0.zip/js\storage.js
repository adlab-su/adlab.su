// Storage Manager for Speed Dial MV3
import { defaultFolders, defaultDials, defaultSettings, defaultNotepad } from './defaultData.js';
import { generateId, debounce, extractDomain, getBrandColorForUrl, getLetterBadgeInfo, getContrastTextColor } from './utils.js';

const isPopup = typeof window !== 'undefined' && (window.location?.pathname?.includes('popup') || window.location?.href?.includes('popup.html'));
const INSTANCE_ID = Math.random().toString(36).substring(2) + Date.now().toString(36);

class StorageManager {
  constructor() {
    this.cache = {
      folders: null,
      dials: null,
      settings: null,
      activeFolderId: null,
      notepad: null,
      tombstones: { dials: {}, folders: {} },
      updatedAt: 0
    };
    this.listeners = new Set();
    this.lastSyncSentTime = 0;
    this.lastSyncWriteTime = 0;
    this.pendingSyncTimer = null;
    this.isSyncing = false;
    this.syncDebounced = debounce(() => this.syncToChromeStorageSync(), 3500);

    // Listen to changes across tabs/popup
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener((changes, areaName) => {
        if (areaName === 'local') {
          // If written by this exact tab/window instance, skip echoing back (already handled by persist callback)
          if (changes['sd_local_writer']?.newValue === INSTANCE_ID) {
            return;
          }
          let hasChange = false;
          const changedKeys = [];
          ['folders', 'dials', 'settings', 'activeFolderId', 'tombstones', 'updatedAt', 'notepad'].forEach(key => {
            if (changes[key]) {
              this.cache[key] = changes[key].newValue;
              hasChange = true;
              changedKeys.push(key);
            }
          });
          if (hasChange) {
            this.notifyListeners(changedKeys);
          }
        } else if (areaName === 'sync' && !isPopup && (changes['sd_sync_count'] || changes['sd_sync_time'] || changes['sd_sync_writer'])) {
          // If written by this exact window instance, skip
          if (changes['sd_sync_writer']?.newValue === INSTANCE_ID) {
            return;
          }
          const newSyncTime = changes['sd_sync_time']?.newValue;
          if (newSyncTime && newSyncTime === this.lastSyncSentTime) {
            return;
          }

          // Change came from another computer: execute smart sync merge WITHOUT echoing back to cloud
          this.smartSyncChromeProfile({ pushBackToCloud: false }).catch(err => {
            console.warn('Auto background smart sync failed:', err);
          });
        }
      });
    }
  }

  async init() {
    if (this.cache.folders && this.cache.dials && this.cache.settings) {
      return this.cache;
    }

    return new Promise((resolve) => {
      chrome.storage.local.get(['folders', 'dials', 'settings', 'activeFolderId', 'updatedAt', 'tombstones', 'notepad'], async (res) => {
        let needsSave = false;

        this.cache.tombstones = res.tombstones || { dials: {}, folders: {} };
        this.cache.updatedAt = res.updatedAt || 0;

        // If local storage is empty, check if cloud sync has data from another PC!
        if (!res.folders || !res.folders.ids || res.folders.ids.length === 0) {
          const syncedData = await this.loadFromChromeStorageSync();
          if (syncedData && syncedData.folders && syncedData.folders.ids && syncedData.folders.ids.length > 0) {
            res = syncedData;
            if (syncedData.tombstones) this.cache.tombstones = syncedData.tombstones;
            needsSave = true;
          }
        }

        // Initialize folders
        if (!res.folders || !res.folders.ids || res.folders.ids.length === 0) {
          this.cache.folders = JSON.parse(JSON.stringify(defaultFolders));
          needsSave = true;
        } else {
          this.cache.folders = res.folders;
        }

        // Ensure folders have groups array
        if (this.cache.folders?.byId) {
          Object.values(this.cache.folders.byId).forEach(f => {
            if (!f.groups) f.groups = [];
          });
        }

        // Initialize dials
        if (!res.dials || !res.dials.ids || res.dials.ids.length === 0) {
          this.cache.dials = JSON.parse(JSON.stringify(defaultDials));
          needsSave = true;
        } else {
          this.cache.dials = res.dials;
        }

        // Initialize settings
        if (!res.settings || !res.settings.dialWidth) {
          this.cache.settings = JSON.parse(JSON.stringify(defaultSettings));
          needsSave = true;
        } else {
          this.cache.settings = { ...defaultSettings, ...res.settings };
        }

        // Initialize notepad
        if (!res.notepad) {
          this.cache.notepad = JSON.parse(JSON.stringify(defaultNotepad));
          needsSave = true;
        } else {
          this.cache.notepad = { ...defaultNotepad, ...res.notepad };
        }

        // Active folder
        if (!res.activeFolderId || !this.cache.folders.byId[res.activeFolderId]) {
          this.cache.activeFolderId = this.cache.folders.ids[0] || '1';
          needsSave = true;
        } else {
          this.cache.activeFolderId = res.activeFolderId;
        }

        if (needsSave) {
          await this.persist();
        }

        resolve(this.cache);

        // Background automatic smart sync on startup (pulls changes made on other PCs without blocking UI)
        if (!isPopup) {
          setTimeout(() => {
            this.smartSyncChromeProfile({ pushBackToCloud: false }).catch(() => {});
          }, 350);
        }
      });
    });
  }

  cleanAndFixDials() {
    if (!this.cache.dials?.byId) return false;
    let changed = false;

    // Check settings background
    if (!this.cache.settings.background) {
      this.cache.settings.background = {
        type: 'color',
        color: '#181818',
        url: '',
        overlayOpacity: 0
      };
      changed = true;
    } else if (!this.cache.settings.background.color) {
      this.cache.settings.background.color = '#181818';
      changed = true;
    }

    if (!this.cache.settings.theme) {
      this.cache.settings.theme = 'system';
      changed = true;
    }

    Object.keys(this.cache.dials.byId).forEach(id => {
      const dial = this.cache.dials.byId[id];
      if (!dial || !dial.url) return;
      const domain = extractDomain(dial.url);

      // Preserve screenshots and remove only legacy external images
      const isScreenshot = dial.tileType === 'screenshot' || Boolean(dial.screenshotUrl);
      if (!isScreenshot) {
        if (dial.imgUrl && (dial.imgUrl.includes('tabmark.me') || dial.type === 'bg_image')) {
          dial.imgUrl = '';
          dial.type = 'gen';
          changed = true;
        }
      } else {
        // Ensure screenshot properties are synchronized
        if (dial.screenshotUrl && !dial.imgUrl) {
          dial.imgUrl = dial.screenshotUrl;
          changed = true;
        }
        if (dial.imgUrl && !dial.screenshotUrl) {
          dial.screenshotUrl = dial.imgUrl;
          changed = true;
        }
        dial.tileType = 'screenshot';
        dial.type = 'image';
      }
      dial.showText = true;
      dial.showFaviconOnThumb = true;
    });

    // 14. Dissolve any remaining folder clusters (keep all dials on desktop)
    Object.keys(this.cache.dials.byId).forEach(id => {
      const dial = this.cache.dials.byId[id];
      if (!dial) return;

      if (dial.type === 'folder') {
        const folder = this.cache.folders.byId[dial.folderId] || this.cache.folders.byId[this.cache.activeFolderId];
        if (folder) {
          const innerIds = (dial.dialIds || []).filter(innerId => Boolean(this.cache.dials.byId[innerId]));
          const cIdx = folder.dialIds.indexOf(id);
          if (cIdx !== -1) {
            folder.dialIds.splice(cIdx, 1, ...innerIds);
          } else {
            folder.dialIds.push(...innerIds);
          }
        }
        delete this.cache.dials.byId[id];
        this.cache.dials.ids = this.cache.dials.ids.filter(x => x !== id);
        changed = true;
      }
    });

    // Ensure all desktop folder.dialIds are valid existing dials
    Object.keys(this.cache.folders.byId).forEach(fId => {
      const f = this.cache.folders.byId[fId];
      if (f && Array.isArray(f.dialIds)) {
        const initialLen = f.dialIds.length;
        f.dialIds = Array.from(new Set(f.dialIds.filter(dId => Boolean(this.cache.dials.byId[dId]))));
        if (f.dialIds.length !== initialLen) changed = true;
      }
    });

    return changed;
  }

  async getState() {
    if (!this.cache.folders) {
      await this.init();
    }
    return this.cache;
  }

  async persist(changedKeys = null) {
    this.cache.updatedAt = Date.now();
    return new Promise((resolve) => {
      chrome.storage.local.set({
        folders: this.cache.folders,
        dials: this.cache.dials,
        settings: this.cache.settings,
        activeFolderId: this.cache.activeFolderId,
        notepad: this.cache.notepad,
        tombstones: this.cache.tombstones,
        updatedAt: this.cache.updatedAt,
        sd_local_writer: INSTANCE_ID
      }, () => {
        this.notifyListeners(changedKeys || ['folders', 'dials', 'settings', 'activeFolderId']);
        if (!isPopup) {
          this.syncDebounced();
        } else {
          this.syncToChromeStorageSync().catch(() => {});
        }
        resolve();
      });
    });
  }

  async persistNotepad() {
    return new Promise((resolve) => {
      chrome.storage.local.set({
        notepad: this.cache.notepad,
        sd_local_writer: INSTANCE_ID
      }, () => {
        this.notifyListeners(['notepad']);
        if (!isPopup) {
          this.syncDebounced();
        } else {
          this.syncToChromeStorageSync().catch(() => {});
        }
        resolve();
      });
    });
  }

  // Chrome Cloud Sync (seamless automatic sync across all browsers logged into same Google account)
  async syncToChromeStorageSync() {
    try {
      if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.sync) return;

      // Rate limit protection: enforce at least 5 seconds between chrome.storage.sync writes
      const now = Date.now();
      const timeSinceLastWrite = now - (this.lastSyncWriteTime || 0);
      if (timeSinceLastWrite < 5000) {
        if (!this.pendingSyncTimer) {
          this.pendingSyncTimer = setTimeout(() => {
            this.pendingSyncTimer = null;
            this.syncToChromeStorageSync();
          }, 5000 - timeSinceLastWrite);
        }
        return;
      }
      this.lastSyncWriteTime = now;

      // Sanitize dials: strip heavy base64 data URLs (screenshots and uploaded images)
      // High-res screenshots stay preserved in chrome.storage.local (unlimitedStorage)
      const sanitizedDials = {
        byId: {},
        ids: this.cache.dials?.ids ? [...this.cache.dials.ids] : []
      };

      if (this.cache.dials?.byId) {
        for (const [id, dial] of Object.entries(this.cache.dials.byId)) {
          sanitizedDials.byId[id] = {
            ...dial,
            screenshotUrl: dial.screenshotUrl?.startsWith('data:') ? '' : (dial.screenshotUrl || ''),
            imgUrl: dial.imgUrl?.startsWith('data:') ? '' : (dial.imgUrl || ''),
            logoUrl: dial.logoUrl?.startsWith('data:') && dial.logoUrl.length > 50000 ? '' : (dial.logoUrl || '')
          };
        }
      }

      // Sanitize settings: strip custom base64 wallpaper from sync to keep size small
      const sanitizedSettings = { ...this.cache.settings };
      if (sanitizedSettings.background?.url?.startsWith('data:')) {
        sanitizedSettings.background = { ...sanitizedSettings.background, url: '' };
      }
      if (sanitizedSettings.wallpaperUrl?.startsWith('data:')) {
        sanitizedSettings.wallpaperUrl = '';
      }

      const exportData = {
        folders: this.cache.folders,
        dials: sanitizedDials,
        settings: sanitizedSettings,
        activeFolderId: this.cache.activeFolderId,
        notepad: this.cache.notepad,
        tombstones: this.cache.tombstones || { dials: {}, folders: {} },
        updatedAt: Date.now()
      };

      const jsonStr = JSON.stringify(exportData);
      // chrome.storage.sync hard quota is 102,400 bytes total
      if (jsonStr.length > 95000) {
        console.info('SpeedDial: Sync payload exceeds 95KB quota, saved locally only.');
        return;
      }

      const CHUNK_SIZE = 7000;
      const chunkCount = Math.ceil(jsonStr.length / CHUNK_SIZE);

      const payload = {
        sd_sync_count: chunkCount,
        sd_sync_time: Date.now(),
        sd_sync_writer: INSTANCE_ID
      };

      for (let i = 0; i < chunkCount; i++) {
        payload[`sd_sync_chunk_${i}`] = jsonStr.substring(i * CHUNK_SIZE, (i + 1) * CHUNK_SIZE);
      }

      // Remove any stale chunk keys from previous larger syncs
      chrome.storage.sync.get(null, (existing) => {
        const removeKeys = [];
        if (existing) {
          for (const key of Object.keys(existing)) {
            if (key.startsWith('sd_sync_chunk_')) {
              const idx = parseInt(key.replace('sd_sync_chunk_', ''), 10);
              if (idx >= chunkCount) removeKeys.push(key);
            }
          }
        }

        const doSet = () => {
          this.lastSyncSentTime = payload.sd_sync_time;
          chrome.storage.sync.set(payload, () => {
            if (chrome.runtime.lastError) {
              const msg = chrome.runtime.lastError.message || chrome.runtime.lastError;
              if (!msg.includes('MAX_WRITE_OPERATIONS')) {
                console.warn('Chrome storage sync error:', msg);
              }
            }
          });
        };

        if (removeKeys.length > 0) {
          chrome.storage.sync.remove(removeKeys, doSet);
        } else {
          doSet();
        }
      });
    } catch (e) {
      console.warn('Chrome storage sync skipped or failed:', e);
    }
  }

  async loadFromChromeStorageSync() {
    return new Promise((resolve) => {
      if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.sync) {
        return resolve(null);
      }

      chrome.storage.sync.get(null, (syncRes) => {
        if (chrome.runtime.lastError || !syncRes || !syncRes.sd_sync_count) {
          return resolve(null);
        }

        try {
          const count = syncRes.sd_sync_count;
          let fullStr = '';
          for (let i = 0; i < count; i++) {
            if (!syncRes[`sd_sync_chunk_${i}`]) return resolve(null);
            fullStr += syncRes[`sd_sync_chunk_${i}`];
          }

          const parsed = JSON.parse(fullStr);
          if (parsed && parsed.folders && parsed.dials) {
            resolve(parsed);
          } else {
            resolve(null);
          }
        } catch (err) {
          console.warn('Failed to parse sync data:', err);
          resolve(null);
        }
      });
    });
  }

  // Smart Two-Way Merge: merges local state with Google profile cloud state
  // Preserves existing local screenshots, handles adding/deleting desktops and tiles
  async smartSyncChromeProfile({ pushBackToCloud = true } = {}) {
    if (this.isSyncing) return { message: 'Синхронизация уже выполняется' };
    this.isSyncing = true;

    try {
      if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.sync) {
        throw new Error('Служба chrome.storage.sync недоступна');
      }

      const cloudData = await this.loadFromChromeStorageSync();

      // If cloud has no data yet, push our local state to cloud
      if (!cloudData || !cloudData.folders || !cloudData.folders.ids || cloudData.folders.ids.length === 0) {
        await this.syncToChromeStorageSync();
        const screenshotCount = Object.values(this.cache.dials?.byId || {}).filter(d => Boolean(d && (d.screenshotUrl || (d.tileType === 'screenshot' && d.imgUrl)))).length;
        return {
          addedDials: 0,
          removedDials: 0,
          updatedDials: 0,
          preservedScreenshots: screenshotCount,
          totalDials: this.cache.dials?.ids?.length || 0,
          totalFolders: this.cache.folders?.ids?.length || 0
        };
      }

      // Merge tombstones (record of deleted items)
      const localTombstones = this.cache.tombstones || { dials: {}, folders: {} };
      const cloudTombstones = cloudData.tombstones || { dials: {}, folders: {} };
      const mergedTombstones = {
        dials: { ...(localTombstones.dials || {}) },
        folders: { ...(localTombstones.folders || {}) }
      };
      for (const [id, time] of Object.entries(cloudTombstones.dials || {})) {
        mergedTombstones.dials[id] = Math.max(mergedTombstones.dials[id] || 0, time);
      }
      for (const [id, time] of Object.entries(cloudTombstones.folders || {})) {
        mergedTombstones.folders[id] = Math.max(mergedTombstones.folders[id] || 0, time);
      }

      // Purge tombstones older than 30 days
      const monthAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;
      for (const [id, time] of Object.entries(mergedTombstones.dials)) {
        if (time < monthAgo) delete mergedTombstones.dials[id];
      }
      for (const [id, time] of Object.entries(mergedTombstones.folders)) {
        if (time < monthAgo) delete mergedTombstones.folders[id];
      }

      let addedDialsCount = 0;
      let removedDialsCount = 0;
      let updatedDialsCount = 0;
      let preservedScreenshotsCount = 0;

      // 1. Merge Folders (Desktops)
      const mergedFolders = { byId: {}, ids: [] };
      const allFolderIds = Array.from(new Set([
        ...(this.cache.folders?.ids || []),
        ...(cloudData.folders?.ids || [])
      ]));

      for (const fId of allFolderIds) {
        const localF = this.cache.folders?.byId?.[fId];
        const cloudF = cloudData.folders?.byId?.[fId];
        const deletedAt = mergedTombstones.folders[fId];

        if (deletedAt) {
          const localUpdated = localF?.updatedAt || 0;
          const cloudUpdated = cloudF?.updatedAt || 0;
          if (localUpdated <= deletedAt && cloudUpdated <= deletedAt) {
            // Folder was deleted on one device
            continue;
          }
        }

        if (localF && cloudF) {
          const base = (cloudF.updatedAt || 0) > (localF.updatedAt || 0) ? cloudF : localF;
          const mergedDialIds = Array.from(new Set([...(localF.dialIds || []), ...(cloudF.dialIds || [])]));
          mergedFolders.byId[fId] = {
            ...base,
            dialIds: mergedDialIds
          };
          mergedFolders.ids.push(fId);
        } else if (localF) {
          mergedFolders.byId[fId] = { ...localF };
          mergedFolders.ids.push(fId);
        } else if (cloudF) {
          mergedFolders.byId[fId] = { ...cloudF };
          mergedFolders.ids.push(fId);
        }
      }

      if (mergedFolders.ids.length === 0) {
        const defId = defaultFolders.ids[0];
        mergedFolders.ids.push(defId);
        mergedFolders.byId[defId] = { ...defaultFolders.byId[defId] };
      }

      // 2. Merge Dials (Tiles) - CRITICAL: Preserve Screenshots
      const mergedDials = { byId: {}, ids: [] };
      const allDialIds = Array.from(new Set([
        ...(this.cache.dials?.ids || []),
        ...(cloudData.dials?.ids || [])
      ]));

      for (const dId of allDialIds) {
        const localD = this.cache.dials?.byId?.[dId];
        const cloudD = cloudData.dials?.byId?.[dId];
        const deletedAt = mergedTombstones.dials[dId];

        if (deletedAt) {
          const localUpdated = localD?.updatedAt || 0;
          const cloudUpdated = cloudD?.updatedAt || 0;
          if (localUpdated <= deletedAt && cloudUpdated <= deletedAt) {
            removedDialsCount++;
            continue;
          }
        }

        if (localD && cloudD) {
          const cloudIsNewer = (cloudD.updatedAt || 0) > (localD.updatedAt || 0);
          const base = cloudIsNewer ? { ...cloudD } : { ...localD };

          // SCREENSHOT PRESERVATION: Local high-res screenshot NEVER gets erased
          const localScreenshot = localD.screenshotUrl || localD.imgUrl || '';
          const localHasScreenshot = Boolean(localScreenshot && (localD.tileType === 'screenshot' || localScreenshot.startsWith('data:') || localScreenshot.startsWith('blob:') || localScreenshot.startsWith('http')));

          if (localHasScreenshot) {
            base.screenshotUrl = localScreenshot;
            base.imgUrl = localScreenshot;
            base.tileType = 'screenshot';
            base.type = 'image';
            preservedScreenshotsCount++;
          } else if (cloudD.screenshotUrl) {
            base.screenshotUrl = cloudD.screenshotUrl;
            base.imgUrl = cloudD.imgUrl || cloudD.screenshotUrl;
          }

          mergedDials.byId[dId] = base;
          mergedDials.ids.push(dId);
          updatedDialsCount++;
        } else if (localD) {
          mergedDials.byId[dId] = { ...localD };
          mergedDials.ids.push(dId);
          if (localD.screenshotUrl || (localD.tileType === 'screenshot' && localD.imgUrl)) {
            preservedScreenshotsCount++;
          }
        } else if (cloudD) {
          const newDial = { ...cloudD };
          // Check if local cache had another dial with the same URL and a screenshot
          const matchSameUrl = Object.values(this.cache.dials?.byId || {}).find(x => x && x.url === cloudD.url && (x.screenshotUrl || x.imgUrl));
          if (matchSameUrl) {
            const sc = matchSameUrl.screenshotUrl || matchSameUrl.imgUrl;
            newDial.screenshotUrl = sc;
            newDial.imgUrl = sc;
            newDial.tileType = 'screenshot';
            newDial.type = 'image';
            preservedScreenshotsCount++;
          }
          mergedDials.byId[dId] = newDial;
          mergedDials.ids.push(dId);
          addedDialsCount++;
        }
      }

      // 3. Reconcile folder dialIds and dial folderIds
      // 3. Reconcile folder dialIds and dial folderIds
      const firstFolderId = mergedFolders.ids[0];

      // Dissolve any legacy folder clusters in merged dials
      for (const dId of [...mergedDials.ids]) {
        const d = mergedDials.byId[dId];
        if (d && d.type === 'folder') {
          const folder = mergedFolders.byId[d.folderId] || mergedFolders.byId[firstFolderId];
          if (folder) {
            const innerIds = (d.dialIds || []).filter(innerId => Boolean(mergedDials.byId[innerId]));
            const cIdx = folder.dialIds.indexOf(dId);
            if (cIdx !== -1) {
              folder.dialIds.splice(cIdx, 1, ...innerIds);
            } else {
              folder.dialIds.push(...innerIds);
            }
          }
          delete mergedDials.byId[dId];
          mergedDials.ids = mergedDials.ids.filter(x => x !== dId);
        }
      }

      const validDialIdsSet = new Set(mergedDials.ids);
      for (const fId of mergedFolders.ids) {
        const folder = mergedFolders.byId[fId];
        if (folder) {
          folder.dialIds = Array.from(new Set((folder.dialIds || []).filter(dId => validDialIdsSet.has(dId))));
        }
      }

      for (const dId of mergedDials.ids) {
        const dial = mergedDials.byId[dId];
        if (!dial.folderId || !mergedFolders.byId[dial.folderId]) {
          dial.folderId = firstFolderId;
        }
        const targetFolder = mergedFolders.byId[dial.folderId];
        if (targetFolder && !targetFolder.dialIds.includes(dId)) {
          targetFolder.dialIds.push(dId);
        }
      }

      // 4. Merge Settings: Keep display & screen resolution settings LOCAL to each device!
      // (Different monitors, laptops vs 4K desktops maintain their own ideal tile size and wallpaper)
      const localSettings = this.cache.settings || {};
      const cloudSettings = cloudData.settings || {};
      const mergedSettings = {
        ...cloudSettings,
        ...localSettings
      };

      const DEVICE_SPECIFIC_KEYS = [
        'dialWidth',
        'dialHeight',
        'dialSize',
        'dialSpacing',
        'tilesFontSize',
        'columns',
        'background',
        'wallpaperUrl'
      ];
      DEVICE_SPECIFIC_KEYS.forEach(key => {
        if (localSettings[key] !== undefined) {
          mergedSettings[key] = localSettings[key];
        }
      });

      // 4.5. Merge Notepad
      if (cloudData.notepad) {
        this.cache.notepad = {
          ...(this.cache.notepad || defaultNotepad),
          ...cloudData.notepad,
          globalNotes: cloudData.notepad.globalNotes || this.cache.notepad?.globalNotes,
          localNotes: { ...(this.cache.notepad?.localNotes || {}), ...(cloudData.notepad.localNotes || {}) }
        };
      }

      // 5. Update Cache
      this.cache.folders = mergedFolders;
      this.cache.dials = mergedDials;
      this.cache.settings = mergedSettings;
      this.cache.tombstones = mergedTombstones;
      this.cache.updatedAt = Date.now();

      // 6. Save to local storage
      await new Promise((resolve) => {
        chrome.storage.local.set({
          folders: this.cache.folders,
          dials: this.cache.dials,
          settings: this.cache.settings,
          activeFolderId: this.cache.activeFolderId,
          notepad: this.cache.notepad,
          tombstones: this.cache.tombstones,
          updatedAt: this.cache.updatedAt
        }, resolve);
      });

      // 7. Push merged state back to cloud ONLY when explicitly requested (e.g. manual user button)
      // When reacting to cloud changes, pushBackToCloud is false to prevent echo loops
      if (pushBackToCloud && !isPopup) {
        await this.syncToChromeStorageSync();
      }

      this.notifyListeners();

      return {
        addedDials: addedDialsCount,
        removedDials: removedDialsCount,
        updatedDials: updatedDialsCount,
        preservedScreenshots: preservedScreenshotsCount,
        totalDials: mergedDials.ids.length,
        totalFolders: mergedFolders.ids.length
      };
    } finally {
      this.isSyncing = false;
    }
  }

  async setActiveFolderId(id) {
    if (this.cache.folders.byId[id]) {
      this.cache.activeFolderId = id;
      await this.persist();
    }
  }

  // --- Folder / Desktop operations ---
  async addFolder(name, icon = 'folder') {
    const id = generateId();
    const order = this.cache.folders.ids.length;
    const newFolder = {
      id,
      name: name.trim() || 'Новый стол',
      icon: icon || 'folder',
      order,
      dialIds: [],
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    this.cache.folders.byId[id] = newFolder;
    this.cache.folders.ids.push(id);
    this.cache.activeFolderId = id;
    await this.persist();
    return newFolder;
  }

  async updateFolder(id, { name, icon }) {
    const f = this.cache.folders.byId[id];
    if (!f) return;
    if (name !== undefined) f.name = name.trim();
    if (icon !== undefined) f.icon = icon;
    f.updatedAt = Date.now();
    await this.persist();
  }

  async deleteFolder(id) {
    if (this.cache.folders.ids.length <= 1) {
      throw new Error('Нельзя удалить единственный рабочий стол');
    }
    const folder = this.cache.folders.byId[id];
    if (!folder) return;

    this.cache.tombstones = this.cache.tombstones || { dials: {}, folders: {} };
    this.cache.tombstones.folders[id] = Date.now();

    // Delete contained dials
    (folder.dialIds || []).forEach(dId => {
      this.cache.tombstones.dials[dId] = Date.now();
      delete this.cache.dials.byId[dId];
      this.cache.dials.ids = this.cache.dials.ids.filter(x => x !== dId);
    });

    delete this.cache.folders.byId[id];
    this.cache.folders.ids = this.cache.folders.ids.filter(x => x !== id);

    if (this.cache.activeFolderId === id) {
      this.cache.activeFolderId = this.cache.folders.ids[0];
    }
    await this.persist();
  }

  async reorderFolders(newIds) {
    this.cache.folders.ids = newIds;
    newIds.forEach((id, idx) => {
      if (this.cache.folders.byId[id]) {
        this.cache.folders.byId[id].order = idx;
      }
    });
    await this.persist();
  }

  // --- Dial operations ---
  async addDial(dialData) {
    const id = dialData.id || generateId();
    const folderId = dialData.folderId || this.cache.activeFolderId;
    const folder = this.cache.folders.byId[folderId] || this.cache.folders.byId[this.cache.folders.ids[0]];

    let bgcolor = dialData.bgcolor;
    let textColor = dialData.textColor;

    if (!bgcolor || bgcolor === '#ffffff' || bgcolor === '#fff' || bgcolor === '#2d2d2d') {
      const brand = getBrandColorForUrl(dialData.url, dialData.name);
      if (brand) {
        bgcolor = brand.bgcolor;
        textColor = brand.textColor || getContrastTextColor(bgcolor);
      } else if (!bgcolor || bgcolor === '#ffffff' || bgcolor === '#fff') {
        const letterInfo = getLetterBadgeInfo(dialData.name, dialData.url);
        bgcolor = letterInfo.bgColor;
        textColor = '#ffffff';
      }
    }
    if (!textColor) {
      textColor = getContrastTextColor(bgcolor || '#2d2d2d');
    }

    const newDial = {
      id,
      folderId: folder.id,
      name: dialData.name || 'Сайт',
      url: dialData.url || '',
      bgcolor: bgcolor || '#2d2d2d',
      textColor: textColor || '#ffffff',
      fontSize: dialData.fontSize || 16,
      textAlign: dialData.textAlign || 'center',
      type: dialData.type || 'gen', // 'gen' or 'image'
      tileType: dialData.tileType || (dialData.screenshotUrl ? 'screenshot' : 'logo'),
      screenshotUrl: dialData.screenshotUrl || dialData.imgUrl || '',
      imgUrl: dialData.imgUrl || dialData.screenshotUrl || '',
      logoUrl: dialData.logoUrl || '',
      faviconUrl: dialData.faviconUrl || '',
      noFavicon: Boolean(dialData.noFavicon),
      showText: dialData.showText !== false,
      showFaviconOnThumb: dialData.showFaviconOnThumb !== false,
      groupId: dialData.groupId || null,
      isWide: false,
      isRow: false,
      order: folder.dialIds.length,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };

    this.cache.dials.byId[id] = newDial;
    if (!this.cache.dials.ids.includes(id)) {
      this.cache.dials.ids.push(id);
    }
    if (!folder.dialIds.includes(id)) {
      folder.dialIds.push(id);
    }

    await this.persist();
    return newDial;
  }

  async updateDial(dialData) {
    const existing = this.cache.dials.byId[dialData.id];
    if (!existing) return;

    // Check if moved to a different folder
    if (dialData.folderId && dialData.folderId !== existing.folderId) {
      const oldFolder = this.cache.folders.byId[existing.folderId];
      const newFolder = this.cache.folders.byId[dialData.folderId];
      if (oldFolder) {
        oldFolder.dialIds = oldFolder.dialIds.filter(id => id !== existing.id);
      }
      if (newFolder && !newFolder.dialIds.includes(existing.id)) {
        newFolder.dialIds.push(existing.id);
      }
    }

    Object.assign(existing, dialData, { updatedAt: Date.now() });
    await this.persist();
  }

  async deleteDial(id) {
    const dial = this.cache.dials.byId[id];
    if (!dial) return;

    this.cache.tombstones = this.cache.tombstones || { dials: {}, folders: {} };
    this.cache.tombstones.dials[id] = Date.now();

    const folder = this.cache.folders.byId[dial.folderId];
    if (folder) {
      folder.dialIds = folder.dialIds.filter(x => x !== id);
    }

    delete this.cache.dials.byId[id];
    this.cache.dials.ids = this.cache.dials.ids.filter(x => x !== id);

    await this.persist();
  }

  async togglePinDial(dialId) {
    const dial = this.cache.dials.byId[dialId];
    if (!dial) return false;
    dial.isPinned = !dial.isPinned;
    dial.updatedAt = Date.now();
    await this.persist();
    return dial.isPinned;
  }

  async moveDialInFolder(folderId, fromIndex, toIndex) {
    const folder = this.cache.folders.byId[folderId];
    if (!folder || !folder.dialIds) return;
    if (fromIndex === toIndex || fromIndex < 0 || toIndex < 0) return;

    const dialIds = [...folder.dialIds];
    const fromId = dialIds[fromIndex];
    const toId = dialIds[toIndex];
    if (!fromId || !toId) return;

    const fromDial = this.cache.dials.byId[fromId];
    const toDial = this.cache.dials.byId[toId];

    // Cannot move a pinned dial or drop directly onto a pinned slot
    if (fromDial?.isPinned || toDial?.isPinned) {
      return;
    }

    // Map pinned slots that must stay fixed at their indices
    const pinnedSlots = new Map();
    dialIds.forEach((id, idx) => {
      if (this.cache.dials.byId[id]?.isPinned) {
        pinnedSlots.set(idx, id);
      }
    });

    // Extract unpinned sequence
    const unpinned = dialIds.filter((id, idx) => !pinnedSlots.has(idx));
    const oldUnpinnedIdx = unpinned.indexOf(fromId);
    const targetUnpinnedIdx = unpinned.indexOf(toId);

    if (oldUnpinnedIdx !== -1 && targetUnpinnedIdx !== -1) {
      unpinned.splice(oldUnpinnedIdx, 1);
      unpinned.splice(targetUnpinnedIdx, 0, fromId);

      // Reconstruct dialIds keeping pinned slots untouched
      const newDialIds = [];
      let unpinnedIdx = 0;
      for (let i = 0; i < dialIds.length; i++) {
        if (pinnedSlots.has(i)) {
          newDialIds.push(pinnedSlots.get(i));
        } else {
          newDialIds.push(unpinned[unpinnedIdx++]);
        }
      }
      folder.dialIds = newDialIds;
      await this.persist();
    }
  }

  async moveDialToFolder(dialId, targetFolderId) {
    const dial = this.cache.dials.byId[dialId];
    const targetFolder = this.cache.folders.byId[targetFolderId];
    if (!dial || !targetFolder || dial.folderId === targetFolderId) return;

    const sourceFolder = this.cache.folders.byId[dial.folderId];
    if (sourceFolder) {
      sourceFolder.dialIds = sourceFolder.dialIds.filter(id => id !== dialId);
    }

    dial.folderId = targetFolderId;
    dial.updatedAt = Date.now();
    targetFolder.dialIds.push(dialId);

    await this.persist();
  }



  // --- Tile Widgets (Виджеты-плитки: Часы, Погода, Курсы, Заметка) ---
  async addWidgetDial(folderId, widgetType, widgetSize = '1x1', config = {}) {
    const id = generateId();
    const folder = this.cache.folders.byId[folderId] || this.cache.folders.byId[this.cache.folders.ids[0]];

    const titles = {
      clock: 'Часы',
      weather: 'Погода',
      rates: 'Курсы валют',
      note: 'Блокнот'
    };

    const newDial = {
      id,
      folderId: folder.id,
      name: titles[widgetType] || 'Виджет',
      type: 'widget',
      widgetType,
      widgetSize: widgetSize || (widgetType === 'note' ? '2x1' : '1x1'),
      widgetConfig: {
        ...config,
        ...(widgetType === 'clock' && { timezone: 'auto', is24Hour: true, showSeconds: true }),
        ...(widgetType === 'weather' && { city: 'Москва', units: 'c' }),
        ...(widgetType === 'note' && {
          color: config.color || 'amber',
          syncScope: config.syncScope || 'independent',
          mode: config.mode || 'todos',
          fontSize: config.fontSize || 'normal',
          text: config.text !== undefined ? config.text : '',
          todos: config.todos !== undefined ? config.todos : []
        })
      },
      createdAt: Date.now(),
      updatedAt: Date.now()
    };

    this.cache.dials.byId[id] = newDial;
    if (!this.cache.dials.ids.includes(id)) {
      this.cache.dials.ids.push(id);
    }
    if (!folder.dialIds.includes(id)) {
      folder.dialIds.push(id);
    }

    await this.persist();
    return newDial;
  }

  async updateWidgetDial(dialId, config = {}, size = null, silent = false, isPinned = undefined) {
    const dial = this.cache.dials.byId[dialId];
    if (!dial || dial.type !== 'widget') return;

    if (config) {
      dial.widgetConfig = { ...(dial.widgetConfig || {}), ...config };
    }
    if (size) {
      dial.widgetSize = size;
    }
    if (isPinned !== undefined) {
      dial.isPinned = !!isPinned;
    }
    dial.updatedAt = Date.now();
    await this.persist(silent ? ['widget-silent'] : null);
  }

  async updateWidgetNoteText(dialId, text, isGlobal = true) {
    const dial = this.cache.dials.byId[dialId];
    if (!dial || dial.widgetType !== 'note') return;

    if (!dial.widgetConfig) dial.widgetConfig = {};
    dial.widgetConfig.text = text;

    if (isGlobal) {
      const notepad = this.getNotepad();
      if (!notepad.globalNotes) notepad.globalNotes = { text: '', todos: [] };
      notepad.globalNotes.text = text;
      notepad.updatedAt = Date.now();
    }

    dial.updatedAt = Date.now();
    await this.persist();
  }

  // --- Settings ---
  async updateSettings(newSettings) {
    this.cache.settings = { ...this.cache.settings, ...newSettings };
    await this.persist();
  }

  // --- Export / Import ---
  exportBackup() {
    return {
      version: (typeof chrome !== 'undefined' && chrome.runtime?.getManifest?.()?.version) || '6.4.0',
      exportedAt: new Date().toISOString(),
      folders: this.cache.folders,
      dials: this.cache.dials,
      settings: this.cache.settings,
      activeFolderId: this.cache.activeFolderId
    };
  }

  async importBackup(data, { preserveScreenshots = true } = {}) {
    if (!data) throw new Error('Данные резервной копии пусты');

    // Handle TabMark legacy .tbm format: { store: { dials, folders, settings } }
    if (data.store) {
      data = data.store;
    }

    if (!data.folders || !data.dials) {
      throw new Error('Некорректная структура файла резервной копии');
    }

    // Preserve local screenshots
    if (preserveScreenshots && this.cache.dials?.byId && data.dials?.byId) {
      for (const [id, dial] of Object.entries(data.dials.byId)) {
        const localDial = this.cache.dials.byId[id] || Object.values(this.cache.dials.byId).find(d => d && d.url === dial.url && (d.screenshotUrl || d.imgUrl));
        if (localDial) {
          const sc = localDial.screenshotUrl || localDial.imgUrl;
          if (sc && !dial.screenshotUrl) {
            dial.screenshotUrl = sc;
            dial.imgUrl = sc;
            dial.tileType = 'screenshot';
            dial.type = 'image';
          }
        }
      }
    }

    this.cache.folders = data.folders;
    this.cache.dials = data.dials;
    if (data.settings) {
      this.cache.settings = { ...this.cache.settings, ...data.settings };
    }
    if (data.activeFolderId && this.cache.folders.byId[data.activeFolderId]) {
      this.cache.activeFolderId = data.activeFolderId;
    } else {
      this.cache.activeFolderId = this.cache.folders.ids[0] || '1';
    }

    await this.persist();
    return true;
  }

  async restoreDefaultSeed() {
    this.cache.folders = JSON.parse(JSON.stringify(defaultFolders));
    this.cache.dials = JSON.parse(JSON.stringify(defaultDials));
    this.cache.settings = JSON.parse(JSON.stringify(defaultSettings));
    this.cache.activeFolderId = this.cache.folders.ids[0] || '1';
    await this.persist();
  }

  // --- Notepad operations ---
  getNotepad() {
    return this.cache.notepad || defaultNotepad;
  }

  async updateNotepad(updates) {
    this.cache.notepad = {
      ...(this.cache.notepad || defaultNotepad),
      ...updates
    };
    await this.persistNotepad();
    return this.cache.notepad;
  }

  // --- Group operations on Desktop ---
  async addGroup(folderId, { name, color = '#0078d7' }) {
    const folder = this.cache.folders.byId[folderId];
    if (!folder) return null;
    if (!folder.groups) folder.groups = [];
    const id = 'grp_' + Date.now().toString(36) + '_' + Math.random().toString(36).substring(2, 6);
    const newGroup = {
      id,
      name: name?.trim() || 'Новая группа',
      color: color || '#0078d7',
      collapsed: false
    };
    folder.groups.push(newGroup);
    folder.updatedAt = Date.now();
    await this.persist();
    return newGroup;
  }

  async updateGroup(folderId, groupId, updates) {
    const folder = this.cache.folders.byId[folderId];
    if (!folder || !folder.groups) return;
    const group = folder.groups.find(g => g.id === groupId);
    if (!group) return;
    if (updates.name !== undefined) group.name = updates.name.trim();
    if (updates.color !== undefined) group.color = updates.color;
    if (updates.collapsed !== undefined) group.collapsed = Boolean(updates.collapsed);
    folder.updatedAt = Date.now();
    await this.persist();
  }

  async deleteGroup(folderId, groupId) {
    const folder = this.cache.folders.byId[folderId];
    if (!folder || !folder.groups) return;
    folder.groups = folder.groups.filter(g => g.id !== groupId);
    // Unlink dials that were in this group
    (folder.dialIds || []).forEach(dId => {
      const dial = this.cache.dials.byId[dId];
      if (dial && dial.groupId === groupId) {
        dial.groupId = null;
      }
    });
    folder.updatedAt = Date.now();
    await this.persist();
  }

  async setDialGroup(dialId, groupId) {
    const dial = this.cache.dials.byId[dialId];
    if (!dial) return;
    dial.groupId = groupId || null;
    dial.updatedAt = Date.now();
    await this.persist();
  }

  onStateChange(cb) {
    this.listeners.add(cb);
    return () => this.listeners.delete(cb);
  }

  notifyListeners(changedKeys = null) {
    for (const listener of this.listeners) {
      try {
        listener(this.cache, changedKeys);
      } catch (e) {
        console.error('Error in state listener:', e);
      }
    }
  }
}

export const storage = new StorageManager();
