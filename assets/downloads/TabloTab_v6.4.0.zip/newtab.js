// Speed Dial Main Logic (MV3)
import { storage } from './js/storage.js';
import { ICONS, getIconSvg } from './js/icons.js';
import { getFaviconUrl, getContrastTextColor, hexToRgba, sanitizeUrl, downloadJsonFile, readJsonFile, extractDomain, resizeScreenshot, getLetterBadgeInfo, checkFaviconValid, isKnownBadFavicon, isKnownValidFavicon, markBadFavicon, isInternalOrNewTabUrl, resolveTheme, getBrandColorForUrl, extractDominantColorFromImage, generateId, debounce } from './js/utils.js';
import { gdriveSync } from './js/gdrive.js';
import { t, initI18n, applyI18n, getLanguage } from './js/i18n.js';

let state = null;
let activeContextMenu = null;
let targetDial = null;
let targetFolder = null;
let targetGroup = null;
let targetGroupFolderId = null;
let editingDialId = null;
let editingFolderId = null;
let editingGroupId = null;
let editingGroupFolderId = null;
let draggedDialIndex = null;
let draggedFolderIndex = null;
let modalCurrentTileType = 'screenshot';
let modalCurrentScreenshot = '';
let draggedDialType = null;

const ICON_LOCKED = `<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>`;
const ICON_UNLOCKED = `<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 9.9-1"></path></svg>`;

// Search engine configs with crisp vector SVGs
const SEARCH_ENGINES = {
  yandex: {
    name: 'Яндекс',
    iconSvg: `<svg viewBox="0 0 24 24" width="16" height="16"><circle cx="12" cy="12" r="11" fill="#FC3F1D"/><path fill="#FFFFFF" d="M13.8 18.5h-2.1v-6.2L8.9 6.2h2.2l1.7 4.5 1.7-4.5h2.2l-2.8 6.1v6.2z"/></svg>`,
    url: 'https://yandex.ru/search/?text='
  },
  google: {
    name: 'Google',
    iconSvg: `<svg viewBox="0 0 24 24" width="16" height="16"><path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"/><path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"/><path fill="#FBBC05" d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.17 0 9.98 0 12s.45 3.83 1.25 5.42l4.03-3.15z"/><path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"/></svg>`,
    url: 'https://www.google.com/search?q='
  },
  duckduckgo: {
    name: 'DuckDuckGo',
    iconSvg: `<svg viewBox="0 0 24 24" width="16" height="16"><circle cx="12" cy="12" r="11" fill="#DE5833"/><path fill="#FFFFFF" d="M12 5.5c-2.8 0-4.5 1.8-4.5 3.8 0 1.5.9 2.5 1.8 3.1-.2.4-.5.9-.9 1.3-.2.2-.1.5.2.5 1.1 0 2.2-.6 2.8-1.3.2 0 .4.1.6.1 2.8 0 4.5-1.8 4.5-3.8 0-2.1-1.7-3.7-4.5-3.7zm-1.8 3.2c-.4 0-.7-.3-.7-.7s.3-.7.7-.7.7.3.7.7-.3.7-.7.7zm3.6 0c-.4 0-.7-.3-.7-.7s.3-.7.7-.7.7.3.7.7-.3.7-.7.7z"/></svg>`,
    url: 'https://duckduckgo.com/?q='
  },
  bing: {
    name: 'Bing',
    iconSvg: `<svg viewBox="0 0 24 24" width="16" height="16"><path fill="#00809D" d="M5 3v18l5.5-3.2 4.8 2.2 4.7-6.5-6.5-2.5V8.5L8.2 6.8 5 3zm4.5 5.5l2.5 1.1v4.8l-2.5 1.4V8.5z"/></svg>`,
    url: 'https://www.bing.com/search?q='
  },
  youtube: {
    name: 'YouTube',
    iconSvg: `<svg viewBox="0 0 24 24" width="16" height="16"><path fill="#FF0000" d="M23.5 6.2c-.3-1-.9-1.8-1.9-2.1C19.9 3.5 12 3.5 12 3.5s-7.9 0-9.6.6c-1 .3-1.6 1.1-1.9 2.1C0 7.9 0 12 0 12s0 4.1.5 5.8c.3 1 .9 1.8 1.9 2.1 1.7.6 9.6.6 9.6.6s7.9 0 9.6-.6c1-.3 1.6-1.1 1.9-2.1.5-1.7.5-5.8.5-5.8s0-4.1-.5-5.8z"/><polygon fill="#FFFFFF" points="9.6,15.6 15.8,12 9.6,8.4"/></svg>`,
    url: 'https://www.youtube.com/results?search_query='
  }
};
let currentSearchEngine = 'google';

// ========================================================
// INITIALIZATION
// ========================================================
document.addEventListener('DOMContentLoaded', async () => {
  state = await storage.init();

  initI18n(state.settings?.language || 'auto');
  applyI18n();

  applySettings();
  renderDesktops();
  renderDials();
  renderNotepad();
  initDeskSearch();
  setupEventListeners();

  // Storage change listener
  storage.onStateChange((newState, changedKeys) => {
    state = newState;
    if (changedKeys && Array.isArray(changedKeys) && changedKeys.length > 0) {
      const isSilentOnly = changedKeys.every(k => k === 'notepad' || k === 'widget-silent' || k === 'updatedAt');
      if (isSilentOnly) {
        return;
      }
    }
    initI18n(state.settings?.language || 'auto');
    applyI18n();
    applySettings();
    renderDesktops();
    renderDials();
  });

  // Listen to messages from extension popup
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (msg.action === 'openSettingsModal') {
        openSettingsModal();
        sendResponse({ success: true });
      } else if (msg.action === 'openAddDialModal') {
        openAddDialModal();
        sendResponse({ success: true });
      } else if (msg.action === 'switchDesktop') {
        if (msg.folderId && state.folders.byId[msg.folderId]) {
          state.activeFolderId = msg.folderId;
          renderDesktops();
          renderDials();
          renderNotepad();
        }
        sendResponse({ success: true });
      } else if (msg.action === 'themeChanged' || msg.action === 'styleChanged' || msg.action === 'settingsUpdated') {
        storage.getState().then(st => {
          state = st;
          applySettings();
          renderDials();
          renderDesktops();
          renderNotepad();
        });
        sendResponse({ success: true });
      }
      return true;
    });
  }

  // Open actions if URL contains parameters
  try {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('openSettings') === 'true') {
      openSettingsModal();
    } else if (urlParams.get('openAddDial') === 'true') {
      openAddDialModal();
    }
  } catch (e) {}
});

// ========================================================
// SETTINGS & APPEARANCE
// ========================================================
function applySettings() {
  const root = document.documentElement;
  const cfg = state.settings || {};

  // Resolve and apply light / dark / system theme
  const themeSetting = cfg.theme || 'system';
  const resolvedTheme = resolveTheme(themeSetting);
  root.setAttribute('data-theme', resolvedTheme);
  const isDark = resolvedTheme === 'dark';

  // Apply visual style (Windows 11 vs Windows 10)
  const currentStyle = cfg.style || 'w11';
  root.setAttribute('data-style', currentStyle);

  // Tile dimensions (Strictly square tiles)
  const dialSize = Math.max(180, cfg.dialSize || cfg.dialWidth || 180);
  const dialSpacing = cfg.dialSpacing !== undefined ? cfg.dialSpacing : 6;
  root.style.setProperty('--dial-size', dialSize + 'px');
  root.style.setProperty('--dial-spacing', dialSpacing + 'px');

  // Tile font size setting
  const tilesFontSize = cfg.tilesFontSize || 'normal';
  document.body.classList.remove('tiles-font-normal', 'tiles-font-large', 'tiles-font-huge');
  document.body.classList.add(`tiles-font-${tilesFontSize}`);

  // Wallpaper / Background mode
  const bg = cfg.background || {};
  const overlay = document.getElementById('wallpaperOverlay');
  if (bg.type === 'color' || !bg.url) {
    document.body.style.backgroundImage = 'none';
    if (bg.color && bg.color !== '#0f1015' && bg.color !== '#181818') {
      document.body.style.backgroundColor = bg.color;
    } else {
      document.body.style.backgroundColor = isDark ? '#181818' : '#f3f3f3';
    }
    if (overlay) {
      overlay.style.background = 'transparent';
      overlay.style.backdropFilter = 'none';
    }
  } else {
    document.body.style.backgroundImage = `url("${bg.url}")`;
    document.body.style.backgroundColor = isDark ? '#000000' : '#f3f3f3';
    if (overlay) {
      const opacity = (bg.overlayOpacity !== undefined ? bg.overlayOpacity : 0.15);
      overlay.style.background = isDark ? `rgba(0, 0, 0, ${opacity})` : `rgba(255, 255, 255, ${opacity})`;
      overlay.style.backdropFilter = bg.blur ? `blur(${bg.blur}px)` : 'none';
    }
  }

  // Searchbar visibility
  const searchBar = document.getElementById('searchBar');
  if (searchBar) {
    const isVisible = cfg.showSearchbar !== false;
    searchBar.style.display = isVisible ? 'flex' : 'none';
    try {
      localStorage.setItem('sd_pref_hide_search', isVisible ? '0' : '1');
      if (isVisible) {
        document.documentElement.classList.remove('hide-searchbar-initial');
      } else {
        document.documentElement.classList.add('hide-searchbar-initial');
      }
    } catch (e) {}
  }

  // Desk Search Container visibility
  const deskSearchCont = document.getElementById('deskSearchContainer');
  if (deskSearchCont) {
    deskSearchCont.style.display = cfg.showDeskSearch !== false ? 'flex' : 'none';
  }


  // Cloud status icon
  const syncDot = document.getElementById('syncDot');
  if (syncDot) {
    if (cfg.googleDrive?.connected) {
      syncDot.className = 'sync-dot';
      syncDot.title = 'Google Диск подключен';
    } else {
      syncDot.className = 'sync-dot offline';
      syncDot.title = 'Google Диск не подключен';
    }
  }

  // Search engine default
  if (cfg.searchEngine && SEARCH_ENGINES[cfg.searchEngine]) {
    setSearchEngine(cfg.searchEngine);
  } else {
    setSearchEngine('google');
  }
}

// ========================================================
// RENDER DESKTOPS / WORKSPACES
// ========================================================
function renderDesktops() {
  const desktopList = document.getElementById('desktopList');
  if (!desktopList) return;
  desktopList.innerHTML = '';

  const activeId = state.activeFolderId;
  const railTooltip = document.getElementById('desktopRailTooltip');

  state.folders.ids.forEach((fId, index) => {
    const folder = state.folders.byId[fId];
    if (!folder) return;

    const tab = document.createElement('div');
    tab.className = 'tab-btn' + (fId === activeId ? ' open' : '');
    tab.dataset.folderId = fId;
    tab.dataset.index = index;
    tab.draggable = true;
    tab.setAttribute('title', folder.name);

    // SVG Icon
    tab.innerHTML = getIconSvg(folder.icon || 'folder');

    // Floating Tooltip on rail hover
    tab.addEventListener('mouseenter', () => {
      if (railTooltip) {
        railTooltip.textContent = folder.name;
        const rect = tab.getBoundingClientRect();
        railTooltip.style.top = `${rect.top + (rect.height - 24) / 2}px`;
        railTooltip.classList.remove('hidden');
      }
    });
    tab.addEventListener('mouseleave', () => {
      if (railTooltip) railTooltip.classList.add('hidden');
    });

    // Switch Desktop on Click
    tab.addEventListener('click', () => {
      if (railTooltip) railTooltip.classList.add('hidden');
      storage.setActiveFolderId(fId);
      renderNotepad();
    });

    // Right-Click Context Menu
    tab.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (railTooltip) railTooltip.classList.add('hidden');
      showFolderContextMenu(e.clientX, e.clientY, folder);
    });

    // Drag & Drop Desktop Tabs Reordering
    tab.addEventListener('dragstart', (e) => {
      draggedFolderIndex = index;
      e.dataTransfer.setData('text/plain', 'folder:' + fId);
      if (railTooltip) railTooltip.classList.add('hidden');
    });

    tab.addEventListener('dragover', (e) => {
      e.preventDefault();
      tab.style.transform = 'scale(1.08)';
    });

    tab.addEventListener('dragleave', () => {
      tab.style.transform = '';
    });

    tab.addEventListener('drop', async (e) => {
      e.preventDefault();
      tab.style.transform = '';
      if (railTooltip) railTooltip.classList.add('hidden');

      const dragData = e.dataTransfer.getData('text/plain');
      // Case 1: Reordering desktop tabs
      if (dragData.startsWith('folder:')) {
        const sourceIndex = draggedFolderIndex;
        const targetIndex = index;
        if (sourceIndex !== null && sourceIndex !== targetIndex) {
          const newIds = [...state.folders.ids];
          const [moved] = newIds.splice(sourceIndex, 1);
          newIds.splice(targetIndex, 0, moved);
          await storage.reorderFolders(newIds);
        }
      }
      // Case 2: Dropping a dial onto this desktop tab!
      else if (dragData.startsWith('dial:')) {
        const dialId = dragData.replace('dial:', '');
        await storage.moveDialToFolder(dialId, fId);
        showToast(t('toastDialMoved', { name: folder.name }));
      }
    });

    desktopList.appendChild(tab);

    if (fId === activeId) {
      setTimeout(() => {
        tab.scrollIntoView({ block: 'nearest' });
      }, 30);
    }
  });
}

// ========================================================
// ========================================================
// RENDER LOGO HELPER FOR DIALS
// ========================================================
function renderLogoFallback(thumbArea, dial, faviconUrl) {
  const logoWrap = document.createElement('div');
  logoWrap.className = 'dial-logo-wrap';
  const isLight = document.documentElement.getAttribute('data-theme') === 'light';
  let bgColor = dial.bgcolor;

  // Auto-detect brand color if dial has default white/unbranded/missing color
  const brand = getBrandColorForUrl(dial.url, dial.name);
  if (brand && (!bgColor || bgColor === '#fff' || bgColor === '#ffffff' || bgColor === '#2d2d2d')) {
    bgColor = brand.bgcolor;
  } else if (!bgColor) {
    bgColor = '#2d2d2d';
  }

  if (isLight && (bgColor === '#2d2d2d' || bgColor === '#202024' || bgColor === '#181818')) {
    bgColor = '#e6e6e8';
  }
  logoWrap.style.backgroundColor = bgColor;
  logoWrap.style.color = dial.textColor || getContrastTextColor(bgColor);

function getBrandLogoSvg(url) {
  if (!url) return null;
  const domain = (extractDomain(url) || '').toLowerCase();
  const isBrand = (...domains) => domains.some(d => domain === d || domain.endsWith('.' + d));

  if (isBrand('youtube.com', 'youtu.be')) {
    return `<svg viewBox="0 0 24 24" width="46" height="34" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>`;
  }
  if (isBrand('twitch.tv')) {
    return `<svg viewBox="0 0 24 24" width="38" height="38" fill="currentColor"><path d="M11.571 4.714h1.715v5.143H11.57zm4.715 0H18v5.143h-1.714zM6 0L1.714 4.286v15.428h5.143V24l4.286-4.286h3.428L22.286 12V0zm14.571 11.143l-3.428 3.428h-3.429l-3 3v-3H6.857V1.714h13.714z"/></svg>`;
  }
  if (isBrand('instagram.com')) {
    return `<svg viewBox="0 0 24 24" width="42" height="42" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>`;
  }
  if (isBrand('t.me', 'telegram.org')) {
    return `<svg viewBox="0 0 24 24" width="42" height="42" fill="currentColor"><path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.446 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.121l-6.871 4.326-2.962-.924c-.643-.204-.657-.643.136-.953l11.57-4.461c.536-.196 1.006.128.832.942z"/></svg>`;
  }
  if (isBrand('vk.com', 'vkvideo.ru', 'vkplay.ru')) {
    return `<svg viewBox="0 0 24 24" width="42" height="42" fill="currentColor"><path d="M15.073 2H8.927C4.167 2 2 4.167 2 8.927v6.146C2 19.833 4.167 22 8.927 22h6.146C19.833 22 22 19.833 22 15.073V8.927C22 4.167 19.833 2 15.073 2zm3.324 14.595h-1.638c-.62 0-.81-.493-1.928-1.611-.976-.95-1.408-1.074-1.648-1.074-.339 0-.435.097-.435.562v1.528c0 .396-.128.595-1.18.595-1.745 0-3.682-1.059-5.05-3.033-2.062-2.909-2.637-5.097-2.637-5.544 0-.244.097-.472.562-.472h1.638c.418 0 .576.19.736.634.808 2.35 2.164 4.414 2.723 4.414.211 0 .31-.097.31-.628V9.324c-.063-1.127-.658-1.222-.658-1.621 0-.19.16-.381.417-.381h2.571c.35 0 .476.182.476.586v3.17c0 .341.15.457.25.457.21 0 .385-.116.777-.508 1.206-1.352 2.065-3.447 2.065-3.447.112-.244.331-.472.748-.472h1.638c.493 0 .6.248.493.595-.205.955-2.222 3.805-2.32 3.96-.168.27-.234.39 0 .703.167.224.717.7 1.085 1.123 1.348 1.503 2.122 2.766 2.37 3.654.106.377-.074.572-.44.572z"/></svg>`;
  }
  if (isBrand('github.com')) {
    return `<svg viewBox="0 0 24 24" width="40" height="40" fill="currentColor"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0 0 24 12c0-6.63-5.37-12-12-12z"/></svg>`;
  }
  if (isBrand('discord.com', 'discord.gg')) {
    return `<svg viewBox="0 0 24 24" width="42" height="42" fill="currentColor"><path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.929 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.894.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/></svg>`;
  }
  if (isBrand('reddit.com')) {
    return `<svg viewBox="0 0 24 24" width="42" height="42" fill="currentColor"><path d="M12 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0zm5.01 4.744c.688 0 1.25.561 1.25 1.249a1.25 1.25 0 0 1-2.498.056l-2.597-.547-.8 3.747c1.824.07 3.48.632 4.674 1.488.308-.309.73-.491 1.207-.491.968 0 1.754.786 1.754 1.754 0 .716-.435 1.333-1.01 1.614a3.111 3.111 0 0 1 .042.52c0 2.694-3.13 4.87-7.004 4.87-3.874 0-7.004-2.176-7.004-4.87 0-.183.015-.366.043-.534A1.748 1.748 0 0 1 4.028 12c0-.968.786-1.754 1.754-1.754.463 0 .898.196 1.207.49 1.207-.883 2.878-1.43 4.744-1.487l.885-4.182a.342.342 0 0 1 .14-.197.35.35 0 0 1 .238-.042l2.906.617a1.214 1.214 0 0 1 1.108-.701zM9.25 12C8.561 12 8 12.562 8 13.25c0 .687.561 1.248 1.25 1.248.687 0 1.248-.561 1.248-1.249 0-.688-.561-1.249-1.249-1.249zm5.5 0c-.687 0-1.248.561-1.248 1.25 0 .687.561 1.248 1.249 1.248.688 0 1.249-.561 1.249-1.249 0-.687-.562-1.249-1.25-1.249zm-5.466 3.99a.327.327 0 0 0-.231.094.33.33 0 0 0 0 .463c.842.842 2.484.913 2.961.913.477 0 2.105-.056 2.961-.913a.361.361 0 0 0 .029-.463.33.33 0 0 0-.464 0c-.547.533-1.684.73-2.512.73-.828 0-1.979-.196-2.512-.73a.326.326 0 0 0-.232-.095z"/></svg>`;
  }
  if (isBrand('x.com', 'twitter.com')) {
    return `<svg viewBox="0 0 24 24" width="38" height="38" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>`;
  }
  if (isBrand('facebook.com')) {
    return `<svg viewBox="0 0 24 24" width="40" height="40" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>`;
  }
  if (isBrand('steampowered.com', 'steamcommunity.com')) {
    return `<svg viewBox="0 0 24 24" width="40" height="40" fill="currentColor"><path d="M11.979 0C5.678 0 .511 4.86.022 11.037l6.432 2.658c.545-.371 1.203-.59 1.912-.59.063 0 .125.004.188.006l2.861-4.142V8.91c0-2.495 2.028-4.524 4.524-4.524 2.494 0 4.524 2.031 4.524 4.527s-2.03 4.525-4.524 4.525h-.105l-4.076 2.911c0 .052.005.105.005.159 0 1.875-1.515 3.396-3.39 3.396-1.635 0-3.016-1.173-3.331-2.727L.436 15.27C1.862 20.307 6.486 24 11.979 24c6.627 0 12-5.373 12-12s-5.373-12-12-12zm-4.32 16.883l-1.914-.79c.315.658.948 1.134 1.704 1.218l.21-.428zm7.39-11.054c-1.705 0-3.088 1.384-3.088 3.088 0 1.705 1.383 3.088 3.088 3.088 1.704 0 3.088-1.383 3.088-3.088 0-1.704-1.384-3.088-3.088-3.088zm0 4.939c-1.022 0-1.851-.829-1.851-1.851s.829-1.851 1.851-1.851 1.851.829 1.851 1.851-.829 1.851-1.851 1.851z"/></svg>`;
  }
  if (isBrand('google.com', 'google.ru', 'mail.google.com', 'docs.google.com', 'drive.google.com')) {
    return `<svg viewBox="0 0 24 24" width="46" height="46"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" fill="#EA4335"/></svg>`;
  }
  if (isBrand('yandex.ru', 'ya.ru', 'mail.yandex.ru', 'dzen.ru', 'music.yandex.ru', 'disk.yandex.ru')) {
    return `<svg viewBox="0 0 24 24" width="46" height="46"><circle cx="12" cy="12" r="11" fill="#fc3f1d"/><path d="M13.5 6.5h-2.1c-1.8 0-3.2 1.3-3.2 3.1 0 1.4.8 2.5 2 2.9l-2.4 5h2.4l2.2-4.6h.3v4.6h2.1V6.5zm-.8 4.4h-1.2c-.8 0-1.4-.5-1.4-1.2 0-.8.6-1.3 1.4-1.3h1.2v2.5z" fill="#ffffff"/></svg>`;
  }
  if (isBrand('habr.com')) {
    return `<svg viewBox="0 0 24 24" width="42" height="42" fill="currentColor"><path d="M5 4h3.5v6.5h7V4H19v16h-3.5v-7h-7V20H5V4z"/></svg>`;
  }
  if (isBrand('wikipedia.org')) {
    return `<svg viewBox="0 0 24 24" width="44" height="44" fill="currentColor"><path d="M12.09 13.01l1.83-5.93h1.84l-3.24 9.17h-1.38L8.62 9.77l-2.5 6.48H4.75L1.5 7.08h1.86l2.12 6.22 2.18-6.22h1.63l2.8 6.15zm8.91-5.93l-3.32 9.17h-1.46l2.45-6.57-2.31-2.6h1.96l1.24 1.54 1.25-1.54h1.69z"/></svg>`;
  }
  if (isBrand('aliexpress.com', 'aliexpress.ru')) {
    return `<svg viewBox="0 0 24 24" width="42" height="42" fill="currentColor"><path d="M19 6h-2c0-2.76-2.24-5-5-5S7 3.24 7 6H5c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-7-3c1.66 0 3 1.34 3 3H9c0-1.66 1.34-3 3-3zm7 17H5V8h14v12zm-7-8c-1.66 0-3-1.34-3-3H7c0 2.76 2.24 5 5 5s5-2.24 5-5h-2c0 1.66-1.34 3-3 3z"/></svg>`;
  }
  if (isBrand('chatgpt.com', 'openai.com')) {
    return `<svg viewBox="0 0 24 24" width="44" height="44" fill="currentColor"><path d="M22.282 9.821a5.985 5.985 0 0 0-.516-4.91 6.046 6.046 0 0 0-6.51-2.9A6.065 6.065 0 0 0 4.981 4.18a5.985 5.985 0 0 0-3.998 2.9 6.046 6.046 0 0 0 .743 7.097 5.98 5.98 0 0 0 .51 4.911 6.051 6.051 0 0 0 6.515 2.9A5.985 5.985 0 0 0 13.26 24a6.056 6.056 0 0 0 5.772-4.206 5.99 5.99 0 0 0 3.997-2.9 6.056 6.056 0 0 0-.747-7.073zM13.26 22.43a4.476 4.476 0 0 1-2.876-1.04l.141-.081 4.779-2.758a.795.795 0 0 0 .392-.681v-6.737l2.02 1.168a.071.071 0 0 1 .038.052v5.583a4.504 4.504 0 0 1-4.494 4.494zM3.6 18.304a4.47 4.47 0 0 1-.535-3.014l.142.085 4.783 2.759a.771.771 0 0 0 .78 0l5.843-3.369v2.332a.08.08 0 0 1-.033.062L9.74 19.95a4.5 4.5 0 0 1-6.14-1.646zM2.34 8.487a4.47 4.47 0 0 1 2.33-1.974V12.05a.79.79 0 0 0 .39.682l5.84 3.37-2.02 1.166a.08.08 0 0 1-.07 0l-4.83-2.79A4.508 4.508 0 0 1 2.34 8.487zm16.597 3.855l-5.833-3.37 2.02-1.164a.08.08 0 0 1 .07 0l4.83 2.79a4.508 4.508 0 0 1-.693 8.013v-5.587a.79.79 0 0 0-.394-.682zm2.01-4.552l-.141-.085-4.773-2.78a.776.776 0 0 0-.785 0L9.409 8.308V5.977a.08.08 0 0 1 .03-.062l4.84-2.797a4.499 4.499 0 0 1 6.67 4.993zM8.307 14.168l-2.02-1.168a.08.08 0 0 1-.038-.052V7.365a4.504 4.504 0 0 1 7.37-3.454l-.14.08-4.78 2.76a.794.794 0 0 0-.392.681zm1.093-2.365l2.6-1.5 2.6 1.5v3l-2.6 1.5-2.6-1.5z"/></svg>`;
  }
  return null;
}

  const domain = (extractDomain(dial.url) || '').toLowerCase();

  const renderFaviconFallback = () => {
    logoWrap.innerHTML = '';
    const letterInfo = getLetterBadgeInfo(dial.name, dial.url);
    const createLetterEl = () => {
      const letterEl = document.createElement('div');
      letterEl.className = 'dial-logo-letter-badge';
      letterEl.style.backgroundColor = letterInfo.bgColor;
      letterEl.textContent = letterInfo.letter;
      return letterEl;
    };

    if (!faviconUrl || dial.noFavicon || isKnownBadFavicon(dial.url)) {
      logoWrap.appendChild(createLetterEl());
    } else {
      const fav = document.createElement('img');
      fav.className = 'dial-logo-icon';
      fav.src = faviconUrl;
      fav.alt = '';
      fav.onerror = () => {
        if (!fav.dataset.triedDdg && domain) {
          fav.dataset.triedDdg = '1';
          fav.src = `https://icons.duckduckgo.com/ip3/${encodeURIComponent(domain)}.ico`;
          return;
        }
        markBadFavicon(dial.url);
        dial.noFavicon = true;
        fav.replaceWith(createLetterEl());
      };
      logoWrap.appendChild(fav);

      if (!isKnownValidFavicon(dial.url)) {
        checkFaviconValid(dial.url, faviconUrl).then(isValid => {
          if (!isValid) {
            dial.noFavicon = true;
            dial.faviconUrl = '';
            if (fav.parentNode) {
              fav.replaceWith(createLetterEl());
            }
          }
        });
      }
    }
  };

  // 1. If explicit custom logo URL is present on the dial
  if (dial.logoUrl) {
    const customLogo = document.createElement('img');
    customLogo.className = 'dial-custom-logo-img';
    customLogo.src = dial.logoUrl;
    customLogo.alt = dial.name || '';
    customLogo.onerror = () => {
      customLogo.remove();
      const brandSvg = getBrandLogoSvg(dial.url);
      if (brandSvg) {
        logoWrap.innerHTML = brandSvg;
      } else {
        renderFaviconFallback();
      }
    };
    logoWrap.appendChild(customLogo);
    thumbArea.appendChild(logoWrap);
    return;
  }

  // 2. Check for recognized brand SVG logo
  const brandSvg = getBrandLogoSvg(dial.url);
  if (brandSvg) {
    logoWrap.innerHTML = brandSvg;
    thumbArea.appendChild(logoWrap);
    return;
  }

  // 3. Fallback to favicon / letter badge in middle
  renderFaviconFallback();
  thumbArea.appendChild(logoWrap);
}

// ========================================================
// RENDER DIALS & DESKTOP GROUPS
// ========================================================
function createDialCard(dId, index, dial, activeFolder) {
  const cfg = state.settings || {};
  const card = document.createElement('div');
  card.className = 'dial-card';
  card.dataset.dialId = dId;
  card.dataset.index = index;
  card.draggable = true;
  card.tabIndex = 0;
  card.setAttribute('role', 'link');

  const domain = extractDomain(dial.url) || '';
  const faviconUrl = getFaviconUrl(dial.url, dial.faviconUrl, dial.noFavicon);
  const letterInfo = getLetterBadgeInfo(dial.name, dial.url);

  if (dial.isPinned) {
    card.classList.add('is-pinned');
  }

  // Pin / Lock button
  const pinBtn = document.createElement('button');
  pinBtn.type = 'button';
  pinBtn.className = `dial-pin-btn ${dial.isPinned ? 'is-pinned' : ''}`;
  pinBtn.title = dial.isPinned ? t('unpinDial') : t('pinDial');
  pinBtn.innerHTML = dial.isPinned ? ICON_LOCKED : ICON_UNLOCKED;
  pinBtn.addEventListener('click', async (e) => {
    e.stopPropagation();
    e.preventDefault();
    const isPinned = await storage.togglePinDial(dId);
    renderDials();
    showToast(isPinned ? t('toastDialPinned') : t('toastDialUnpinned'), '🔒');
  });
  card.appendChild(pinBtn);

  // 1. Upper Thumb Area (Screenshot OR Logo)
  const thumbArea = document.createElement('div');
  thumbArea.className = 'dial-thumb-area';

  const isScreenshot = dial.tileType === 'screenshot' || (dial.screenshotUrl && dial.tileType !== 'logo');
  const screenshotSrc = dial.screenshotUrl || (dial.type === 'image' ? dial.imgUrl : '');

  if (isScreenshot && screenshotSrc) {
    const img = document.createElement('img');
    img.className = 'dial-screenshot';
    img.src = screenshotSrc;
    img.alt = dial.name || '';
    img.loading = 'lazy';
    img.onerror = () => {
      img.remove();
      renderLogoFallback(thumbArea, dial, faviconUrl);
    };
    thumbArea.appendChild(img);
  } else {
    renderLogoFallback(thumbArea, dial, faviconUrl);
  }

  // 2. Lower Footer Bar (42px bar with crisp favicon / letter badge + title + domain)
  const footerBar = document.createElement('div');
  footerBar.className = 'dial-footer-bar';

  const createFooterBadge = () => {
    const badge = document.createElement('div');
    badge.className = 'dial-footer-letter-badge';
    badge.style.backgroundColor = letterInfo.bgColor;
    badge.textContent = letterInfo.letter;
    return badge;
  };

  let footFav;
  if (!faviconUrl || dial.noFavicon || isKnownBadFavicon(dial.url)) {
    footFav = createFooterBadge();
  } else {
    footFav = document.createElement('img');
    footFav.className = 'dial-footer-favicon';
    footFav.src = faviconUrl;
    footFav.alt = '';
    footFav.onerror = () => {
      if (!footFav.dataset.triedDdg && domain) {
        footFav.dataset.triedDdg = '1';
        footFav.src = `https://icons.duckduckgo.com/ip3/${encodeURIComponent(domain)}.ico`;
        return;
      }
      markBadFavicon(dial.url);
      dial.noFavicon = true;
      footFav.replaceWith(createFooterBadge());
    };
    if (!isKnownValidFavicon(dial.url)) {
      checkFaviconValid(dial.url, faviconUrl).then(isValid => {
        if (!isValid) {
          dial.noFavicon = true;
          dial.faviconUrl = '';
          if (footFav.parentNode) {
            footFav.replaceWith(createFooterBadge());
          }
        }
      });
    }
  }

  const footInfo = document.createElement('div');
  footInfo.className = 'dial-footer-info';

  const footTitle = document.createElement('span');
  footTitle.className = 'dial-footer-title';
  footTitle.textContent = dial.name || 'Сайт';

  const footDomain = document.createElement('span');
  footDomain.className = 'dial-footer-domain';
  footDomain.textContent = domain;

  footInfo.appendChild(footTitle);
  footInfo.appendChild(footDomain);

  footerBar.appendChild(footFav);
  footerBar.appendChild(footInfo);

  card.appendChild(thumbArea);
  card.appendChild(footerBar);

  // Click Handler (Direct navigation)
  card.addEventListener('click', (e) => {
    if (e.ctrlKey || e.metaKey || e.button === 1 || cfg.openInNewTab) {
      e.preventDefault();
      chrome.tabs.create({ url: dial.url, active: !e.ctrlKey && !e.metaKey });
    } else {
      window.location.href = dial.url;
    }
  });

  // Keyboard navigation (Enter opens link)
  card.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      if (e.ctrlKey || e.metaKey || cfg.openInNewTab) {
        chrome.tabs.create({ url: dial.url, active: !e.ctrlKey && !e.metaKey });
      } else {
        window.location.href = dial.url;
      }
    }
  });

  // Middle-click opens in background
  card.addEventListener('auxclick', (e) => {
    if (e.button === 1) {
      e.preventDefault();
      chrome.tabs.create({ url: dial.url, active: false });
    }
  });

  // Right-Click Context Menu
  card.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    e.stopPropagation();
    showDialContextMenu(e.clientX, e.clientY, dial);
  });

  // Drag & Drop Reordering
  card.addEventListener('dragstart', (e) => {
    if (dial.isPinned) {
      e.preventDefault();
      showToast(t('toastDialPinnedLocked'), '🔒');
      return;
    }
    draggedDialIndex = activeFolder.dialIds.indexOf(dId);
    draggedDialType = dial.type || 'site';
    e.dataTransfer.setData('text/plain', `dial:${dId}`);
    e.dataTransfer.effectAllowed = 'move';
    card.style.opacity = '0.35';
  });

  card.addEventListener('dragend', () => {
    card.style.opacity = '';
    draggedDialType = null;
    removeDragPlaceholders();
    document.querySelectorAll('.dial-card, .dial-widget-card').forEach(c => c.classList.remove('drag-forbidden'));
  });

  card.addEventListener('dragover', (e) => {
    e.preventDefault();
    if (dial.isPinned) {
      card.classList.add('drag-forbidden');
      e.dataTransfer.dropEffect = 'none';
    } else {
      card.classList.remove('drag-forbidden');
      e.dataTransfer.dropEffect = 'move';
    }
  });

  card.addEventListener('dragleave', () => {
    card.classList.remove('drag-forbidden');
  });

  card.addEventListener('drop', async (e) => {
    e.preventDefault();
    e.stopPropagation();
    card.classList.remove('drag-forbidden');

    if (dial.isPinned) {
      showToast(t('toastCannotDropOnPinned'), '🔒');
      return;
    }

    const dragData = e.dataTransfer.getData('text/plain');

    if (dragData.startsWith('dial:')) {
      const fromDialId = dragData.replace('dial:', '');
      const toDialId = dId;
      if (fromDialId === toDialId) return;

      const fromIndex = activeFolder.dialIds.indexOf(fromDialId);
      const toIndex = activeFolder.dialIds.indexOf(toDialId);
      if (fromIndex !== -1 && toIndex !== -1 && fromIndex !== toIndex) {
        await storage.moveDialInFolder(activeFolder.id, fromIndex, toIndex);
        renderDials();
      }
    }
  });

  return card;
}


// ========================================================
// TILE WIDGETS (ВИДЖЕТЫ В ПЛИТКАХ НА СТОЛЕ)
// Часы, Погода, Курсы валют, Блокнот-заметка
// ========================================================
function getWidgetTitle(widgetDial) {
  if (!widgetDial) return '';
  const type = widgetDial.widgetType;
  const cfg = widgetDial.widgetConfig || {};

  const typeKeyMap = {
    clock: 'widgetClock',
    weather: 'widgetWeather',
    rates: 'widgetRates',
    note: 'widgetNotepad'
  };

  const defaultTitles = [
    'Часы', 'Погода', 'Курсы валют', 'Блокнот', 'Виджет',
    'Clock', 'Weather', 'Exchange Rates', 'Notepad', 'Widget'
  ];

  if (widgetDial.name && !defaultTitles.includes(widgetDial.name)) {
    return widgetDial.name;
  }

  const baseKey = typeKeyMap[type] || 'widgetGeneric';
  let title = t(baseKey) || widgetDial.name || (type === 'clock' ? 'Часы' : (type === 'weather' ? 'Погода' : (type === 'rates' ? 'Курсы валют' : 'Блокнот')));

  if (type === 'rates' && cfg.baseCurrency && cfg.baseCurrency !== 'RUB') {
    title += ` (${cfg.baseCurrency})`;
  }

  return title;
}

function getFriendlyTimezoneName(tz) {
  if (!tz || tz === 'auto') return t('wSetTimezoneAuto');
  const ru = getLanguage() === 'ru';
  const friendlyNames = {
    'Europe/Kaliningrad': ru ? 'Калининград (UTC+2)' : 'Kaliningrad (UTC+2)',
    'Europe/Moscow': ru ? 'Москва (UTC+3)' : 'Moscow (UTC+3)',
    'Europe/Samara': ru ? 'Самара (UTC+4)' : 'Samara (UTC+4)',
    'Asia/Yekaterinburg': ru ? 'Екатеринбург (UTC+5)' : 'Yekaterinburg (UTC+5)',
    'Asia/Omsk': ru ? 'Омск (UTC+6)' : 'Omsk (UTC+6)',
    'Asia/Krasnoyarsk': ru ? 'Красноярск (UTC+7)' : 'Krasnoyarsk (UTC+7)',
    'Asia/Irkutsk': ru ? 'Иркутск (UTC+8)' : 'Irkutsk (UTC+8)',
    'Asia/Yakutsk': ru ? 'Якутск (UTC+9)' : 'Yakutsk (UTC+9)',
    'Asia/Vladivostok': ru ? 'Владивосток (UTC+10)' : 'Vladivostok (UTC+10)',
    'Asia/Magadan': ru ? 'Магадан (UTC+11)' : 'Magadan (UTC+11)',
    'Asia/Kamchatka': ru ? 'Камчатка (UTC+12)' : 'Kamchatka (UTC+12)',
    'UTC': 'UTC / GMT',
    'Europe/London': ru ? 'Лондон (UTC+0/+1)' : 'London (UTC+0/+1)',
    'Europe/Berlin': ru ? 'Берлин, Париж (UTC+1/+2)' : 'Berlin, Paris (UTC+1/+2)',
    'Europe/Kyiv': ru ? 'Киев (UTC+2/+3)' : 'Kyiv (UTC+2/+3)',
    'Europe/Minsk': ru ? 'Минск (UTC+3)' : 'Minsk (UTC+3)',
    'Europe/Istanbul': ru ? 'Стамбул (UTC+3)' : 'Istanbul (UTC+3)',
    'Asia/Dubai': ru ? 'Дубай (UTC+4)' : 'Dubai (UTC+4)',
    'Asia/Baku': ru ? 'Баку (UTC+4)' : 'Baku (UTC+4)',
    'Asia/Tbilisi': ru ? 'Тбилиси (UTC+4)' : 'Tbilisi (UTC+4)',
    'Asia/Yerevan': ru ? 'Ереван (UTC+4)' : 'Yerevan (UTC+4)',
    'Asia/Tashkent': ru ? 'Ташкент (UTC+5)' : 'Tashkent (UTC+5)',
    'Asia/Almaty': ru ? 'Алматы, Астана (UTC+5)' : 'Almaty, Astana (UTC+5)',
    'Asia/Bangkok': ru ? 'Бангкок (UTC+7)' : 'Bangkok (UTC+7)',
    'Asia/Singapore': ru ? 'Сингапур (UTC+8)' : 'Singapore (UTC+8)',
    'Asia/Shanghai': ru ? 'Пекин, Шанхай (UTC+8)' : 'Beijing, Shanghai (UTC+8)',
    'Asia/Tokyo': ru ? 'Токио, Сеул (UTC+9)' : 'Tokyo, Seoul (UTC+9)',
    'Australia/Sydney': ru ? 'Сидней (UTC+10/+11)' : 'Sydney (UTC+10/+11)',
    'America/New_York': ru ? 'Нью-Йорк (UTC-5/-4)' : 'New York (UTC-5/-4)',
    'America/Chicago': ru ? 'Чикаго (UTC-6/-5)' : 'Chicago (UTC-6/-5)',
    'America/Denver': ru ? 'Денвер (UTC-7/-6)' : 'Denver (UTC-7/-6)',
    'America/Los_Angeles': ru ? 'Лос-Анджелес (UTC-8/-7)' : 'Los Angeles (UTC-8/-7)',
    'America/Sao_Paulo': ru ? 'Сан-Паулу (UTC-3)' : 'Sao Paulo (UTC-3)',
    'Pacific/Honolulu': ru ? 'Гавайи, Гонолулу (UTC-10)' : 'Honolulu (UTC-10)'
  };
  return friendlyNames[tz] || tz.split('/').pop().replace(/_/g, ' ');
}

function buildTimezoneSelectHtml(selectedTz) {
  const current = selectedTz || 'auto';
  const ru = getLanguage() === 'ru';

  const russiaZones = [
    { id: 'Europe/Kaliningrad', name: ru ? 'Калининград (UTC+2)' : 'Kaliningrad (UTC+2)' },
    { id: 'Europe/Moscow', name: ru ? 'Москва, СПб, Казань (UTC+3)' : 'Moscow, St. Petersburg (UTC+3)' },
    { id: 'Europe/Samara', name: ru ? 'Самара, Саратов, Ижевск (UTC+4)' : 'Samara, Saratov (UTC+4)' },
    { id: 'Asia/Yekaterinburg', name: ru ? 'Екатеринбург, Уфа, Пермь, Тюмень (UTC+5)' : 'Yekaterinburg, Perm (UTC+5)' },
    { id: 'Asia/Omsk', name: ru ? 'Омск (UTC+6)' : 'Omsk (UTC+6)' },
    { id: 'Asia/Krasnoyarsk', name: ru ? 'Красноярск, Новосибирск, Томск (UTC+7)' : 'Krasnoyarsk, Novosibirsk (UTC+7)' },
    { id: 'Asia/Irkutsk', name: ru ? 'Иркутск, Улан-Удэ (UTC+8)' : 'Irkutsk (UTC+8)' },
    { id: 'Asia/Yakutsk', name: ru ? 'Якутск, Чита, Благовещенск (UTC+9)' : 'Yakutsk, Chita (UTC+9)' },
    { id: 'Asia/Vladivostok', name: ru ? 'Владивосток, Хабаровск (UTC+10)' : 'Vladivostok, Khabarovsk (UTC+10)' },
    { id: 'Asia/Magadan', name: ru ? 'Магадан, Сахалин (UTC+11)' : 'Magadan, Sakhalin (UTC+11)' },
    { id: 'Asia/Kamchatka', name: ru ? 'Петропавловск-Камчатский, Анадырь (UTC+12)' : 'Kamchatka, Anadyr (UTC+12)' }
  ];

  const worldHubs = [
    { id: 'UTC', name: 'UTC / GMT' },
    { id: 'Europe/London', name: ru ? 'Лондон, Дублин (UTC+0/+1)' : 'London, Dublin (UTC+0/+1)' },
    { id: 'Europe/Berlin', name: ru ? 'Берлин, Париж, Рим, Амстердам (UTC+1/+2)' : 'Berlin, Paris, Rome (UTC+1/+2)' },
    { id: 'Europe/Kyiv', name: ru ? 'Киев, Кишинёв (UTC+2/+3)' : 'Kyiv, Chisinau (UTC+2/+3)' },
    { id: 'Europe/Minsk', name: ru ? 'Минск (UTC+3)' : 'Minsk (UTC+3)' },
    { id: 'Europe/Istanbul', name: ru ? 'Стамбул (UTC+3)' : 'Istanbul (UTC+3)' },
    { id: 'Asia/Dubai', name: ru ? 'Дубай, Абу-Даби (UTC+4)' : 'Dubai, Abu Dhabi (UTC+4)' },
    { id: 'Asia/Baku', name: ru ? 'Баку (UTC+4)' : 'Baku (UTC+4)' },
    { id: 'Asia/Tbilisi', name: ru ? 'Тбилиси (UTC+4)' : 'Tbilisi (UTC+4)' },
    { id: 'Asia/Yerevan', name: ru ? 'Ереван (UTC+4)' : 'Yerevan (UTC+4)' },
    { id: 'Asia/Tashkent', name: ru ? 'Ташкент, Самарканд (UTC+5)' : 'Tashkent, Samarkand (UTC+5)' },
    { id: 'Asia/Almaty', name: ru ? 'Алматы, Астана (UTC+5)' : 'Almaty, Astana (UTC+5)' },
    { id: 'Asia/Bangkok', name: ru ? 'Бангкок, Ханой, Джакарта (UTC+7)' : 'Bangkok, Hanoi, Jakarta (UTC+7)' },
    { id: 'Asia/Singapore', name: ru ? 'Сингапур (UTC+8)' : 'Singapore (UTC+8)' },
    { id: 'Asia/Shanghai', name: ru ? 'Пекин, Шанхай (UTC+8)' : 'Beijing, Shanghai (UTC+8)' },
    { id: 'Asia/Tokyo', name: ru ? 'Токио, Сеул (UTC+9)' : 'Tokyo, Seoul (UTC+9)' },
    { id: 'Australia/Sydney', name: ru ? 'Сидней, Мельбурн (UTC+10/+11)' : 'Sydney, Melbourne (UTC+10/+11)' },
    { id: 'America/New_York', name: ru ? 'Нью-Йорк, Вашингтон, Майами (UTC-5/-4)' : 'New York, Washington, Miami (UTC-5/-4)' },
    { id: 'America/Chicago', name: ru ? 'Чикаго, Даллас (UTC-6/-5)' : 'Chicago, Dallas (UTC-6/-5)' },
    { id: 'America/Denver', name: ru ? 'Денвер, Финикс (UTC-7/-6)' : 'Denver, Phoenix (UTC-7/-6)' },
    { id: 'America/Los_Angeles', name: ru ? 'Лос-Анджелес, Сан-Франциско (UTC-8/-7)' : 'Los Angeles, San Francisco (UTC-8/-7)' },
    { id: 'America/Sao_Paulo', name: ru ? 'Сан-Паулу, Рио-де-Жанейро (UTC-3)' : 'Sao Paulo, Rio (UTC-3)' },
    { id: 'Pacific/Honolulu', name: ru ? 'Гавайи, Гонолулу (UTC-10)' : 'Hawaii, Honolulu (UTC-10)' }
  ];

  let allTzList = [];
  if (typeof Intl !== 'undefined' && typeof Intl.supportedValuesOf === 'function') {
    try {
      allTzList = Intl.supportedValuesOf('timeZone');
    } catch (e) {
      allTzList = [];
    }
  }

  let html = `<option value="auto" ${current === 'auto' ? 'selected' : ''}>${t('wSetTimezoneAuto')}</option>`;

  html += `<optgroup label="${t('wTzGroupRussia')}">`;
  russiaZones.forEach(z => {
    html += `<option value="${z.id}" ${current === z.id ? 'selected' : ''}>${z.name}</option>`;
  });
  html += `</optgroup>`;

  html += `<optgroup label="${t('wTzGroupWorld')}">`;
  worldHubs.forEach(z => {
    html += `<option value="${z.id}" ${current === z.id ? 'selected' : ''}>${z.name}</option>`;
  });
  html += `</optgroup>`;

  if (allTzList.length > 0) {
    html += `<optgroup label="${t('wTzGroupAll')}">`;
    allTzList.forEach(tz => {
      const isAlreadyInTop = russiaZones.some(z => z.id === tz) || worldHubs.some(z => z.id === tz);
      if (!isAlreadyInTop) {
        html += `<option value="${tz}" ${current === tz ? 'selected' : ''}>${tz.replace(/_/g, ' ')}</option>`;
      }
    });
    html += `</optgroup>`;
  }

  return html;
}

function createWidgetCard(dId, index, widgetDial, activeFolder) {
  const card = document.createElement('div');
  const size = widgetDial.widgetSize || '1x1';
  const type = widgetDial.widgetType || 'clock';
  const cfg = widgetDial.widgetConfig || {};
  const fontSize = cfg.fontSize || 'normal';

  card.className = `dial-widget-card widget-size-${size} widget-font-${fontSize}`;
  if (widgetDial.isPinned) {
    card.classList.add('is-pinned');
  }
  if (type === 'note') {
    card.classList.add(`widget-note-${cfg.color || 'amber'}`);
    card.classList.add(`note-font-${fontSize}`);
  }
  card.dataset.dialId = dId;
  card.dataset.index = index;
  card.draggable = true;

  // Header
  const header = document.createElement('div');
  header.className = 'dial-widget-header';

  const icons = { clock: '⏰', weather: '🌤️', rates: '📈', note: '📝' };
  header.innerHTML = `
    <div class="dial-widget-title-wrap">
      <span>${icons[type] || '⚙️'}</span>
      <span>${getWidgetTitle(widgetDial)}</span>
    </div>
    <div class="dial-widget-header-actions" style="display:flex; align-items:center; gap:4px;">
      <button type="button" class="widget-header-btn widget-pin-btn ${widgetDial.isPinned ? 'is-pinned' : ''}" title="${widgetDial.isPinned ? t('unpinDial') : t('pinDial')}" style="padding:2px 4px; border-radius:4px; border:none; background:transparent; cursor:pointer; display:flex; align-items:center;">
        ${widgetDial.isPinned ? ICON_LOCKED : ICON_UNLOCKED}
      </button>
      <button type="button" class="dial-widget-btn-gear" title="${t('widgetModalTitle')}">
        <svg viewBox="0 0 16 16" width="12" height="12" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="8" cy="8" r="3"></circle><path d="M8 1v2M8 13v2M1 8h2M13 8h2M3.05 3.05l1.41 1.41M11.54 11.54l1.41 1.41M3.05 12.95l1.41-1.41M11.54 4.46l1.41-1.41"></path></svg>
      </button>
    </div>
  `;

  header.querySelector('.widget-pin-btn')?.addEventListener('click', async (e) => {
    e.stopPropagation();
    const isPinned = await storage.togglePinDial(dId);
    renderDials();
    showToast(isPinned ? t('toastDialPinned') : t('toastDialUnpinned'), '🔒');
  });

  header.querySelector('.dial-widget-btn-gear')?.addEventListener('click', (e) => {
    e.stopPropagation();
    openWidgetSettingsModal(widgetDial);
  });

  // Body
  const body = document.createElement('div');
  body.className = 'dial-widget-body';

  if (type === 'clock') {
    const disp = document.createElement('div');
    disp.className = 'widget-clock-display';
    const zoneLabel = getFriendlyTimezoneName(cfg.timezone);

    const getClockFormatted = () => {
      const now = new Date();
      let d = now;
      if (cfg.timezone && cfg.timezone !== 'auto') {
        try {
          const str = now.toLocaleString('en-US', { timeZone: cfg.timezone });
          d = new Date(str);
        } catch (e) { d = now; }
      }
      const is24 = cfg.is24Hour !== false;
      let hNum = d.getHours();
      let ampm = '';
      if (!is24) {
        ampm = hNum >= 12 ? ' PM' : ' AM';
        hNum = hNum % 12 || 12;
      }
      const h = is24 ? String(hNum).padStart(2, '0') : String(hNum);
      const m = String(d.getMinutes()).padStart(2, '0');
      const s = String(d.getSeconds()).padStart(2, '0');
      const timeStr = (cfg.showSeconds !== false ? `${h}:${m}:${s}` : `${h}:${m}`) + ampm;
      const options = { weekday: 'short', day: 'numeric', month: 'short' };
      const dateStr = d.toLocaleDateString(getLanguage() === 'ru' ? 'ru-RU' : 'en-US', options);
      return { timeStr, dateStr };
    };

    const initialClock = getClockFormatted();
    disp.innerHTML = `
      <div class="widget-clock-time" id="wClockTime_${dId}">${initialClock.timeStr}</div>
      <button type="button" class="widget-clock-date widget-clock-date-btn" id="wClockDate_${dId}" title="${t('clockCalendarTooltip')}">
        <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" style="opacity:0.75; flex-shrink:0;"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
        <span class="widget-clock-date-text">${initialClock.dateStr}</span>
      </button>
      <div class="widget-clock-zone">${zoneLabel}</div>
    `;
    body.appendChild(disp);

    const dateBtn = disp.querySelector(`#wClockDate_${dId}`);
    dateBtn?.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleClockCalendar(dateBtn, cfg.timezone);
    });

    const updateTime = () => {
      const timeEl = document.getElementById(`wClockTime_${dId}`);
      const dateEl = document.getElementById(`wClockDate_${dId}`);
      if (!timeEl) return;
      const { timeStr, dateStr } = getClockFormatted();
      timeEl.textContent = timeStr;
      if (dateEl) {
        const textSpan = dateEl.querySelector('.widget-clock-date-text') || dateEl;
        textSpan.textContent = dateStr;
      }
    };
    const interval = setInterval(updateTime, 1000);
    card.dataset.intervalId = interval;

  } else if (type === 'weather') {
    const disp = document.createElement('div');
    disp.className = 'widget-weather-display';
    const city = cfg.city || (getLanguage() === 'ru' ? 'Москва' : 'London');
    const units = cfg.units || 'c';
    disp.innerHTML = `
      <div class="widget-weather-main">
        <span class="widget-weather-icon" id="wWeatherIcon_${dId}">🌤️</span>
        <span class="widget-weather-temp" id="wWeatherTemp_${dId}">--°</span>
      </div>
      <div class="widget-weather-city">${city}</div>
      <div class="widget-weather-desc" id="wWeatherDesc_${dId}">${t('loading')}</div>
    `;
    body.appendChild(disp);

    fetchLiveWeather(city, units).then(info => {
      const iconEl = document.getElementById(`wWeatherIcon_${dId}`);
      const tempEl = document.getElementById(`wWeatherTemp_${dId}`);
      const descEl = document.getElementById(`wWeatherDesc_${dId}`);
      if (iconEl && tempEl && descEl && info) {
        iconEl.textContent = info.icon;
        tempEl.textContent = info.temp;
        descEl.textContent = info.desc;
      }
    });

  } else if (type === 'rates') {
    const list = document.createElement('div');
    list.className = 'widget-rates-list';
    const items = cfg.items || ['USD', 'EUR', 'BTC'];
    const baseCurrency = cfg.baseCurrency || 'RUB';
    const maxItems = widgetDial.widgetSize === '2x1' ? 8 : 4;
    if (items.length > maxItems) {
      list.classList.add('rates-scrollable');
    }

    const renderRows = (ratesData) => {
      list.innerHTML = '';
      items.forEach(item => {
        const data = ratesData[item] || { val: '—', delta: '0%', up: true };
        const row = document.createElement('div');
        row.className = 'widget-rate-row';

        let changeClass = 'neutral';
        let arrow = '';
        const deltaStr = data.delta || '0%';
        if (deltaStr.startsWith('+') || (data.up && !deltaStr.startsWith('0') && !deltaStr.startsWith('-'))) {
          changeClass = 'up';
          arrow = '▲ ';
        } else if (deltaStr.startsWith('-') || (!data.up && !deltaStr.startsWith('0'))) {
          changeClass = 'down';
          arrow = '▼ ';
        }

        row.innerHTML = `
          <span class="widget-rate-asset" title="${data.name || item}">${item}</span>
          <span class="widget-rate-value">${data.val}</span>
          <span class="widget-rate-change ${changeClass}">${arrow}${deltaStr}</span>
        `;
        list.appendChild(row);
      });
    };

    fetchLiveRates(items, baseCurrency).then(renderRows);
    body.appendChild(list);

  } else if (type === 'note') {
    card.classList.add('dial-widget-note');
    const noteColor = cfg.color || 'amber';
    card.classList.add(`widget-note-${noteColor}`);
    const noteFontSize = cfg.fontSize || 'normal';
    card.classList.add(`note-font-${noteFontSize}`);

    // Режим: 'todos' (задачи) или 'notes' (текст)
    let currentMode = cfg.mode || 'todos';

    // Область данных: 'independent' (только в этой плитке), 'global' (на всех столах) или 'local' (только на этом столе)
    const scope = cfg.syncScope || (cfg.text !== undefined || cfg.todos !== undefined ? 'independent' : 'global');
    const notepad = storage.getNotepad();
    let activeData;
    if (scope === 'independent') {
      if (!Array.isArray(cfg.todos)) cfg.todos = [];
      if (typeof cfg.text !== 'string') cfg.text = '';
      activeData = {
        todos: cfg.todos,
        get text() { return cfg.text || ''; },
        set text(v) { cfg.text = v; }
      };
    } else if (scope === 'global') {
      if (!notepad.globalNotes) notepad.globalNotes = { text: '', todos: [] };
      if (!Array.isArray(notepad.globalNotes.todos)) notepad.globalNotes.todos = [];
      if (typeof notepad.globalNotes.text !== 'string') notepad.globalNotes.text = '';
      activeData = notepad.globalNotes;
    } else {
      if (!notepad.localNotes) notepad.localNotes = {};
      if (!notepad.localNotes[activeFolder.id]) {
        notepad.localNotes[activeFolder.id] = { text: cfg.text || '', todos: cfg.todos || [] };
      }
      activeData = notepad.localNotes[activeFolder.id];
      if (!Array.isArray(activeData.todos)) activeData.todos = [];
      if (typeof activeData.text !== 'string') activeData.text = '';
    }

    // Переключатель режимов в шапке виджета
    const headerActions = header.querySelector('.dial-widget-header-actions');
    if (headerActions) {
      const modeToggle = document.createElement('div');
      modeToggle.className = 'widget-note-mode-toggle';
      modeToggle.innerHTML = `
        <button type="button" class="widget-note-mode-btn ${currentMode === 'todos' ? 'active' : ''}" data-mode="todos" title="${t('widgetTabTodos')}">☑️</button>
        <button type="button" class="widget-note-mode-btn ${currentMode === 'notes' ? 'active' : ''}" data-mode="notes" title="${t('widgetTabNotes')}">✍️</button>
      `;
      headerActions.insertBefore(modeToggle, headerActions.firstChild);

      modeToggle.querySelectorAll('.widget-note-mode-btn').forEach(btn => {
        btn.addEventListener('click', async (e) => {
          e.stopPropagation();
          const newMode = btn.dataset.mode;
          if (newMode === currentMode) return;
          currentMode = newMode;
          modeToggle.querySelectorAll('.widget-note-mode-btn').forEach(b => {
            b.classList.toggle('active', b.dataset.mode === currentMode);
          });
          todosPane.classList.toggle('active', currentMode === 'todos');
          notesPane.classList.toggle('active', currentMode === 'notes');
          cfg.mode = currentMode;
          await storage.updateWidgetDial(dId, { mode: currentMode }, null, true);
        });
      });
    }

    body.classList.add('widget-note-body');

    // Панели: Задачи и Текст
    const todosPane = document.createElement('div');
    todosPane.className = `widget-note-pane widget-todos-pane ${currentMode === 'todos' ? 'active' : ''}`;

    const notesPane = document.createElement('div');
    notesPane.className = `widget-note-pane widget-text-pane ${currentMode === 'notes' ? 'active' : ''}`;

    const saveNotepad = async () => {
      if (scope === 'independent') {
        await storage.updateWidgetDial(dId, { text: activeData.text, todos: activeData.todos }, null, true);
      } else {
        const np = storage.getNotepad();
        if (scope === 'global') {
          np.globalNotes = activeData;
        } else {
          if (!np.localNotes) np.localNotes = {};
          np.localNotes[activeFolder.id] = activeData;
        }
        await storage.updateNotepad({
          globalNotes: np.globalNotes,
          localNotes: np.localNotes
        });
      }
    };

    // 1. ПАНЕЛЬ ЗАДАЧ (TODOS)
    const todoList = document.createElement('div');
    todoList.className = 'widget-todo-list';

    const todoFooter = document.createElement('div');
    todoFooter.className = 'widget-todo-footer';

    const renderTodoList = () => {
      todoList.innerHTML = '';
      const todos = activeData.todos || [];

      if (todos.length === 0) {
        const empty = document.createElement('div');
        empty.className = 'widget-todo-empty';
        empty.textContent = t('widgetNoTodos');
        todoList.appendChild(empty);
      } else {
        todos.forEach((todo, idx) => {
          const item = document.createElement('div');
          item.className = 'widget-todo-item' + (todo.completed ? ' completed' : '');

          const check = document.createElement('input');
          check.type = 'checkbox';
          check.className = 'widget-todo-check';
          check.checked = Boolean(todo.completed);
          check.addEventListener('click', (e) => e.stopPropagation());
          check.addEventListener('change', async (e) => {
            e.stopPropagation();
            todo.completed = check.checked;
            item.classList.toggle('completed', todo.completed);
            updateFooterCounter();
            await saveNotepad();
          });

          const span = document.createElement('span');
          span.className = 'widget-todo-text';
          span.textContent = todo.text;
          span.title = todo.text;

          const del = document.createElement('button');
          del.type = 'button';
          del.className = 'widget-todo-del';
          del.innerHTML = '✕';
          del.title = t('ctxDeleteDial');
          del.addEventListener('click', async (e) => {
            e.stopPropagation();
            todos.splice(idx, 1);
            renderTodoList();
            await saveNotepad();
          });

          item.appendChild(check);
          item.appendChild(span);
          item.appendChild(del);
          todoList.appendChild(item);
        });
      }

      updateFooterCounter();
    };

    const updateFooterCounter = () => {
      const todos = activeData.todos || [];
      const done = todos.filter(t => t.completed).length;
      const total = todos.length;
      todoFooter.innerHTML = `
        <span class="widget-todo-counter">${t('widgetTodoCounter', { done, total })}</span>
        ${done > 0 ? `<button type="button" class="widget-todo-clear-done" title="${t('widgetClearDone')}">${t('widgetClearDone')}</button>` : ''}
      `;
      todoFooter.querySelector('.widget-todo-clear-done')?.addEventListener('click', async (e) => {
        e.stopPropagation();
        activeData.todos = (activeData.todos || []).filter(t => !t.completed);
        renderTodoList();
        await saveNotepad();
      });
    };

    const addRow = document.createElement('div');
    addRow.className = 'widget-add-todo';
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'widget-todo-input';
    input.placeholder = t('widgetNewTodoPlaceholder');
    input.addEventListener('mousedown', (e) => e.stopPropagation());
    input.addEventListener('keydown', async (e) => {
      e.stopPropagation();
      if (e.key === 'Enter') {
        const val = input.value.trim();
        if (!val) return;
        activeData.todos.push({ id: generateId(), text: val, completed: false });
        input.value = '';
        renderTodoList();
        await saveNotepad();
      }
    });

    const addBtn = document.createElement('button');
    addBtn.type = 'button';
    addBtn.className = 'widget-todo-add-btn';
    addBtn.textContent = '+';
    addBtn.title = t('widgetAddTodoBtn');
    addBtn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const val = input.value.trim();
      if (!val) return;
      activeData.todos.push({ id: generateId(), text: val, completed: false });
      input.value = '';
      renderTodoList();
      await saveNotepad();
    });

    addRow.appendChild(input);
    addRow.appendChild(addBtn);

    todosPane.appendChild(todoList);
    todosPane.appendChild(addRow);
    todosPane.appendChild(todoFooter);
    renderTodoList();

    // 2. ПАНЕЛЬ ТЕКСТОВОЙ ЗАМЕТКИ (NOTES)
    const textarea = document.createElement('textarea');
    textarea.className = 'widget-note-textarea';
    textarea.placeholder = t('widgetTextPlaceholder');
    textarea.value = activeData.text || '';
    textarea.addEventListener('mousedown', (e) => e.stopPropagation());

    const debouncedSaveText = debounce(async (txt) => {
      activeData.text = txt;
      await saveNotepad();
    }, 400);

    textarea.addEventListener('input', (e) => {
      debouncedSaveText(e.target.value);
    });

    notesPane.appendChild(textarea);

    body.appendChild(todosPane);
    body.appendChild(notesPane);
  }

  card.appendChild(header);
  card.appendChild(body);

  // Drag & drop for widget reordering
  card.addEventListener('dragstart', (e) => {
    if (e.target.closest('input, textarea, button, .widget-todo-item')) {
      e.preventDefault();
      return;
    }
    if (widgetDial.isPinned) {
      e.preventDefault();
      showToast(t('toastDialPinnedLocked'), '🔒');
      return;
    }
    draggedDialType = 'widget';
    e.dataTransfer.setData('text/plain', `dial:${dId}`);
    card.style.opacity = '0.35';
  });

  card.addEventListener('dragend', () => {
    card.style.opacity = '';
    draggedDialType = null;
    document.querySelectorAll('.dial-card, .dial-widget-card').forEach(c => c.classList.remove('drag-forbidden'));
  });

  card.addEventListener('dragover', (e) => {
    e.preventDefault();
    if (widgetDial.isPinned) {
      card.classList.add('drag-forbidden');
      e.dataTransfer.dropEffect = 'none';
    } else {
      card.classList.remove('drag-forbidden');
      e.dataTransfer.dropEffect = 'move';
    }
  });

  card.addEventListener('dragleave', () => {
    card.classList.remove('drag-forbidden');
  });

  card.addEventListener('drop', async (e) => {
    e.preventDefault();
    e.stopPropagation();
    card.classList.remove('drag-forbidden');

    if (widgetDial.isPinned) {
      showToast(t('toastCannotDropOnPinned'), '🔒');
      return;
    }

    const dragData = e.dataTransfer.getData('text/plain');

    if (dragData.startsWith('dial:')) {
      const fromDialId = dragData.replace('dial:', '');
      if (fromDialId !== dId) {
        const fromIndex = activeFolder.dialIds.indexOf(fromDialId);
        const toIndex = activeFolder.dialIds.indexOf(dId);
        if (fromIndex !== -1 && toIndex !== -1 && fromIndex !== toIndex) {
          await storage.moveDialInFolder(activeFolder.id, fromIndex, toIndex);
          renderDials();
        }
      }
    }
  });

  // Right-click opens widget settings
  card.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    e.stopPropagation();
    openWidgetSettingsModal(widgetDial);
  });

  return card;
}

// ========================================================
// ADD BUTTON & QUICK ADD POPOVER (+ Меню: Сайт / Виджеты)
// ========================================================
function createAddDialCard(folderId) {
  const addCard = document.createElement('div');
  addCard.className = 'add-dial-card';
  addCard.title = t('addBtnTitle');
  addCard.innerHTML = `<svg viewBox="0 0 24 24" width="32" height="32" fill="none" stroke="currentColor" stroke-width="2.2"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>`;
  addCard.addEventListener('click', (e) => {
    e.stopPropagation();
    showQuickAddPopover(addCard, folderId);
  });

  addCard.addEventListener('dragover', (e) => {
    e.preventDefault();
  });

  addCard.addEventListener('drop', async (e) => {
    e.preventDefault();
    e.stopPropagation();
    const dragData = e.dataTransfer.getData('text/plain');
    const activeFolder = state.folders.byId[state.activeFolderId];
    if (!activeFolder) return;

    if (dragData.startsWith('dial:')) {
      const fromDialId = dragData.replace('dial:', '');
      const fromIndex = activeFolder.dialIds.indexOf(fromDialId);
      if (fromIndex !== -1 && fromIndex !== activeFolder.dialIds.length - 1) {
        await storage.moveDialInFolder(activeFolder.id, fromIndex, activeFolder.dialIds.length - 1);
        renderDials();
      }
    }
  });

  return addCard;
}

function showQuickAddPopover(anchorEl, folderId) {
  const popover = document.getElementById('quickAddPopover');
  if (!popover) {
    openDialModal(null, '');
    return;
  }

  const rect = anchorEl.getBoundingClientRect();
  popover.style.left = `${Math.min(rect.left, window.innerWidth - 230)}px`;
  popover.style.top = `${Math.min(rect.bottom + 6, window.innerHeight - 240)}px`;
  popover.classList.add('active');

  const closePopover = () => {
    popover.classList.remove('active');
    document.removeEventListener('click', closePopover);
  };
  setTimeout(() => document.addEventListener('click', closePopover), 0);
}

// ========================================================
// CLOCK WIDGET: FLYOUT CALENDAR POPOVER
// ========================================================
let activeCalendarAnchor = null;
let calendarViewDate = new Date();
let calendarTargetTimezone = null;

function toggleClockCalendar(anchorBtn, timezone) {
  const flyout = document.getElementById('clockCalendarFlyout');
  if (!flyout) return;

  if (activeCalendarAnchor === anchorBtn && !flyout.classList.contains('hidden')) {
    closeClockCalendar();
    return;
  }

  if (activeCalendarAnchor) {
    activeCalendarAnchor.classList.remove('active');
  }
  activeCalendarAnchor = anchorBtn;
  anchorBtn.classList.add('active');
  calendarTargetTimezone = timezone;

  // Initialize view date based on widget timezone or current local date
  let d = new Date();
  if (timezone && timezone !== 'auto') {
    try {
      const str = d.toLocaleString('en-US', { timeZone: timezone });
      d = new Date(str);
    } catch (e) {}
  }
  calendarViewDate = new Date(d);

  renderClockCalendar();

  // Position flyout relative to anchorBtn
  const rect = anchorBtn.getBoundingClientRect();
  const flyoutWidth = 288;
  const flyoutHeight = 330;

  let left = rect.left + (rect.width / 2) - (flyoutWidth / 2);
  if (left + flyoutWidth > window.innerWidth - 12) {
    left = window.innerWidth - flyoutWidth - 12;
  }
  if (left < 12) left = 12;

  let top = rect.bottom + 8;
  if (top + flyoutHeight > window.innerHeight - 12) {
    top = Math.max(12, rect.top - flyoutHeight - 8);
  }

  flyout.style.left = `${left}px`;
  flyout.style.top = `${top}px`;
  flyout.classList.remove('hidden');
}

function closeClockCalendar() {
  const flyout = document.getElementById('clockCalendarFlyout');
  if (flyout) flyout.classList.add('hidden');
  if (activeCalendarAnchor) {
    activeCalendarAnchor.classList.remove('active');
    activeCalendarAnchor = null;
  }
}

function renderClockCalendar() {
  const flyout = document.getElementById('clockCalendarFlyout');
  if (!flyout) return;

  const monthYearEl = document.getElementById('calMonthYear');
  const daysGrid = document.getElementById('calDaysGrid');
  const statusEl = document.getElementById('calStatus');
  if (!monthYearEl || !daysGrid) return;

  const lang = getLanguage() === 'ru' ? 'ru' : 'en';
  const year = calendarViewDate.getFullYear();
  const month = calendarViewDate.getMonth();

  // Localized Month & Year header
  try {
    const titleFormatter = new Intl.DateTimeFormat(lang === 'ru' ? 'ru-RU' : 'en-US', { month: 'long', year: 'numeric' });
    const rawTitle = titleFormatter.format(calendarViewDate);
    monthYearEl.textContent = rawTitle.charAt(0).toUpperCase() + rawTitle.slice(1);
  } catch (err) {
    monthYearEl.textContent = `${month + 1}.${year}`;
  }

  daysGrid.innerHTML = '';

  // Calculate "today" in target timezone
  let now = new Date();
  if (calendarTargetTimezone && calendarTargetTimezone !== 'auto') {
    try {
      now = new Date(now.toLocaleString('en-US', { timeZone: calendarTargetTimezone }));
    } catch (e) {}
  }
  const todayYear = now.getFullYear();
  const todayMonth = now.getMonth();
  const todayDate = now.getDate();

  // First day of current month (European standard: Mon = 0, Sun = 6)
  const firstDay = new Date(year, month, 1);
  let startDayOfWeek = firstDay.getDay() - 1;
  if (startDayOfWeek === -1) startDayOfWeek = 6;

  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const daysInPrevMonth = new Date(year, month, 0).getDate();

  // Previous month filler days
  for (let i = startDayOfWeek - 1; i >= 0; i--) {
    const d = daysInPrevMonth - i;
    const cell = document.createElement('div');
    cell.className = 'cal-day other-month';
    cell.textContent = d;
    daysGrid.appendChild(cell);
  }

  // Current month days
  for (let day = 1; day <= daysInMonth; day++) {
    const cell = document.createElement('div');
    cell.className = 'cal-day';
    cell.textContent = day;

    const cellDate = new Date(year, month, day);
    const dayOfWeek = cellDate.getDay();
    if (dayOfWeek === 0 || dayOfWeek === 6) {
      cell.classList.add('weekend');
    }

    const isToday = (day === todayDate && month === todayMonth && year === todayYear);
    if (isToday) {
      cell.classList.add('today');
    }

    cell.addEventListener('click', (e) => {
      e.stopPropagation();
      daysGrid.querySelectorAll('.cal-day').forEach(c => c.classList.remove('selected'));
      cell.classList.add('selected');
      try {
        const dFormatter = new Intl.DateTimeFormat(lang === 'ru' ? 'ru-RU' : 'en-US', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
        if (statusEl) {
          statusEl.innerHTML = `${t('calSelected')} <strong>${dFormatter.format(cellDate)}</strong>`;
        }
      } catch (err) {}
    });

    daysGrid.appendChild(cell);
  }

  // Next month filler days to complete rows (35 or 42 cells)
  const totalCells = startDayOfWeek + daysInMonth;
  const targetCells = totalCells > 35 ? 42 : 35;
  const remainingCells = targetCells - totalCells;
  for (let day = 1; day <= remainingCells; day++) {
    const cell = document.createElement('div');
    cell.className = 'cal-day other-month';
    cell.textContent = day;
    daysGrid.appendChild(cell);
  }

  if (statusEl) {
    try {
      const nowFormatter = new Intl.DateTimeFormat(lang === 'ru' ? 'ru-RU' : 'en-US', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
      statusEl.innerHTML = `${t('calTodayLabel')} <strong>${nowFormatter.format(now)}</strong>`;
    } catch (err) {}
  }
}

// ========================================================
// RENDER ALL DIALS (MAIN DESKTOP GRID)
// ========================================================
function renderDials() {
  closeClockCalendar();
  const grid = document.getElementById('dialsGrid');
  if (!grid) return;

  // Clear running timers/intervals on existing widget cards before wiping DOM
  grid.querySelectorAll('.dial-widget-card').forEach(card => {
    if (card.dataset.intervalId) {
      clearInterval(Number(card.dataset.intervalId));
    }
  });

  grid.innerHTML = '';

  const activeFolder = state.folders.byId[state.activeFolderId];
  if (!activeFolder) return;

  const dialIds = activeFolder.dialIds || [];

  dialIds.forEach((dId, index) => {
    try {
      const dial = state.dials.byId[dId];
      if (!dial) return;
      if (dial.type === 'widget') {
        grid.appendChild(createWidgetCard(dId, index, dial, activeFolder));
      } else {
        grid.appendChild(createDialCard(dId, index, dial, activeFolder));
      }
    } catch (err) {
      console.error(`Error rendering dial ${dId}:`, err);
    }
  });

  try {
    grid.appendChild(createAddDialCard(activeFolder.id));
  } catch (err) {
    console.error('Error rendering add card:', err);
  }

  // Re-apply search filter if query exists
  filterDeskDials();
}

function removeDragPlaceholders() {
  document.querySelectorAll('.dial-drag-placeholder').forEach(el => el.remove());
}

// ========================================================
// CONTEXT MENUS
// ========================================================
function showDialContextMenu(x, y, dial) {
  closeContextMenus();
  targetDial = dial;

  const menu = document.getElementById('dialContextMenu');
  if (!menu) return;

  const pinText = document.getElementById('ctxPinText');
  const pinIcon = document.getElementById('ctxPinIcon');
  if (pinText) pinText.textContent = dial.isPinned ? t('ctxUnpinDial') : t('ctxPinDial');
  if (pinIcon) pinIcon.innerHTML = dial.isPinned ? ICON_LOCKED : ICON_UNLOCKED;

  // Build Submenu with available target desktops
  const submenu = document.getElementById('ctxMoveSubmenu');
  submenu.innerHTML = '';
  state.folders.ids.forEach(fId => {
    if (fId !== dial.folderId) {
      const f = state.folders.byId[fId];
      if (f) {
        const item = document.createElement('div');
        item.className = 'menu-item';

        const iconSpan = document.createElement('span');
        iconSpan.className = 'menu-item-icon';
        iconSpan.innerHTML = getIconSvg(f.icon || 'folder');

        const textSpan = document.createElement('span');
        textSpan.className = 'menu-item-text';
        textSpan.textContent = f.name;

        item.appendChild(iconSpan);
        item.appendChild(textSpan);

        item.addEventListener('click', async () => {
          await storage.moveDialToFolder(dial.id, fId);
          showToast(t('toastDialMoved', { name: f.name }));
          closeContextMenus();
        });
        submenu.appendChild(item);
      }
    }
  });

  menu.style.left = `${Math.min(x, window.innerWidth - 220)}px`;
  menu.style.top = `${Math.min(y, window.innerHeight - 200)}px`;
  menu.classList.remove('hidden');
  activeContextMenu = menu;
}

function showFolderContextMenu(x, y, folder) {
  closeContextMenus();
  targetFolder = folder;

  const menu = document.getElementById('folderContextMenu');
  if (!menu) return;

  menu.style.left = `${Math.min(x, window.innerWidth - 200)}px`;
  menu.style.top = `${Math.min(y, window.innerHeight - 180)}px`;
  menu.classList.remove('hidden');
  activeContextMenu = menu;
}

function showGroupContextMenu(x, y, group, folderId) {
  closeContextMenus();
  targetGroup = group;
  targetGroupFolderId = folderId;

  const menu = document.getElementById('groupContextMenu');
  if (!menu) return;

  menu.style.left = `${Math.min(x, window.innerWidth - 200)}px`;
  menu.style.top = `${Math.min(y, window.innerHeight - 150)}px`;
  menu.classList.remove('hidden');
  activeContextMenu = menu;
}

function closeContextMenus() {
  if (activeContextMenu) {
    activeContextMenu.classList.add('hidden');
    activeContextMenu = null;
  }
}

// ========================================================
// SEARCH BAR LOGIC
// ========================================================
function setSearchEngine(engineKey) {
  const eng = SEARCH_ENGINES[engineKey];
  if (!eng) return;
  currentSearchEngine = engineKey;

  const iconEl = document.getElementById('searchEngineIcon');
  if (iconEl) iconEl.innerHTML = eng.iconSvg;

  const selector = document.getElementById('searchEngineSelector');
  if (selector) selector.setAttribute('title', `${t('searchEngineSelectorTitle') || 'Поисковик'}: ${eng.name}`);

  // Highlight active option in dropdown
  document.querySelectorAll('.engine-opt').forEach(opt => {
    opt.classList.toggle('active', opt.dataset.engine === engineKey);
  });
}

function performSearch(query) {
  const q = (query || '').trim();
  if (!q) return;

  // If it's a direct URL or domain
  if (/^https?:\/\//i.test(q)) {
    window.location.href = q;
    return;
  }
  if (/^[a-zA-Z0-9-]+\.[a-zA-Z]{2,}(\/.*)?$/.test(q)) {
    window.location.href = 'https://' + q;
    return;
  }

  // Otherwise perform search
  const eng = SEARCH_ENGINES[currentSearchEngine] || SEARCH_ENGINES.google;
  window.location.href = eng.url + encodeURIComponent(q);
}

// ========================================================
// DIAL MODAL (CREATE / EDIT)
// ========================================================
function openDialModal(dial, preselectedGroupId = null) {
  editingDialId = dial ? dial.id : null;

  const modal = document.getElementById('dialModal');
  const modalTitle = document.getElementById('dialModalTitle');
  const inputFolder = document.getElementById('modalDialFolder');
  const selectGroup = document.getElementById('modalDialGroup');
  const inputName = document.getElementById('modalDialName');
  const inputUrl = document.getElementById('modalDialUrl');
  const inputScreenshotUrl = document.getElementById('modalScreenshotUrl');
  const customColor = document.getElementById('modalCustomColor');

  modalTitle.textContent = dial ? 'Редактировать сайт' : 'Добавить новый сайт';

  // Populate Folders
  inputFolder.innerHTML = '';
  state.folders.ids.forEach(fId => {
    const f = state.folders.byId[fId];
    if (f) {
      const opt = document.createElement('option');
      opt.value = fId;
      opt.textContent = f.name;
      opt.selected = dial ? dial.folderId === fId : fId === state.activeFolderId;
      inputFolder.appendChild(opt);
    }
  });

  // Populate Groups for currently selected folder
  const populateModalGroups = () => {
    if (!selectGroup) return;
    const targetFid = inputFolder.value || state.activeFolderId;
    const f = state.folders.byId[targetFid];
    const groups = (f && f.groups) || [];
    selectGroup.innerHTML = '<option value="">(Без группы)</option>';
    groups.forEach(g => {
      const opt = document.createElement('option');
      opt.value = g.id;
      opt.textContent = g.name;
      selectGroup.appendChild(opt);
    });

    const activeGid = dial ? (dial.groupId || '') : (preselectedGroupId || '');
    selectGroup.value = activeGid;
  };

  populateModalGroups();
  inputFolder.onchange = populateModalGroups;

  inputName.value = dial ? dial.name : '';
  inputUrl.value = dial ? dial.url : '';

  const inputLogoUrl = document.getElementById('modalLogoUrl');
  if (inputLogoUrl) inputLogoUrl.value = dial ? (dial.logoUrl || '') : '';
  const inputLogoFile = document.getElementById('modalLogoFile');
  if (inputLogoFile) inputLogoFile.value = '';

  modalCurrentTileType = dial ? (dial.tileType || (dial.screenshotUrl ? 'screenshot' : 'logo')) : 'screenshot';
  modalCurrentScreenshot = dial ? (dial.screenshotUrl || (dial.type === 'image' ? dial.imgUrl : '')) : '';
  if (inputScreenshotUrl) inputScreenshotUrl.value = modalCurrentScreenshot;

  document.querySelectorAll('#modalTileTypeControl .segment-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.type === modalCurrentTileType);
  });

  let bg = dial ? dial.bgcolor || '#2d2d2d' : '#2d2d2d';
  if (dial && (bg === '#fff' || bg === '#ffffff' || bg === '#2d2d2d')) {
    const brand = getBrandColorForUrl(dial.url, dial.name);
    if (brand) bg = brand.bgcolor;
  }
  customColor.value = bg.startsWith('#') ? bg : '#2d2d2d';
  document.querySelectorAll('#modalColorPalette .color-swatch').forEach(swatch => {
    swatch.classList.toggle('active', swatch.dataset.color.toLowerCase() === bg.toLowerCase());
  });

  updateModalDialPreview();
  modal.classList.remove('hidden');
}

function updateModalDialPreview() {
  const previewThumbArea = document.getElementById('modalPreviewThumbArea');
  const previewScreenshot = document.getElementById('modalPreviewScreenshot');
  const previewLogoWrap = document.getElementById('modalPreviewLogoWrap');
  const previewIcon = document.getElementById('modalPreviewIcon');
  const previewFooterFavicon = document.getElementById('modalPreviewFooterFavicon');
  const previewName = document.getElementById('modalPreviewName');
  const previewDomain = document.getElementById('modalPreviewDomain');
  const inputName = document.getElementById('modalDialName');
  const inputUrl = document.getElementById('modalDialUrl');
  const customColor = document.getElementById('modalCustomColor');
  const screenshotGroup = document.getElementById('modalScreenshotGroup');
  const colorGroup = document.getElementById('modalColorPaletteGroup');

  const name = inputName.value.trim() || 'Название';
  const url = inputUrl.value.trim();
  const domain = extractDomain(url) || 'example.com';
  const color = customColor.value || '#2d2d2d';
  const favUrl = getFaviconUrl(url);
  const letterInfo = getLetterBadgeInfo(name, url);

  if (previewName) previewName.textContent = name;
  if (previewDomain) previewDomain.textContent = domain;

  const showFooterLetterBadge = () => {
    if (previewFooterFavicon) previewFooterFavicon.style.display = 'none';
    let badge = previewFooterFavicon?.parentElement.querySelector('.dial-footer-letter-badge');
    if (!badge && previewFooterFavicon?.parentElement) {
      badge = document.createElement('div');
      badge.className = 'dial-footer-letter-badge';
      previewFooterFavicon.parentElement.prepend(badge);
    }
    if (badge) {
      badge.style.display = 'flex';
      badge.style.backgroundColor = letterInfo.bgColor;
      badge.textContent = letterInfo.letter;
    }
  };

  if (previewFooterFavicon) {
    if (!favUrl || isKnownBadFavicon(url)) {
      showFooterLetterBadge();
    } else {
      const existingBadge = previewFooterFavicon.parentElement.querySelector('.dial-footer-letter-badge');
      if (isKnownValidFavicon(url)) {
        if (existingBadge) existingBadge.style.display = 'none';
        previewFooterFavicon.style.display = 'block';
        previewFooterFavicon.src = favUrl;
      } else {
        showFooterLetterBadge();
        checkFaviconValid(url, favUrl).then(isValid => {
          if (isValid) {
            if (existingBadge) existingBadge.style.display = 'none';
            previewFooterFavicon.style.display = 'block';
            previewFooterFavicon.src = favUrl;
          } else {
            showFooterLetterBadge();
          }
        });
      }
      previewFooterFavicon.onerror = () => {
        markBadFavicon(url);
        showFooterLetterBadge();
      };
    }
  }

  function applyLogoBadge(container, imgEl) {
    const showLogoLetterBadge = () => {
      if (imgEl) imgEl.style.display = 'none';
      let badge = container.querySelector('.dial-logo-letter-badge');
      if (!badge) {
        badge = document.createElement('div');
        badge.className = 'dial-logo-letter-badge';
        container.appendChild(badge);
      }
      badge.style.display = 'flex';
      badge.style.backgroundColor = letterInfo.bgColor;
      badge.textContent = letterInfo.letter;
    };

    if (!favUrl || isKnownBadFavicon(url)) {
      showLogoLetterBadge();
    } else {
      const existingBadge = container.querySelector('.dial-logo-letter-badge');
      if (isKnownValidFavicon(url)) {
        if (existingBadge) existingBadge.style.display = 'none';
        if (imgEl) {
          imgEl.style.display = 'block';
          imgEl.src = favUrl;
        }
      } else {
        showLogoLetterBadge();
        checkFaviconValid(url, favUrl).then(isValid => {
          if (isValid) {
            if (existingBadge) existingBadge.style.display = 'none';
            if (imgEl) {
              imgEl.style.display = 'block';
              imgEl.src = favUrl;
            }
          } else {
            showLogoLetterBadge();
          }
        });
      }
      if (imgEl) {
        imgEl.onerror = () => {
          markBadFavicon(url);
          showLogoLetterBadge();
        };
      }
    }
  }

  const inputLogoUrl = document.getElementById('modalLogoUrl');
  const customLogoUrl = inputLogoUrl?.value.trim() || '';

  function renderPreviewLogoContent(container) {
    const existingBadge = container.querySelector('.dial-logo-letter-badge');
    if (existingBadge) existingBadge.remove();
    const existingCustomLogo = container.querySelector('.dial-custom-logo-img');
    if (existingCustomLogo) existingCustomLogo.remove();
    const existingBrandSvg = container.querySelector('svg');
    if (existingBrandSvg) existingBrandSvg.remove();

    if (customLogoUrl) {
      if (previewIcon) previewIcon.style.display = 'none';
      const img = document.createElement('img');
      img.className = 'dial-custom-logo-img';
      img.src = customLogoUrl;
      img.onerror = () => {
        img.remove();
        const brandSvg = getBrandLogoSvg(url);
        if (brandSvg) {
          container.insertAdjacentHTML('beforeend', brandSvg);
        } else {
          applyLogoBadge(container, previewIcon);
        }
      };
      container.appendChild(img);
      return;
    }

    const brandSvg = getBrandLogoSvg(url);
    if (brandSvg) {
      if (previewIcon) previewIcon.style.display = 'none';
      container.insertAdjacentHTML('beforeend', brandSvg);
      return;
    }

    applyLogoBadge(container, previewIcon);
  }

  if (modalCurrentTileType === 'screenshot') {
    screenshotGroup?.classList.remove('hidden');
    colorGroup?.classList.add('hidden');

    if (modalCurrentScreenshot) {
      if (previewScreenshot) {
        previewScreenshot.src = modalCurrentScreenshot;
        previewScreenshot.style.display = 'block';
      }
      if (previewLogoWrap) previewLogoWrap.style.display = 'none';
      if (previewThumbArea) previewThumbArea.style.backgroundColor = '#18181b';
    } else {
      if (previewScreenshot) previewScreenshot.style.display = 'none';
      if (previewLogoWrap) {
        previewLogoWrap.style.display = 'flex';
        previewLogoWrap.style.backgroundColor = '#252528';
        previewLogoWrap.style.color = '#ffffff';
        renderPreviewLogoContent(previewLogoWrap);
      }
    }
  } else {
    screenshotGroup?.classList.add('hidden');
    colorGroup?.classList.remove('hidden');

    if (previewScreenshot) previewScreenshot.style.display = 'none';
    if (previewLogoWrap) {
      previewLogoWrap.style.display = 'flex';
      previewLogoWrap.style.backgroundColor = color;
      previewLogoWrap.style.color = getContrastTextColor(color);
      renderPreviewLogoContent(previewLogoWrap);
    }
  }
}

// ========================================================
// DESKTOP MODAL (CREATE / EDIT)
// ========================================================
function openFolderModal(folder) {
  editingFolderId = folder ? folder.id : null;

  const modal = document.getElementById('folderModal');
  const modalTitle = document.getElementById('folderModalTitle');
  const inputName = document.getElementById('modalFolderName');
  const grid = document.getElementById('iconPickerGrid');

  modalTitle.textContent = folder ? 'Редактировать стол' : 'Создать рабочий стол';
  inputName.value = folder ? folder.name : '';

  // Render Icon Picker
  grid.innerHTML = '';
  const currentIcon = folder ? folder.icon || 'folder' : 'folder';

  Object.keys(ICONS).forEach(iconKey => {
    const item = document.createElement('div');
    item.className = 'icon-picker-item' + (iconKey === currentIcon ? ' active' : '');
    item.dataset.icon = iconKey;
    item.innerHTML = ICONS[iconKey];
    item.title = iconKey;

    item.addEventListener('click', () => {
      grid.querySelectorAll('.icon-picker-item').forEach(i => i.classList.remove('active'));
      item.classList.add('active');
    });

    grid.appendChild(item);
  });

  modal.classList.remove('hidden');
  inputName.focus();
}

// ========================================================
// DESKTOP GROUP MODAL (CREATE / EDIT)
// ========================================================
function openGroupModal(group, folderId) {
  editingGroupId = group ? group.id : null;
  editingGroupFolderId = folderId || state.activeFolderId;

  const modal = document.getElementById('groupModal');
  const modalTitle = document.getElementById('groupModalTitle');
  const inputName = document.getElementById('modalGroupName');

  if (modalTitle) modalTitle.textContent = group ? 'Редактировать группу' : 'Создать группу на столе';
  if (inputName) inputName.value = group ? group.name : '';

  const currentColor = group ? group.color || '#0078d7' : '#0078d7';
  document.querySelectorAll('#groupColorPalette .color-swatch').forEach(sw => {
    sw.classList.toggle('active', sw.dataset.color.toLowerCase() === currentColor.toLowerCase());
  });

  modal?.classList.remove('hidden');
  inputName?.focus();
}


// ========================================================
// WIDGET SETTINGS MODAL (ВИДЖЕТЫ-ПЛИТКИ)
// ========================================================
let editingWidgetDial = null;
function openWidgetSettingsModal(widgetDial) {
  editingWidgetDial = widgetDial;
  const modal = document.getElementById('widgetSettingsModal');
  const title = document.getElementById('widgetModalTitle');
  const body = document.getElementById('widgetModalBody');
  if (!modal || !body) return;

  const cfg = widgetDial.widgetConfig || {};
  const type = widgetDial.widgetType || 'clock';
  const size = widgetDial.widgetSize || '1x1';

  title.textContent = `${t('widgetModalTitle')}: ${getWidgetTitle(widgetDial)}`;
  body.innerHTML = '';

  if (type === 'clock') {
    const fontSize = cfg.fontSize || 'normal';
    body.innerHTML = `
      <div class="form-group">
        <label>${t('wSetTimezone')}</label>
        <select id="wSetTimezone" class="form-input">
          ${buildTimezoneSelectHtml(cfg.timezone)}
        </select>
      </div>
      <div class="form-group" style="display: flex; gap: 14px; margin-top: 10px;">
        <label style="display: flex; align-items: center; gap: 6px; cursor: pointer;">
          <input type="checkbox" id="wSetSeconds" ${cfg.showSeconds !== false ? 'checked' : ''}>
          <span>${t('wSetSeconds')}</span>
        </label>
        <label style="display: flex; align-items: center; gap: 6px; cursor: pointer;">
          <input type="checkbox" id="wSet24h" ${cfg.is24Hour !== false ? 'checked' : ''}>
          <span>${t('wSet24h')}</span>
        </label>
      </div>
      <div class="form-group" style="margin-top: 10px;">
        <label>${t('wSetFontSize')}</label>
        <select id="wSetFontSize" class="form-input">
          <option value="normal" ${fontSize === 'normal' ? 'selected' : ''}>${t('wFontNormal')}</option>
          <option value="large" ${fontSize === 'large' ? 'selected' : ''}>${t('wFontLarge')}</option>
          <option value="huge" ${fontSize === 'huge' ? 'selected' : ''}>${t('wFontHuge')}</option>
        </select>
      </div>
      <div class="form-group" style="margin-top: 10px;">
        <label>${t('wSetSize')}</label>
        <select id="wSetSize" class="form-input">
          <option value="1x1" ${size === '1x1' ? 'selected' : ''}>${t('wSize1x1')}</option>
          <option value="2x1" ${size === '2x1' ? 'selected' : ''}>${t('wSize2x1')}</option>
        </select>
      </div>
    `;
  } else if (type === 'weather') {
    const curCity = cfg.city || (getLanguage() === 'ru' ? 'Москва' : 'London');
    const fontSize = cfg.fontSize || 'normal';
    body.innerHTML = `
      <div class="form-group">
        <label>${t('wSetCity')}</label>
        <input type="text" id="wSetCity" class="form-input" value="${curCity}" placeholder="${t('wSetCityPlaceholder')}">
        <div id="wCityFeedback" style="font-size: 11.5px; margin-top: 5px; min-height: 18px; line-height: 1.4;"></div>
      </div>
      <div class="form-group" style="margin-top: 10px;">
        <label>${t('wSetUnits')}</label>
        <select id="wSetUnits" class="form-input">
          <option value="c" ${cfg.units !== 'f' ? 'selected' : ''}>${t('wSetUnitsC')}</option>
          <option value="f" ${cfg.units === 'f' ? 'selected' : ''}>${t('wSetUnitsF')}</option>
        </select>
      </div>
      <div class="form-group" style="margin-top: 10px;">
        <label>${t('wSetFontSize')}</label>
        <select id="wSetFontSize" class="form-input">
          <option value="normal" ${fontSize === 'normal' ? 'selected' : ''}>${t('wFontNormal')}</option>
          <option value="large" ${fontSize === 'large' ? 'selected' : ''}>${t('wFontLarge')}</option>
          <option value="huge" ${fontSize === 'huge' ? 'selected' : ''}>${t('wFontHuge')}</option>
        </select>
      </div>
      <div class="form-group" style="margin-top: 10px;">
        <label>${t('wSetSize')}</label>
        <select id="wSetSize" class="form-input">
          <option value="1x1" ${size === '1x1' ? 'selected' : ''}>${t('wSize1x1')}</option>
          <option value="2x1" ${size === '2x1' ? 'selected' : ''}>${t('wSize2x1')}</option>
        </select>
      </div>
    `;

    const cityInput = body.querySelector('#wSetCity');
    const feedbackEl = body.querySelector('#wCityFeedback');

    const validateCityInput = debounce(async (val) => {
      const q = (val || '').trim();
      if (!q) {
        if (feedbackEl) feedbackEl.innerHTML = '';
        return;
      }
      if (feedbackEl) {
        feedbackEl.innerHTML = `<span style="color: var(--text-muted, #94a3b8);">⏳ ${t('wCityValidating')}</span>`;
      }
      try {
        const lang = getLanguage() === 'ru' ? 'ru' : 'en';
        const res = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=1&language=${lang}`);
        if (res.ok) {
          const data = await res.json();
          if (data.results && data.results.length > 0) {
            const item = data.results[0];
            const locInfo = `${item.name}${item.admin1 ? ', ' + item.admin1 : ''}${item.country ? ' (' + item.country + ')' : ''}`;
            if (feedbackEl) {
              feedbackEl.innerHTML = `<span style="color: #4ade80;">✓ ${t('wCityFound')} <strong>${locInfo}</strong></span>`;
            }
            if (cityInput) cityInput.dataset.validatedCity = item.name;
          } else {
            if (feedbackEl) {
              feedbackEl.innerHTML = `<span style="color: #f87171;">⚠️ ${t('wCityNotFound')}</span>`;
            }
            if (cityInput) delete cityInput.dataset.validatedCity;
          }
        }
      } catch (err) {
        if (feedbackEl) feedbackEl.innerHTML = '';
      }
    }, 350);

    cityInput?.addEventListener('input', (e) => {
      validateCityInput(e.target.value);
    });

    if (curCity) {
      validateCityInput(curCity);
    }
  } else if (type === 'rates') {
    let currentTokens = [...(cfg.items || ['USD', 'EUR', 'BTC'])];
    const popularList = ['USD', 'EUR', 'RUB', 'CNY', 'BTC', 'ETH', 'SOL', 'TON', 'TRY', 'AED', 'KZT', 'DOGE', 'XRP'];
    let validatedTokenToAdd = null;
    const fontSize = cfg.fontSize || 'normal';
    const baseCurrency = cfg.baseCurrency || 'RUB';

    const getMaxLimit = () => {
      const curSize = body.querySelector('#wSetSize')?.value || size;
      return curSize === '2x1' ? 8 : 4;
    };

    body.innerHTML = `
      <div class="form-group" style="margin-bottom: 12px;">
        <label>${t('wSetBaseCurrency')}</label>
        <select id="wSetBaseCurrency" class="form-input">
          ${BASE_CURRENCIES.map(c => {
            const name = getLanguage() === 'en' ? c.nameEn : c.nameRu;
            return `<option value="${c.code}" ${baseCurrency === c.code ? 'selected' : ''}>${c.code} — ${name} (${c.sym})</option>`;
          }).join('')}
        </select>
        <div style="font-size: 11.5px; color: var(--text-muted); margin-top: 4px;">${t('wBaseCurrencyHint')}</div>
      </div>
      <div class="form-group">
        <label>${t('wSetCurrencies')}</label>
        <div style="font-size: 11.5px; color: var(--text-muted); margin-bottom: 6px;">${t('wRateMaxItemsHint')}</div>

        <div style="display: flex; justify-content: space-between; align-items: baseline; margin-top: 6px;">
          <div style="font-size: 11.5px; font-weight: 600;">${t('wRateSelected')}</div>
          <div id="rateCountBadge" style="font-size: 11.5px; font-weight: 700;"></div>
        </div>
        <div id="rateSelectedChips" class="rate-selected-chips"></div>

        <div style="font-size: 11.5px; font-weight: 600; margin-top: 10px;">${t('wRatePopular')}</div>
        <div id="ratePopularPills" class="rate-popular-pills"></div>

        <div style="margin-top: 12px;">
          <div class="select-row">
            <input type="text" id="wSearchRateInput" class="form-input" placeholder="${t('wRateSearchPlaceholder')}">
            <button type="button" id="wBtnAddRateToken" class="btn-primary" disabled style="white-space: nowrap; padding: 0 14px;">
              ${t('wRateAddBtn')}
            </button>
          </div>
          <div id="wRateFeedback" style="font-size: 11.5px; margin-top: 5px; min-height: 18px; line-height: 1.4;"></div>
        </div>
      </div>
      <div class="form-group" style="margin-top: 10px;">
        <label>${t('wSetFontSize')}</label>
        <select id="wSetFontSize" class="form-input">
          <option value="normal" ${fontSize === 'normal' ? 'selected' : ''}>${t('wFontNormal')}</option>
          <option value="large" ${fontSize === 'large' ? 'selected' : ''}>${t('wFontLarge')}</option>
          <option value="huge" ${fontSize === 'huge' ? 'selected' : ''}>${t('wFontHuge')}</option>
        </select>
      </div>
      <div class="form-group" style="margin-top: 12px;">
        <label>${t('wSetSize')}</label>
        <select id="wSetSize" class="form-input">
          <option value="1x1" ${size === '1x1' ? 'selected' : ''}>${t('wSize1x1')}</option>
          <option value="2x1" ${size === '2x1' ? 'selected' : ''}>${t('wSize2x1')}</option>
        </select>
      </div>
    `;

    const searchInput = body.querySelector('#wSearchRateInput');
    const addBtn = body.querySelector('#wBtnAddRateToken');
    const feedbackEl = body.querySelector('#wRateFeedback');
    const baseCurrencySelect = body.querySelector('#wSetBaseCurrency');

    const handleValidation = debounce(async (val) => {
      const q = (val || '').trim();
      if (!q) {
        if (feedbackEl) feedbackEl.innerHTML = '';
        if (addBtn) addBtn.disabled = true;
        validatedTokenToAdd = null;
        return;
      }
      const maxLim = getMaxLimit();
      const curSize = body.querySelector('#wSetSize')?.value || size;
      if (currentTokens.length >= maxLim) {
        if (feedbackEl) {
          feedbackEl.innerHTML = `<span style="color: #f59e0b;">⚠️ ${t('wRateLimitReached', { max: maxLim, size: curSize })}</span>`;
        }
        if (addBtn) addBtn.disabled = true;
        validatedTokenToAdd = null;
        return;
      }
      if (feedbackEl) {
        feedbackEl.innerHTML = `<span style="color: var(--text-muted, #94a3b8);">⏳ ${t('wRateValidating')}</span>`;
      }
      try {
        const curBase = baseCurrencySelect?.value || baseCurrency;
        const result = await validateCurrencyOrCrypto(q, curBase);
        if (result && result.found) {
          validatedTokenToAdd = result;
          const isAlready = currentTokens.includes(result.code);
          if (isAlready) {
            feedbackEl.innerHTML = `<span style="color: #facc15;">⚠️ <strong>${result.code}</strong> — ${t('wRateAlreadyAdded')}</span>`;
            if (addBtn) addBtn.disabled = true;
          } else {
            const prefix = result.type === 'fiat' ? t('wRateFoundFiat') : t('wRateFoundCrypto');
            feedbackEl.innerHTML = `<span style="color: #4ade80;">✓ ${prefix} <strong>${result.code}</strong>${result.name && result.name !== result.code ? ' (' + result.name + ')' : ''} ~ ${result.val}</span>`;
            if (addBtn) addBtn.disabled = false;
          }
        } else {
          validatedTokenToAdd = null;
          if (feedbackEl) {
            feedbackEl.innerHTML = `<span style="color: #f87171;">⚠️ ${t('wRateNotFound')}</span>`;
          }
          if (addBtn) addBtn.disabled = true;
        }
      } catch (err) {
        validatedTokenToAdd = null;
        if (feedbackEl) feedbackEl.innerHTML = '';
        if (addBtn) addBtn.disabled = true;
      }
    }, 300);

    const renderTokensUi = () => {
      const chipsEl = body.querySelector('#rateSelectedChips');
      const pillsEl = body.querySelector('#ratePopularPills');
      const countBadge = body.querySelector('#rateCountBadge');
      if (!chipsEl || !pillsEl) return;

      const maxLimit = getMaxLimit();
      if (countBadge) {
        countBadge.textContent = `${currentTokens.length} / ${maxLimit}`;
        countBadge.style.color = currentTokens.length >= maxLimit ? '#f59e0b' : 'var(--text-muted)';
      }

      if (currentTokens.length === 0) {
        chipsEl.innerHTML = `<span style="font-size: 11.5px; color: var(--text-muted);">${t('wRateEmptySelected')}</span>`;
      } else {
        chipsEl.innerHTML = currentTokens.map(tok => `
          <span class="rate-chip">
            <span>${tok}</span>
            <span class="rate-chip-remove" data-token="${tok}" title="${t('ctxDeleteDial')}">✕</span>
          </span>
        `).join('');

        chipsEl.querySelectorAll('.rate-chip-remove').forEach(btn => {
          btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const tok = btn.dataset.token;
            currentTokens = currentTokens.filter(x => x !== tok);
            renderTokensUi();
            if (feedbackEl) feedbackEl.innerHTML = '';
            if (searchInput && searchInput.value.trim()) {
              handleValidation(searchInput.value);
            }
          });
        });
      }

      pillsEl.innerHTML = popularList.map(tok => {
        const isActive = currentTokens.includes(tok);
        return `<span class="rate-pill ${isActive ? 'active' : ''}" data-token="${tok}">${isActive ? '✓ ' : '+ '}${tok}</span>`;
      }).join('');

      pillsEl.querySelectorAll('.rate-pill').forEach(pill => {
        pill.addEventListener('click', () => {
          const tok = pill.dataset.token;
          if (currentTokens.includes(tok)) {
            currentTokens = currentTokens.filter(x => x !== tok);
            renderTokensUi();
            if (feedbackEl) feedbackEl.innerHTML = '';
            if (searchInput && searchInput.value.trim()) {
              handleValidation(searchInput.value);
            }
          } else {
            const maxLim = getMaxLimit();
            const curSize = body.querySelector('#wSetSize')?.value || size;
            if (currentTokens.length >= maxLim) {
              if (feedbackEl) {
                feedbackEl.innerHTML = `<span style="color: #f59e0b;">⚠️ ${t('wRateLimitReached', { max: maxLim, size: curSize })}</span>`;
              }
              return;
            }
            currentTokens.push(tok);
            renderTokensUi();
            if (feedbackEl) feedbackEl.innerHTML = '';
            if (searchInput && searchInput.value.trim()) {
              handleValidation(searchInput.value);
            }
          }
        });
      });
    };

    renderTokensUi();

    body.querySelector('#wSetSize')?.addEventListener('change', () => {
      renderTokensUi();
      if (feedbackEl) feedbackEl.innerHTML = '';
      if (searchInput && searchInput.value.trim()) {
        handleValidation(searchInput.value);
      }
    });

    baseCurrencySelect?.addEventListener('change', () => {
      if (searchInput && searchInput.value.trim()) {
        handleValidation(searchInput.value);
      }
    });

    searchInput?.addEventListener('input', (e) => {
      handleValidation(e.target.value);
    });

    const addValidatedToken = () => {
      if (!validatedTokenToAdd) return;
      const maxLim = getMaxLimit();
      const curSize = body.querySelector('#wSetSize')?.value || size;
      if (currentTokens.length >= maxLim) {
        if (feedbackEl) {
          feedbackEl.innerHTML = `<span style="color: #f59e0b;">⚠️ ${t('wRateLimitReached', { max: maxLim, size: curSize })}</span>`;
        }
        return;
      }
      if (!currentTokens.includes(validatedTokenToAdd.code)) {
        currentTokens.push(validatedTokenToAdd.code);
        renderTokensUi();
        if (searchInput) searchInput.value = '';
        if (feedbackEl) feedbackEl.innerHTML = '';
        if (addBtn) addBtn.disabled = true;
        validatedTokenToAdd = null;
      }
    };

    addBtn?.addEventListener('click', addValidatedToken);
    searchInput?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        addValidatedToken();
      }
    });

    modal._currentRateTokens = () => currentTokens;
  } else if (type === 'note') {
    const color = cfg.color || 'amber';
    const mode = cfg.mode || 'todos';
    const fontSize = cfg.fontSize || 'normal';
    const scope = cfg.syncScope || (cfg.text !== undefined || cfg.todos !== undefined ? 'independent' : 'global');
    body.innerHTML = `
      <div class="form-group">
        <label>${t('wSetStickerColor')}</label>
        <div style="display: flex; gap: 8px; margin-top: 6px; flex-wrap: wrap;" id="wNoteColorPicker">
          ${[
            { id: 'amber', bg: '#f59e0b', name: t('colorAmber') },
            { id: 'cyan', bg: '#06b6d4', name: t('colorCyan') },
            { id: 'blue', bg: '#0078d7', name: t('colorBlue') },
            { id: 'green', bg: '#107c41', name: t('colorGreen') },
            { id: 'purple', bg: '#9146ff', name: t('colorPurple') },
            { id: 'slate', bg: '#64748b', name: t('colorSlate') }
          ].map(c => `
            <div class="color-swatch ${color === c.id ? 'active' : ''}" data-color="${c.id}" title="${c.name}" style="background:${c.bg}; width: 28px; height: 28px; border-radius: 6px; cursor: pointer;"></div>
          `).join('')}
        </div>
      </div>
      <div class="form-group" style="margin-top: 10px;">
        <label>${t('wSetFontSize')}</label>
        <select id="wSetFontSize" class="form-input">
          <option value="normal" ${fontSize === 'normal' ? 'selected' : ''}>${t('wFontNormal')}</option>
          <option value="large" ${fontSize === 'large' ? 'selected' : ''}>${t('wFontLarge')}</option>
          <option value="huge" ${fontSize === 'huge' ? 'selected' : ''}>${t('wFontHuge')}</option>
        </select>
      </div>
      <div class="form-group" style="margin-top: 10px;">
        <label>${t('wSetDefaultTab')}</label>
        <select id="wSetMode" class="form-input">
          <option value="todos" ${mode !== 'notes' ? 'selected' : ''}>☑️ ${t('widgetTabTodos')}</option>
          <option value="notes" ${mode === 'notes' ? 'selected' : ''}>✍️ ${t('widgetTabNotes')}</option>
        </select>
      </div>
      <div class="form-group" style="margin-top: 10px;">
        <label>${t('wSetSize')}</label>
        <select id="wSetSize" class="form-input">
          <option value="1x1" ${size === '1x1' ? 'selected' : ''}>${t('wSize1x1')}</option>
          <option value="2x1" ${size === '2x1' ? 'selected' : ''}>${t('wSize2x1')}</option>
          <option value="2x2" ${size === '2x2' ? 'selected' : ''}>${t('wSize2x2')}</option>
          <option value="4x1" ${size === '4x1' ? 'selected' : ''}>${t('wSize4x1')}</option>
        </select>
      </div>
      <div class="form-group" style="margin-top: 10px;">
        <label>${t('wSetScope')}</label>
        <select id="wSetScope" class="form-input">
          <option value="independent" ${scope === 'independent' ? 'selected' : ''}>${t('wScopeIndependent')}</option>
          <option value="global" ${scope === 'global' ? 'selected' : ''}>${t('wScopeGlobal')}</option>
          <option value="local" ${scope === 'local' ? 'selected' : ''}>${t('wScopeLocal')}</option>
        </select>
      </div>
    `;

    body.querySelectorAll('#wNoteColorPicker .color-swatch').forEach(sw => {
      sw.addEventListener('click', () => {
        body.querySelectorAll('#wNoteColorPicker .color-swatch').forEach(s => s.classList.remove('active'));
        sw.classList.add('active');
      });
    });
  }

  // Common: Pin / Freeze setting for widget
  const pinGroup = document.createElement('div');
  pinGroup.className = 'form-group';
  pinGroup.style.marginTop = '12px';
  pinGroup.style.paddingTop = '10px';
  pinGroup.style.borderTop = '1px solid rgba(255, 255, 255, 0.08)';
  pinGroup.innerHTML = `
    <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; user-select: none;">
      <input type="checkbox" id="wSetPinned" ${widgetDial.isPinned ? 'checked' : ''}>
      <span style="display: inline-flex; align-items: center; gap: 6px; font-size: 13px; font-weight: 500;">
        <span style="display: inline-flex; align-items: center; color: var(--accent, #0078d7);">${ICON_LOCKED}</span>
        ${t('wSetPinned')}
      </span>
    </label>
  `;
  body.appendChild(pinGroup);

  modal.classList.remove('hidden');
}

// ========================================================
// SETTINGS MODAL & CLOUD SYNC
// ========================================================
function openSettingsModal() {
  const modal = document.getElementById('settingsModal');
  const cfg = state.settings || {};

  const manifestVersion = (typeof chrome !== 'undefined' && chrome.runtime?.getManifest?.()?.version) || '6.4.0';
  const verEl = document.getElementById('settingsVersionLabel');
  if (verEl) verEl.textContent = `v${manifestVersion}`;

  // Tab 1: General
  const currentLang = cfg.language || 'auto';
  document.querySelectorAll('#languageModeControl .segment-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.lang === currentLang);
  });
  const currentTheme = cfg.theme || 'system';
  document.querySelectorAll('#themeModeControl .segment-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.theme === currentTheme);
  });
  const currentStyle = cfg.style || 'w11';
  document.querySelectorAll('#styleModeControl .segment-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.style === currentStyle);
  });
  document.getElementById('cfgShowSearchbar').checked = cfg.showSearchbar !== false;
  document.getElementById('cfgSearchEngine').value = cfg.searchEngine || 'google';
  document.getElementById('cfgOpenInNewTab').checked = cfg.openInNewTab || false;

  const cfgShowDeskSearch = document.getElementById('cfgShowDeskSearch');
  if (cfgShowDeskSearch) cfgShowDeskSearch.checked = cfg.showDeskSearch !== false;

  // Tab 2: Dials (Size scale & spacing)
  const size = Math.max(180, cfg.dialSize || cfg.dialWidth || 180);
  const sp = cfg.dialSpacing !== undefined ? cfg.dialSpacing : 6;
  const sSize = document.getElementById('sliderDialSize');
  const sSp = document.getElementById('sliderDialSpacing');
  if (sSize) sSize.value = size;
  if (sSp) sSp.value = sp;
  const valSize = document.getElementById('valDialSize');
  const valSp = document.getElementById('valDialSpacing');
  if (valSize) valSize.textContent = size + 'px';
  if (valSp) valSp.textContent = sp + 'px';

  const currentTilesFontSize = cfg.tilesFontSize || 'normal';
  document.querySelectorAll('#tilesFontSizeControl .segment-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tilesize === currentTilesFontSize);
  });

  // Tab 3: Wallpaper / Background
  const bg = cfg.background || {};
  const isColor = bg.type === 'color' || !bg.url;

  document.querySelectorAll('#bgModeControl .segment-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.bgmode === (isColor ? 'color' : 'wall'));
  });

  const solidSec = document.getElementById('bgSolidColorSection');
  const imgSec = document.getElementById('bgImageSection');
  if (solidSec && imgSec) {
    if (isColor) {
      solidSec.classList.remove('hidden');
      imgSec.classList.add('hidden');
    } else {
      solidSec.classList.add('hidden');
      imgSec.classList.remove('hidden');
    }
  }

  const currentColor = bg.color || '#0f1015';
  const customColorInput = document.getElementById('cfgBgSolidColor');
  if (customColorInput) customColorInput.value = currentColor;

  document.querySelectorAll('#bgColorPalette .color-swatch').forEach(swatch => {
    swatch.classList.toggle('active', swatch.dataset.color.toLowerCase() === currentColor.toLowerCase());
  });

  document.getElementById('cfgCustomWallpaperUrl').value = bg.url || '';
  const op = Math.round((bg.overlayOpacity !== undefined ? bg.overlayOpacity : 0.15) * 100);
  document.getElementById('sliderOverlayOpacity').value = op;
  document.getElementById('valOverlayOpacity').textContent = op + '%';

  // Tab 4: Cloud
  const gd = cfg.googleDrive || {};
  document.getElementById('cfgGdriveClientId').value = gd.clientId || '';
  updateGdriveUI(gd);

  const lblRedirectUri = document.getElementById('lblRedirectUri');
  if (lblRedirectUri && typeof chrome !== 'undefined' && chrome.identity && chrome.identity.getRedirectURL) {
    lblRedirectUri.textContent = chrome.identity.getRedirectURL();
  }

  modal.classList.remove('hidden');
}

function updateGdriveUI(gd) {
  const badge = document.getElementById('gdriveStatusBadge');
  const lastSyncInfo = document.getElementById('gdriveLastSyncInfo');
  if (badge) {
    if (gd.connected) {
      badge.className = 'status-pill online';
      badge.textContent = 'Подключено';
    } else {
      badge.className = 'status-pill offline';
      badge.textContent = 'Не подключено';
    }
  }
  if (lastSyncInfo) {
    if (gd.lastSynced) {
      const dateStr = new Date(gd.lastSynced).toLocaleString('ru-RU');
      lastSyncInfo.textContent = `✓ Последняя синхронизация с Google Диском: ${dateStr}`;
    } else {
      lastSyncInfo.textContent = '';
    }
  }
}

// ========================================================
// SCREENSHOT CAPTURE HELPERS
// ========================================================
function waitForFirstTabLoad(tabId, timeoutMs = 7000) {
  return new Promise((resolve) => {
    if (!tabId) return resolve();
    chrome.tabs.get(tabId, (tab) => {
      if (chrome.runtime.lastError || !tab) return resolve();
      if (tab.status === 'complete') return resolve();

      let timer = null;
      const listener = (tid, changeInfo) => {
        if (tid === tabId && changeInfo.status === 'complete') {
          cleanup();
          resolve();
        }
      };

      const cleanup = () => {
        clearTimeout(timer);
        if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.onUpdated) {
          chrome.tabs.onUpdated.removeListener(listener);
        }
      };

      timer = setTimeout(() => {
        cleanup();
        resolve();
      }, timeoutMs);

      if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.onUpdated) {
        chrome.tabs.onUpdated.addListener(listener);
      }
    });
  });
}

async function captureTabScreenshot(windowId) {
  // Bring window to front and allow OS compositor to draw
  await new Promise(r => chrome.windows.update(windowId, { focused: true }, r));
  await new Promise(r => setTimeout(r, 450));

  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ action: 'captureWindowTab', windowId }, (res) => {
      if (!chrome.runtime.lastError && res && res.dataUrl) {
        return resolve(res.dataUrl);
      }
      chrome.tabs.captureVisibleTab(windowId, { format: 'jpeg', quality: 86 }, (captured) => {
        if (!chrome.runtime.lastError && captured) {
          return resolve(captured);
        }
        setTimeout(() => {
          chrome.tabs.captureVisibleTab(windowId, { format: 'jpeg', quality: 86 }, (retry) => {
            if (chrome.runtime.lastError || !retry) {
              console.warn('captureVisibleTab error:', chrome.runtime.lastError?.message);
              resolve(null);
            } else {
              resolve(retry);
            }
          });
        }, 400);
      });
    });
  });
}

async function captureSingleDialScreenshot(dial) {
  if (!dial || !dial.url) return;
  const rawUrl = dial.url;
  if (isInternalOrNewTabUrl(rawUrl)) {
    showToast(getLanguage() === 'ru' ? 'Нельзя сделать снимок этой страницы' : 'Cannot capture this page');
    return;
  }
  const url = sanitizeUrl(rawUrl);
  showToast(getLanguage() === 'ru' ? 'Делаем снимок сайта...' : 'Capturing screenshot...');
  let win = null;
  try {
    win = await new Promise((resolve) => {
      chrome.windows.create({
        url,
        type: 'popup',
        width: 1024,
        height: 768,
        focused: true
      }, (w) => resolve(w));
    });
    if (win && win.id) {
      const tabs = await new Promise((res) => {
        chrome.tabs.query({ windowId: win.id }, res);
      });
      const tabId = tabs && tabs[0] ? tabs[0].id : null;
      await waitForFirstTabLoad(tabId, 6000);
      await new Promise(r => setTimeout(r, 600));

      const dataUrl = await captureTabScreenshot(win.id);
      if (dataUrl) {
        const resized = await resizeScreenshot(dataUrl, 560, 420);
        dial.screenshotUrl = resized;
        dial.tileType = 'screenshot';
        dial.type = 'image';
        dial.imgUrl = resized;
        await storage.updateDial(dial);
        state = await storage.getState();
        renderDials();
        showToast(getLanguage() === 'ru' ? '✓ Снимок успешно сохранен!' : '✓ Screenshot updated!');
      } else {
        showToast(getLanguage() === 'ru' ? 'Не удалось сделать снимок' : 'Could not capture screenshot');
      }
    }
  } catch (err) {
    console.warn('Error capturing single dial screenshot:', err);
    showToast(getLanguage() === 'ru' ? 'Ошибка при создании снимка' : 'Error capturing screenshot');
  } finally {
    if (win && win.id) {
      try {
        chrome.windows.remove(win.id);
      } catch (e) {}
    }
  }
}

// ========================================================
// EVENT LISTENERS SETUP
// ========================================================
function setupEventListeners() {
  // Document click closes context menus and dropdowns
  document.addEventListener('click', (e) => {
    closeContextMenus();
    document.getElementById('searchEngineDropdown')?.classList.add('hidden');
    document.getElementById('searchEngineSelector')?.classList.remove('open');
    const flyout = document.getElementById('clockCalendarFlyout');
    if (flyout && !flyout.classList.contains('hidden')) {
      if (!flyout.contains(e.target) && !activeCalendarAnchor?.contains(e.target)) {
        closeClockCalendar();
      }
    }
  });

  // Search submit
  const searchInput = document.getElementById('searchInput');
  const searchSubmit = document.getElementById('searchSubmit');
  const searchSelector = document.getElementById('searchEngineSelector');
  const searchDropdown = document.getElementById('searchEngineDropdown');

  searchSubmit?.addEventListener('click', () => performSearch(searchInput.value));
  searchInput?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') performSearch(searchInput.value);
  });

  searchSelector?.addEventListener('click', (e) => {
    e.stopPropagation();
    const isHidden = searchDropdown?.classList.toggle('hidden');
    searchSelector.classList.toggle('open', !isHidden);
  });

  document.querySelectorAll('.engine-opt').forEach(opt => {
    opt.addEventListener('click', () => {
      const eng = opt.dataset.engine;
      setSearchEngine(eng);
      storage.updateSettings({ searchEngine: eng });
      searchDropdown?.classList.add('hidden');
      searchSelector?.classList.remove('open');
    });
  });

  // Sidebar Add Desktop Button & Wheel Scroll
  const sidebar = document.getElementById('sidebar');
  sidebar?.addEventListener('wheel', (e) => {
    const list = document.getElementById('desktopList');
    if (list) {
      list.scrollTop += e.deltaY;
    }
  }, { passive: true });

  document.getElementById('btnAddDesktop')?.addEventListener('click', () => {
    openFolderModal(null);
  });

  // Top Bar Actions
  document.getElementById('btnOpenSettings')?.addEventListener('click', openSettingsModal);
  document.getElementById('btnCloudStatus')?.addEventListener('click', () => {
    openSettingsModal();
    // Switch to Cloud tab
    document.querySelector('.tab-nav[data-tab="tabCloud"]')?.click();
  });

  // Context Menu Handlers (Dial)
  document.getElementById('ctxOpenNewTab')?.addEventListener('click', () => {
    if (targetDial) chrome.tabs.create({ url: targetDial.url, active: true });
    closeContextMenus();
  });

  document.getElementById('ctxOpenBgTab')?.addEventListener('click', () => {
    if (targetDial) chrome.tabs.create({ url: targetDial.url, active: false });
    closeContextMenus();
  });

  document.getElementById('ctxCaptureDialScreenshot')?.addEventListener('click', async () => {
    const dial = targetDial;
    closeContextMenus();
    if (dial) {
      await captureSingleDialScreenshot(dial);
    }
  });

  document.getElementById('ctxSetDialToIcon')?.addEventListener('click', async () => {
    const dial = targetDial;
    closeContextMenus();
    if (dial) {
      dial.tileType = 'logo';
      dial.type = 'gen';
      dial.screenshotUrl = '';
      dial.imgUrl = '';
      await storage.updateDial(dial);
      state = await storage.getState();
      renderDials();
      showToast(getLanguage() === 'ru' ? '✓ Для плитки установлен режим «Иконка»' : '✓ Tile set to "Icon" mode');
    }
  });

  document.getElementById('ctxEditDial')?.addEventListener('click', () => {
    if (targetDial) openDialModal(targetDial);
    closeContextMenus();
  });

  document.getElementById('ctxTogglePinDial')?.addEventListener('click', async () => {
    if (targetDial) {
      const isPinned = await storage.togglePinDial(targetDial.id);
      state = await storage.getState();
      renderDials();
      showToast(isPinned ? t('toastDialPinned') : t('toastDialUnpinned'), '🔒');
    }
    closeContextMenus();
  });

  document.getElementById('ctxDeleteDial')?.addEventListener('click', async () => {
    if (targetDial && confirm(t('confirmDeleteDial', { name: targetDial.name }))) {
      await storage.deleteDial(targetDial.id);
      showToast(t('toastDialDeleted'));
    }
    closeContextMenus();
  });

  // Context Menu Handlers (Folder)
  document.getElementById('ctxEditFolder')?.addEventListener('click', () => {
    if (targetFolder) openFolderModal(targetFolder);
    closeContextMenus();
  });

  document.getElementById('ctxOpenAllTabs')?.addEventListener('click', () => {
    if (targetFolder) {
      const urls = (targetFolder.dialIds || []).map(id => state.dials.byId[id]?.url).filter(Boolean);
      urls.forEach(url => chrome.tabs.create({ url, active: false }));
    }
    closeContextMenus();
  });

  document.getElementById('ctxOpenAllWindow')?.addEventListener('click', () => {
    if (targetFolder) {
      const urls = (targetFolder.dialIds || []).map(id => state.dials.byId[id]?.url).filter(Boolean);
      if (urls.length > 0) {
        chrome.windows.create({ url: urls[0] }, (win) => {
          for (let i = 1; i < urls.length; i++) {
            chrome.tabs.create({ windowId: win.id, url: urls[i], active: false });
          }
        });
      }
    }
    closeContextMenus();
  });

  document.getElementById('ctxDeleteFolder')?.addEventListener('click', async () => {
    if (targetFolder) {
      if (state.folders.ids.length <= 1) {
        alert(t('alertCannotDeleteOnlyDesk'));
        return;
      }
      if (confirm(t('confirmDeleteDesk', { name: targetFolder.name }))) {
        await storage.deleteFolder(targetFolder.id);
        showToast(t('toastDeskDeleted'));
      }
    }
    closeContextMenus();
  });

  // Modal Close Buttons
  document.querySelectorAll('[data-close]').forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.dataset.close;
      document.getElementById(targetId)?.classList.add('hidden');
    });
  });

  // Save Dial Modal
  document.getElementById('modalBtnSaveDial')?.addEventListener('click', async () => {
    const defaultName = getLanguage() === 'ru' ? 'Сайт' : 'Website';
    const name = document.getElementById('modalDialName').value.trim() || defaultName;
    const rawUrl = document.getElementById('modalDialUrl').value.trim();
    if (isInternalOrNewTabUrl(rawUrl)) {
      alert(t('alertInvalidUrl'));
      return;
    }
    const url = sanitizeUrl(rawUrl);
    if (!url || isInternalOrNewTabUrl(url)) {
      alert(t('alertInvalidUrl'));
      return;
    }

    const folderId = document.getElementById('modalDialFolder').value;
    const groupId = document.getElementById('modalDialGroup')?.value || '';
    const customColor = document.getElementById('modalCustomColor').value || '#2d2d2d';
    const screenshotUrl = modalCurrentScreenshot;
    const logoUrl = document.getElementById('modalLogoUrl')?.value.trim() || '';

    const existingDial = editingDialId ? state.dials.byId[editingDialId] : null;
    const noFavicon = isKnownBadFavicon(url);
    const dialData = {
      id: editingDialId,
      folderId,
      groupId,
      name,
      url,
      tileType: modalCurrentTileType,
      screenshotUrl,
      logoUrl,
      bgcolor: customColor,
      textColor: getContrastTextColor(customColor),
      type: modalCurrentTileType === 'screenshot' && screenshotUrl ? 'image' : 'gen',
      imgUrl: modalCurrentTileType === 'screenshot' ? screenshotUrl : '',
      faviconUrl: noFavicon ? '' : getFaviconUrl(url),
      noFavicon,
      showFaviconOnThumb: true,
      showText: true,
      isWide: existingDial ? Boolean(existingDial.isWide) : false,
      isRow: existingDial ? Boolean(existingDial.isRow) : false,
      isPinned: existingDial ? Boolean(existingDial.isPinned) : false
    };

    if (editingDialId) {
      await storage.updateDial(dialData);
      showToast(t('toastDialUpdated'));
    } else {
      await storage.addDial(dialData);
      showToast(t('toastDialAdded', { name }));
    }

    document.getElementById('dialModal')?.classList.add('hidden');
  });

  // Live Dial Modal inputs
  ['modalDialName', 'modalDialUrl', 'modalCustomColor', 'modalScreenshotUrl', 'modalLogoUrl'].forEach(id => {
    document.getElementById(id)?.addEventListener('input', (e) => {
      if (id === 'modalScreenshotUrl') {
        modalCurrentScreenshot = e.target.value.trim();
      }
      if (id === 'modalDialUrl' || id === 'modalDialName') {
        const u = document.getElementById('modalDialUrl')?.value?.trim() || '';
        const n = document.getElementById('modalDialName')?.value?.trim() || '';
        const brand = getBrandColorForUrl(u, n);
        if (brand) {
          const colorInput = document.getElementById('modalCustomColor');
          if (colorInput) colorInput.value = brand.bgcolor;
          document.querySelectorAll('#modalColorPalette .color-swatch').forEach(swatch => {
            swatch.classList.toggle('active', swatch.dataset.color.toLowerCase() === brand.bgcolor.toLowerCase());
          });
        } else if (u && id === 'modalDialUrl') {
          const fav = getFaviconUrl(u);
          if (fav) {
            extractDominantColorFromImage(fav).then(domColor => {
              if (domColor) {
                const colorInput = document.getElementById('modalCustomColor');
                if (colorInput) {
                  colorInput.value = domColor;
                  updateModalDialPreview();
                }
              }
            });
          }
        }
      }
      updateModalDialPreview();
    });
  });

  // Logo File Upload & Clear
  document.getElementById('modalLogoFile')?.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        const logoInput = document.getElementById('modalLogoUrl');
        if (logoInput) logoInput.value = ev.target.result;
        updateModalDialPreview();
      };
      reader.readAsDataURL(file);
    }
  });

  document.getElementById('modalBtnClearLogo')?.addEventListener('click', () => {
    const logoInput = document.getElementById('modalLogoUrl');
    const logoFile = document.getElementById('modalLogoFile');
    if (logoInput) logoInput.value = '';
    if (logoFile) logoFile.value = '';
    updateModalDialPreview();
  });

  // Screenshot File Upload
  document.getElementById('modalScreenshotFile')?.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = async (ev) => {
        modalCurrentScreenshot = await resizeScreenshot(ev.target.result, 560, 420);
        const urlInput = document.getElementById('modalScreenshotUrl');
        if (urlInput) urlInput.value = modalCurrentScreenshot;
        updateModalDialPreview();
      };
      reader.readAsDataURL(file);
    }
  });

  // Single screenshot capture inside dial edit modal
  document.getElementById('modalBtnTakeScreenshot')?.addEventListener('click', async () => {
    const rawUrl = document.getElementById('modalDialUrl')?.value?.trim();
    if (isInternalOrNewTabUrl(rawUrl)) {
      alert('Нельзя сделать скриншот страницы Экспресс-панели');
      return;
    }
    const url = sanitizeUrl(rawUrl);
    if (!url || isInternalOrNewTabUrl(url)) {
      alert(getLanguage() === 'ru' ? 'Сначала введите адрес (URL) сайта' : 'Please enter website URL first');
      return;
    }
    const btn = document.getElementById('modalBtnTakeScreenshot');
    if (btn) btn.disabled = true;
    showToast(getLanguage() === 'ru' ? 'Делаем снимок сайта...' : 'Capturing screenshot...');
    let win = null;
    try {
      win = await new Promise(r => {
        chrome.windows.create({ url, type: 'popup', width: 1024, height: 768, focused: true }, r);
      });
      if (win && win.id) {
        const tabs = await new Promise(r => chrome.tabs.query({ windowId: win.id }, r));
        const tabId = tabs && tabs[0] ? tabs[0].id : null;
        await waitForFirstTabLoad(tabId, 6000);
        await new Promise(r => setTimeout(r, 600));
        const dataUrl = await captureTabScreenshot(win.id);
        if (dataUrl) {
          modalCurrentScreenshot = await resizeScreenshot(dataUrl, 560, 420);
          const urlInput = document.getElementById('modalScreenshotUrl');
          if (urlInput) urlInput.value = modalCurrentScreenshot;
          modalCurrentTileType = 'screenshot';
          document.querySelectorAll('#modalTileTypeControl .segment-btn').forEach(b => {
            b.classList.toggle('active', b.dataset.type === 'screenshot');
          });
          updateModalDialPreview();
          showToast(getLanguage() === 'ru' ? '✓ Снимок успешно получен!' : '✓ Screenshot captured!');
        } else {
          showToast(getLanguage() === 'ru' ? 'Не удалось сделать снимок' : 'Could not capture screenshot');
        }
      }
    } catch (err) {
      console.warn('Error taking single screenshot:', err);
      showToast(getLanguage() === 'ru' ? 'Ошибка при создании снимка' : 'Error capturing screenshot');
    } finally {
      if (win && win.id) {
        try { chrome.windows.remove(win.id); } catch (e) {}
      }
      if (btn) btn.disabled = false;
    }
  });

  // Tile Type switch (Screenshot vs Logo)
  document.querySelectorAll('#modalTileTypeControl .segment-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('#modalTileTypeControl .segment-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      modalCurrentTileType = btn.dataset.type;
      updateModalDialPreview();
    });
  });

  // Color Swatches
  document.querySelectorAll('#modalColorPalette .color-swatch').forEach(swatch => {
    swatch.addEventListener('click', () => {
      document.querySelectorAll('#modalColorPalette .color-swatch').forEach(s => s.classList.remove('active'));
      swatch.classList.add('active');
      document.getElementById('modalCustomColor').value = swatch.dataset.color;
      updateModalDialPreview();
    });
  });

  // Save Desktop Modal
  document.getElementById('modalBtnSaveDesktop')?.addEventListener('click', async () => {
    const defaultDeskName = getLanguage() === 'ru' ? 'Новый стол' : 'New Desktop';
    const name = document.getElementById('modalFolderName').value.trim() || defaultDeskName;
    const activeIconEl = document.querySelector('.icon-picker-item.active');
    const icon = activeIconEl ? activeIconEl.dataset.icon : 'folder';

    if (editingFolderId) {
      await storage.updateFolder(editingFolderId, { name, icon });
      showToast(t('toastDeskUpdated'));
    } else {
      await storage.addFolder(name, icon);
      showToast(t('toastDeskCreated'));
      setTimeout(() => {
        const list = document.getElementById('desktopList');
        if (list) list.scrollTop = list.scrollHeight;
      }, 50);
    }

    document.getElementById('folderModal')?.classList.add('hidden');
  });

  // Save Group Modal
  document.getElementById('modalBtnSaveGroup')?.addEventListener('click', async () => {
    const defaultGroupName = getLanguage() === 'ru' ? 'Новая группа' : 'New Group';
    const input = document.getElementById('modalGroupName');
    const name = input ? input.value.trim() || defaultGroupName : defaultGroupName;
    const activeSwatch = document.querySelector('#groupColorPalette .color-swatch.active');
    const color = activeSwatch ? activeSwatch.dataset.color : '#0078d7';

    if (editingGroupId) {
      await storage.updateGroup(editingGroupFolderId, editingGroupId, { name, color });
      showToast(t('toastGroupUpdated'));
    } else {
      await storage.addGroup(editingGroupFolderId, { name, color });
      showToast(t('toastGroupCreated'));
    }

    document.getElementById('groupModal')?.classList.add('hidden');
    renderDials();
  });

  // Group Color Swatches
  document.querySelectorAll('#groupColorPalette .color-swatch').forEach(swatch => {
    swatch.addEventListener('click', () => {
      document.querySelectorAll('#groupColorPalette .color-swatch').forEach(s => s.classList.remove('active'));
      swatch.classList.add('active');
    });
  });

  // Group Context Menu Handlers
  document.getElementById('ctxEditGroup')?.addEventListener('click', () => {
    if (targetGroup) openGroupModal(targetGroup, targetGroupFolderId);
    closeContextMenus();
  });

  document.getElementById('ctxAddDialToGroup')?.addEventListener('click', () => {
    if (targetGroup) openDialModal(null, targetGroup.id);
    closeContextMenus();
  });

  document.getElementById('ctxDeleteGroup')?.addEventListener('click', async () => {
    if (targetGroup && confirm(t('confirmDeleteGroup', { name: targetGroup.name }))) {
      await storage.deleteGroup(targetGroupFolderId, targetGroup.id);
      showToast(t('toastGroupDeleted'));
      renderDials();
    }
    closeContextMenus();
  });



  // Grid Drop Handler
  const dialsGridEl = document.getElementById('dialsGrid');
  if (dialsGridEl) {
    dialsGridEl.addEventListener('dragover', (e) => {
      e.preventDefault();
    });
    dialsGridEl.addEventListener('drop', async (e) => {
      const dragData = e.dataTransfer.getData('text/plain');
      const activeFolder = state.folders.byId[state.activeFolderId];
      if (!activeFolder) return;

      if (dragData.startsWith('dial:')) {
        e.preventDefault();
        const fromDialId = dragData.replace('dial:', '');
        const fromIndex = activeFolder.dialIds.indexOf(fromDialId);
        if (fromIndex !== -1 && fromIndex !== activeFolder.dialIds.length - 1) {
          await storage.moveDialInFolder(activeFolder.id, fromIndex, activeFolder.dialIds.length - 1);
          renderDials();
        }
        return;
      }
    });
  }

  // Widget Settings Modal Handlers
  document.getElementById('btnSaveWidgetSettings')?.addEventListener('click', async () => {
    if (!editingWidgetDial) return;
    const type = editingWidgetDial.widgetType;
    const sizeEl = document.getElementById('wSetSize');
    const size = sizeEl ? sizeEl.value : (editingWidgetDial.widgetSize || '1x1');
    let newConfig = {};

    if (type === 'clock') {
      const tz = document.getElementById('wSetTimezone')?.value || 'auto';
      const showSec = document.getElementById('wSetSeconds')?.checked !== false;
      const is24h = document.getElementById('wSet24h')?.checked !== false;
      const fontSize = document.getElementById('wSetFontSize')?.value || 'normal';
      newConfig = { timezone: tz, showSeconds: showSec, is24Hour: is24h, fontSize };
    } else if (type === 'weather') {
      const cityInput = document.getElementById('wSetCity');
      const feedbackEl = document.getElementById('wCityFeedback');
      const rawCity = cityInput ? cityInput.value.trim() : '';
      if (!rawCity) {
        showToast(t('wCityNotFound'), '⚠️');
        cityInput?.focus();
        return;
      }
      if (feedbackEl && feedbackEl.textContent.includes(t('wCityNotFound'))) {
        showToast(t('wCityNotFound'), '⚠️');
        cityInput?.focus();
        return;
      }
      const city = cityInput?.dataset.validatedCity || rawCity;
      const units = document.getElementById('wSetUnits')?.value || 'c';
      const fontSize = document.getElementById('wSetFontSize')?.value || 'normal';
      newConfig = { city, units, fontSize };
    } else if (type === 'rates') {
      const modal = document.getElementById('widgetSettingsModal');
      const tokens = typeof modal?._currentRateTokens === 'function' ? modal._currentRateTokens() : null;
      const fontSize = document.getElementById('wSetFontSize')?.value || 'normal';
      const baseCurrency = document.getElementById('wSetBaseCurrency')?.value || 'RUB';
      newConfig = { items: (tokens && tokens.length > 0) ? tokens : ['USD', 'EUR', 'BTC'], fontSize, baseCurrency };
    } else if (type === 'note') {
      const activeSwatch = document.querySelector('#wNoteColorPicker .color-swatch.active');
      const color = activeSwatch ? activeSwatch.dataset.color : 'amber';
      const scope = document.getElementById('wSetScope')?.value || 'independent';
      const fontSize = document.getElementById('wSetFontSize')?.value || 'normal';
      const mode = document.getElementById('wSetMode')?.value || 'todos';
      newConfig = { color, syncScope: scope, fontSize, mode };
    }

    const isPinned = document.getElementById('wSetPinned')?.checked;
    await storage.updateWidgetDial(editingWidgetDial.id, newConfig, size, false, isPinned);
    document.getElementById('widgetSettingsModal')?.classList.add('hidden');
    renderDials();
    showToast(t('toastSettingsSaved'), '⚙️');
  });

  document.getElementById('btnDeleteWidget')?.addEventListener('click', async () => {
    if (!editingWidgetDial) return;
    if (confirm(t('confirmDeleteWidget', { name: getWidgetTitle(editingWidgetDial) }))) {
      await storage.deleteDial(editingWidgetDial.id);
      document.getElementById('widgetSettingsModal')?.classList.add('hidden');
      renderDials();
      showToast(t('toastWidgetDeleted'));
    }
  });

  // Quick Add Popover (+ Меню выбора: Сайт или Виджет)
  document.querySelectorAll('#quickAddPopover .add-popover-item').forEach(item => {
    item.addEventListener('click', async (e) => {
      e.stopPropagation();
      document.getElementById('quickAddPopover')?.classList.remove('active');
      const action = item.dataset.action;
      if (action === 'add-site') {
        openDialModal(null, '');
      } else if (action === 'add-widget-clock') {
        await storage.addWidgetDial(state.activeFolderId, 'clock', '1x1');
        renderDials();
        showToast(t('toastWidgetAdded', { name: t('widgetClock') }), '⏰');
      } else if (action === 'add-widget-weather') {
        await storage.addWidgetDial(state.activeFolderId, 'weather', '1x1');
        renderDials();
        showToast(t('toastWidgetAdded', { name: t('widgetWeather') }), '🌤️');
      } else if (action === 'add-widget-rates') {
        await storage.addWidgetDial(state.activeFolderId, 'rates', '1x1');
        renderDials();
        showToast(t('toastWidgetAdded', { name: t('widgetRates') }), '📈');
      } else if (action === 'add-widget-note') {
        await storage.addWidgetDial(state.activeFolderId, 'note', '2x1');
        renderDials();
        showToast(t('toastWidgetAdded', { name: t('widgetNote') }), '📝');
      }
    });
  });

  // Settings Modal Tabs
  document.querySelectorAll('.tab-nav').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab-nav').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
      tab.classList.add('active');
      const target = document.getElementById(tab.dataset.tab);
      if (target) target.classList.add('active');
    });
  });

  // Settings: Language Switcher
  document.querySelectorAll('#languageModeControl .segment-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      document.querySelectorAll('#languageModeControl .segment-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const lang = btn.dataset.lang || 'auto';
      await storage.updateSettings({ language: lang });
      initI18n(lang);
      applyI18n();
      renderDesktops();
      renderDials();
      showToast(t('toastLangChanged'));
    });
  });

  // Settings: Theme Switcher
  document.querySelectorAll('#themeModeControl .segment-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      document.querySelectorAll('#themeModeControl .segment-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const theme = btn.dataset.theme;
      await storage.updateSettings({ theme });
      applySettings();
      renderDials();
      showToast(t('toastThemeChanged'));
    });
  });

  // Settings: Style Switcher (Windows 11 vs Windows 10)
  document.querySelectorAll('#styleModeControl .segment-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      document.querySelectorAll('#styleModeControl .segment-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const style = btn.dataset.style;
      await storage.updateSettings({ style });
      applySettings();
      showToast(t('toastStyleChanged'));
    });
  });

  // Settings: General toggles
  document.getElementById('cfgShowSearchbar')?.addEventListener('change', (e) => {
    const isVisible = e.target.checked;
    try {
      localStorage.setItem('sd_pref_hide_search', isVisible ? '0' : '1');
      if (isVisible) {
        document.documentElement.classList.remove('hide-searchbar-initial');
      } else {
        document.documentElement.classList.add('hide-searchbar-initial');
      }
    } catch (err) {}
    storage.updateSettings({ showSearchbar: isVisible });
  });
  document.getElementById('cfgSearchEngine')?.addEventListener('change', (e) => {
    storage.updateSettings({ searchEngine: e.target.value });
  });
  document.getElementById('cfgOpenInNewTab')?.addEventListener('change', (e) => {
    storage.updateSettings({ openInNewTab: e.target.checked });
  });
  document.getElementById('cfgShowDeskSearch')?.addEventListener('change', (e) => {
    storage.updateSettings({ showDeskSearch: e.target.checked });
    applySettings();
  });

  // Settings: Sliders with live preview
  const sSize = document.getElementById('sliderDialSize');
  const sSp = document.getElementById('sliderDialSpacing');
  const sOp = document.getElementById('sliderOverlayOpacity');

  sSize?.addEventListener('input', (e) => {
    const val = parseInt(e.target.value);
    document.getElementById('valDialSize').textContent = val + 'px';
    storage.updateSettings({ dialSize: val });
  });
  sSp?.addEventListener('input', (e) => {
    const val = parseInt(e.target.value);
    document.getElementById('valDialSpacing').textContent = val + 'px';
    storage.updateSettings({ dialSpacing: val });
  });

  // Settings: Tile Font Size Switcher
  document.querySelectorAll('#tilesFontSizeControl .segment-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      document.querySelectorAll('#tilesFontSizeControl .segment-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const tilesFontSize = btn.dataset.tilesize || 'normal';
      await storage.updateSettings({ tilesFontSize });
      applySettings();
    });
  });

  sOp?.addEventListener('input', (e) => {
    document.getElementById('valOverlayOpacity').textContent = e.target.value + '%';
    const bg = state.settings.background || {};
    storage.updateSettings({
      background: { ...bg, overlayOpacity: parseInt(e.target.value) / 100 }
    });
  });

  // Settings: Background Mode Switcher (Solid Color vs Wallpaper)
  document.querySelectorAll('#bgModeControl .segment-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('#bgModeControl .segment-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const mode = btn.dataset.bgmode;
      const solidSec = document.getElementById('bgSolidColorSection');
      const imgSec = document.getElementById('bgImageSection');

      if (mode === 'color') {
        solidSec?.classList.remove('hidden');
        imgSec?.classList.add('hidden');
      } else {
        solidSec?.classList.add('hidden');
        imgSec?.classList.remove('hidden');
      }

      const bg = state.settings.background || {};
      storage.updateSettings({ background: { ...bg, type: mode } });
      showToast(mode === 'color' ? t('toastBgSolidActive') : t('toastBgWallActive'));
    });
  });

  // Settings: Background Color Swatches
  document.querySelectorAll('#bgColorPalette .color-swatch').forEach(swatch => {
    swatch.addEventListener('click', () => {
      document.querySelectorAll('#bgColorPalette .color-swatch').forEach(s => s.classList.remove('active'));
      swatch.classList.add('active');
      const color = swatch.dataset.color;
      const customColorInput = document.getElementById('cfgBgSolidColor');
      if (customColorInput) customColorInput.value = color;

      const bg = state.settings.background || {};
      storage.updateSettings({ background: { ...bg, type: 'color', color } });
      showToast(t('toastColorChanged'));
    });
  });

  // Settings: Background Custom Color Picker
  document.getElementById('cfgBgSolidColor')?.addEventListener('input', (e) => {
    document.querySelectorAll('#bgColorPalette .color-swatch').forEach(s => s.classList.remove('active'));
    const color = e.target.value;
    const bg = state.settings.background || {};
    storage.updateSettings({ background: { ...bg, type: 'color', color } });
  });

  // Settings: Wallpaper Presets
  document.querySelectorAll('.wp-card').forEach(card => {
    card.addEventListener('click', () => {
      document.querySelectorAll('.wp-card').forEach(c => c.classList.remove('active'));
      card.classList.add('active');
      const url = card.dataset.wp;
      const bg = state.settings.background || {};
      storage.updateSettings({ background: { ...bg, url, type: 'wall' } });
      showToast(t('toastWallpaperUpdated'));
    });
  });

  document.getElementById('btnApplyWallpaperUrl')?.addEventListener('click', () => {
    const url = document.getElementById('cfgCustomWallpaperUrl').value.trim();
    if (url) {
      const bg = state.settings.background || {};
      storage.updateSettings({ background: { ...bg, url } });
      showToast(t('toastWallpaperApplied'));
    }
  });

  document.getElementById('fileWallpaperUpload')?.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        const bg = state.settings.background || {};
        storage.updateSettings({ background: { ...bg, url: ev.target.result } });
        showToast(t('toastCustomWallpaperLoaded'));
      };
      reader.readAsDataURL(file);
    }
  });

  // Settings: Cloud Sync (Google Drive)
  document.getElementById('cfgGdriveClientId')?.addEventListener('change', (e) => {
    const clientId = e.target.value.trim();
    const gd = state.settings.googleDrive || {};
    storage.updateSettings({ googleDrive: { ...gd, clientId } });
  });

  // Force Chrome Storage Sync
  document.getElementById('btnForceChromeSync')?.addEventListener('click', async () => {
    const btn = document.getElementById('btnForceChromeSync');
    const statusInfo = document.getElementById('chromeSyncStatusInfo');
    btn.disabled = true;
    const oldHtml = btn.innerHTML;
    btn.innerHTML = `<svg class="spin-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67M2.5 22v-6h6M2.66 8.43a10 10 0 1 1 .57 8.38l-5.67 5.67"/></svg> Синхронизация...`;
    try {
      const stats = await storage.smartSyncChromeProfile();
      let msg = `✓ Синхронизировано: ${stats.totalFolders} столов, ${stats.totalDials} плиток.`;
      if (stats.addedDials > 0) msg += ` Новых: +${stats.addedDials}.`;
      if (stats.removedDials > 0) msg += ` Удалено: -${stats.removedDials}.`;
      if (stats.preservedScreenshots > 0) msg += ` Скриншоты сохранены (${stats.preservedScreenshots}).`;
      showToast(msg);
      if (statusInfo) {
        statusInfo.textContent = msg + ` (Синхронизировано в ${new Date().toLocaleTimeString()})`;
      }
    } catch (e) {
      showToast((getLanguage() === 'ru' ? 'Ошибка синхронизации: ' : 'Sync error: ') + e.message);
      if (statusInfo) statusInfo.textContent = (getLanguage() === 'ru' ? 'Ошибка: ' : 'Error: ') + e.message;
    } finally {
      btn.innerHTML = oldHtml;
      btn.disabled = false;
    }
  });

  document.getElementById('btnGdriveUpload')?.addEventListener('click', async () => {
    const btn = document.getElementById('btnGdriveUpload');
    btn.disabled = true;
    btn.textContent = t('toastConnectingGdrive');
    try {
      await gdriveSync.uploadBackup(true);
      showToast(t('toastGdriveSuccess'));
      updateGdriveUI(state.settings.googleDrive);
    } catch (err) {
      if (err.message && err.message.includes('Client ID')) {
        alert(
          'Служба Google Диска требует подтверждения от зарегистрированного приложения.\n\n' +
          '• Вариант 1 (Рекомендуемый, работает автоматически):\n' +
          'Используйте верхний блок «Автоматическая синхронизация через Google» — он уже синхронизирует все столы и сайты в ваше облако Google без Client ID!\n\n' +
          '• Вариант 2 (Сохранение отдельного файла на Диск):\n' +
          'Откройте пункт «⚙ Дополнительно» ниже и введите ваш Client ID (создаётся бесплатно в Google Cloud Console).'
        );
      } else {
        alert('Google Drive Error: ' + err.message);
      }
    } finally {
      btn.disabled = false;
      btn.innerHTML = `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path><polyline points="10 17 15 12 10 7"></polyline><line x1="15" y1="12" x2="3" y2="12"></line></svg> ` + t('btnConnectGDrive');
    }
  });

  document.getElementById('btnGdriveDownload')?.addEventListener('click', async () => {
    if (!confirm(t('confirmGdriveRestore'))) return;
    const btn = document.getElementById('btnGdriveDownload');
    btn.disabled = true;
    btn.textContent = t('toastRestoringGdrive');
    try {
      await gdriveSync.downloadBackup(true);
      showToast(t('toastGdriveRestored'));
      updateGdriveUI(state.settings.googleDrive);
    } catch (err) {
      alert('Google Drive Error: ' + err.message);
    } finally {
      btn.disabled = false;
      btn.innerHTML = `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg> ` + (getLanguage() === 'ru' ? 'Восстановить из Google Диска' : 'Restore from Google Drive');
    }
  });

  // Settings: File Export / Import
  document.getElementById('btnExportBackup')?.addEventListener('click', () => {
    const backup = storage.exportBackup();
    downloadJsonFile(backup, 'SpeedDial_Backup.json');
    showToast(t('toastBackupDownloaded'));
  });

  const fileImportInput = document.getElementById('fileBackupImport');
  document.getElementById('btnTriggerImport')?.addEventListener('click', () => {
    fileImportInput?.click();
  });

  fileImportInput?.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (file) {
      try {
        const data = await readJsonFile(file);
        await storage.importBackup(data);
        showToast(t('toastBackupImported'));
      } catch (err) {
        alert((getLanguage() === 'ru' ? 'Ошибка импорта: ' : 'Import error: ') + err.message);
      }
      fileImportInput.value = '';
    }
  });
}

// ========================================================
// DESK SEARCH / FILTER
// ========================================================
function filterDeskDials() {
  const searchInput = document.getElementById('deskSearchInput');
  const clearBtn = document.getElementById('deskSearchClearBtn');
  const badge = document.getElementById('deskSearchMatchBadge');
  if (!searchInput) return;

  const query = searchInput.value.trim().toLowerCase();
  const cards = document.querySelectorAll('.dial-card');

  if (!query) {
    cards.forEach(c => {
      c.classList.remove('search-match', 'search-dimmed');
    });
    if (badge) badge.classList.add('hidden');
    if (clearBtn) clearBtn.classList.add('hidden');
    return;
  }

  if (clearBtn) clearBtn.classList.remove('hidden');

  let matchCount = 0;
  cards.forEach(card => {
    const dialId = card.dataset.dialId;
    const dial = state?.dials?.byId[dialId];
    if (!dial) return;

    const widgetTitle = dial.type === 'widget' ? getWidgetTitle(dial) : '';
    const nameMatch = (dial.name || '').toLowerCase().includes(query) || widgetTitle.toLowerCase().includes(query);
    const urlMatch = (dial.url || '').toLowerCase().includes(query);
    const domainMatch = (extractDomain(dial.url) || '').toLowerCase().includes(query);

    if (nameMatch || urlMatch || domainMatch) {
      card.classList.add('search-match');
      card.classList.remove('search-dimmed');
      matchCount++;

      const section = card.closest('.desk-group-section');
      if (section && section.classList.contains('desk-group-collapsed')) {
        section.classList.remove('desk-group-collapsed');
      }
    } else {
      card.classList.remove('search-match');
      card.classList.add('search-dimmed');
    }
  });

  if (badge) {
    badge.textContent = matchCount;
    badge.classList.remove('hidden');
  }
}

function initDeskSearch() {
  const searchInput = document.getElementById('deskSearchInput');
  const clearBtn = document.getElementById('deskSearchClearBtn');
  if (!searchInput) return;

  searchInput.addEventListener('input', filterDeskDials);

  clearBtn?.addEventListener('click', () => {
    searchInput.value = '';
    filterDeskDials();
    searchInput.focus();
  });

  searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      searchInput.value = '';
      filterDeskDials();
    }
  });

  // Global shortcut: Ctrl+F / Cmd+F to focus desktop filter, and Escape to close calendar
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeClockCalendar();
    }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'f') {
      const activeEl = document.activeElement;
      if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA') && activeEl !== searchInput) {
        return;
      }
      e.preventDefault();
      searchInput.focus();
      searchInput.select();
    }
  });

  // Calendar Flyout Controls
  document.getElementById('btnCalPrevMonth')?.addEventListener('click', (e) => {
    e.stopPropagation();
    calendarViewDate.setMonth(calendarViewDate.getMonth() - 1);
    renderClockCalendar();
  });

  document.getElementById('btnCalNextMonth')?.addEventListener('click', (e) => {
    e.stopPropagation();
    calendarViewDate.setMonth(calendarViewDate.getMonth() + 1);
    renderClockCalendar();
  });

  document.getElementById('btnCalToday')?.addEventListener('click', (e) => {
    e.stopPropagation();
    let d = new Date();
    if (calendarTargetTimezone && calendarTargetTimezone !== 'auto') {
      try {
        d = new Date(d.toLocaleString('en-US', { timeZone: calendarTargetTimezone }));
      } catch (err) {}
    }
    calendarViewDate = new Date(d);
    renderClockCalendar();
  });

  window.addEventListener('resize', closeClockCalendar);
  window.addEventListener('scroll', closeClockCalendar, true);
}

// ========================================================
// ========================================================
// NOTEPAD REFRESH / SYNC
// ========================================================
function renderNotepad() {
  // Note widgets manage their own state and render during renderDials()
}

// ========================================================
// LIVE DATA HELPERS FOR TILE WIDGETS (WEATHER & RATES)
// ========================================================
const WMO_CODES = {
  0: { descRu: 'Ясно', descEn: 'Clear', icon: '☀️' },
  1: { descRu: 'Преимущественно ясно', descEn: 'Mainly clear', icon: '🌤️' },
  2: { descRu: 'Переменная облачность', descEn: 'Partly cloudy', icon: '⛅' },
  3: { descRu: 'Пасмурно', descEn: 'Overcast', icon: '☁️' },
  45: { descRu: 'Туман', descEn: 'Fog', icon: '🌫️' },
  48: { descRu: 'Туман с изморозью', descEn: 'Depositing rime fog', icon: '🌫️' },
  51: { descRu: 'Морось', descEn: 'Drizzle', icon: '🌦️' },
  61: { descRu: 'Небольшой дождь', descEn: 'Slight rain', icon: '🌧️' },
  63: { descRu: 'Умеренный дождь', descEn: 'Moderate rain', icon: '🌧️' },
  65: { descRu: 'Сильный дождь', descEn: 'Heavy rain', icon: '🌧️' },
  71: { descRu: 'Небольшой снегопад', descEn: 'Slight snow', icon: '🌨️' },
  73: { descRu: 'Снегопад', descEn: 'Moderate snow', icon: '🌨️' },
  75: { descRu: 'Сильный снегопад', descEn: 'Heavy snow', icon: '❄️' },
  80: { descRu: 'Ливень', descEn: 'Rain showers', icon: '🌧️' },
  95: { descRu: 'Гроза', descEn: 'Thunderstorm', icon: '⛈️' }
};

const CITY_COORDS = {
  'москва': { lat: 55.75, lon: 37.61 },
  'санкт-петербург': { lat: 59.93, lon: 30.33 },
  'казань': { lat: 55.78, lon: 49.12 },
  'сочи': { lat: 43.60, lon: 39.73 },
  'новосибирск': { lat: 55.03, lon: 82.93 },
  'екатеринбург': { lat: 56.85, lon: 60.61 },
  'нижний новгород': { lat: 56.32, lon: 44.00 },
  'краснодар': { lat: 45.03, lon: 38.97 },
  'самара': { lat: 53.20, lon: 50.15 },
  'уфа': { lat: 54.73, lon: 55.97 },
  'минск': { lat: 53.90, lon: 27.56 },
  'алматы': { lat: 43.25, lon: 76.92 }
};

const weatherCache = {};
async function fetchLiveWeather(city = 'Москва', units = 'c') {
  const normCity = (city || 'Москва').trim().toLowerCase();
  const lang = getLanguage() === 'ru' ? 'ru' : 'en';
  const cacheKey = `${normCity}_${units}_${lang}`;
  const cached = weatherCache[cacheKey];
  if (cached && Date.now() - cached.time < 20 * 60 * 1000) {
    return cached.data;
  }

  let lat = 55.75, lon = 37.61;
  if (CITY_COORDS[normCity]) {
    lat = CITY_COORDS[normCity].lat;
    lon = CITY_COORDS[normCity].lon;
  } else {
    try {
      const geoRes = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=${lang}`);
      if (geoRes.ok) {
        const geoData = await geoRes.json();
        if (geoData.results && geoData.results[0]) {
          lat = geoData.results[0].latitude;
          lon = geoData.results[0].longitude;
        }
      }
    } catch (e) {}
  }

  try {
    const tempUnitParam = units === 'f' ? '&temperature_unit=fahrenheit' : '';
    const res = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true${tempUnitParam}`);
    if (res.ok) {
      const json = await res.json();
      const cur = json.current_weather;
      if (cur) {
        const tempVal = Math.round(cur.temperature);
        const symbol = units === 'f' ? '°F' : '°C';
        const tempStr = (tempVal > 0 ? '+' : '') + tempVal + symbol;
        const codeInfo = WMO_CODES[cur.weathercode];
        const isRu = lang === 'ru';
        const desc = codeInfo ? (isRu ? codeInfo.descRu : codeInfo.descEn) : (isRu ? 'Облачно' : 'Cloudy');
        const icon = codeInfo ? codeInfo.icon : '⛅';
        const result = {
          temp: tempStr,
          icon,
          desc
        };
        weatherCache[cacheKey] = { time: Date.now(), data: result };
        return result;
      }
    }
  } catch (e) {}

  return { temp: units === 'f' ? '+64°F' : '+18°C', icon: '🌤️', desc: lang === 'ru' ? 'Переменная облачность' : 'Partly cloudy' };
}

const BASE_CURRENCIES = [
  { code: 'RUB', nameRu: 'Российский рубль', nameEn: 'Russian Ruble', sym: '₽' },
  { code: 'USD', nameRu: 'Доллар США', nameEn: 'US Dollar', sym: '$' },
  { code: 'EUR', nameRu: 'Евро', nameEn: 'Euro', sym: '€' },
  { code: 'KZT', nameRu: 'Казахстанский тенге', nameEn: 'Kazakhstani Tenge', sym: '₸' },
  { code: 'BYN', nameRu: 'Белорусский рубль', nameEn: 'Belarusian Ruble', sym: 'Br' },
  { code: 'TRY', nameRu: 'Турецкая лира', nameEn: 'Turkish Lira', sym: '₺' },
  { code: 'CNY', nameRu: 'Китайский юань', nameEn: 'Chinese Yuan', sym: '¥' },
  { code: 'UAH', nameRu: 'Украинская гривна', nameEn: 'Ukrainian Hryvnia', sym: '₴' },
  { code: 'GEL', nameRu: 'Грузинский лари', nameEn: 'Georgian Lari', sym: '₾' },
  { code: 'AED', nameRu: 'Дирхам ОАЭ', nameEn: 'UAE Dirham', sym: 'AED' },
  { code: 'GBP', nameRu: 'Британский фунт', nameEn: 'British Pound', sym: '£' },
  { code: 'JPY', nameRu: 'Японская иена', nameEn: 'Japanese Yen', sym: '¥' },
  { code: 'CHF', nameRu: 'Швейцарский франк', nameEn: 'Swiss Franc', sym: 'Fr' },
  { code: 'AMD', nameRu: 'Армянский драм', nameEn: 'Armenian Dram', sym: '֏' },
  { code: 'UZS', nameRu: 'Узбекский сум', nameEn: 'Uzbekistani Som', sym: 'сум' },
  { code: 'CAD', nameRu: 'Канадский доллар', nameEn: 'Canadian Dollar', sym: 'C$' },
  { code: 'AUD', nameRu: 'Австралийский доллар', nameEn: 'Australian Dollar', sym: 'A$' },
  { code: 'PLN', nameRu: 'Польский злотый', nameEn: 'Polish Zloty', sym: 'zł' },
  { code: 'ILS', nameRu: 'Израильский шекель', nameEn: 'Israeli Shekel', sym: '₪' },
  { code: 'INR', nameRu: 'Индийская рупия', nameEn: 'Indian Rupee', sym: '₹' },
  { code: 'BRL', nameRu: 'Бразильский реал', nameEn: 'Brazilian Real', sym: 'R$' }
];

const CURRENCY_SYMBOLS = {
  RUB: '₽',
  USD: '$',
  EUR: '€',
  KZT: '₸',
  BYN: 'Br',
  TRY: '₺',
  CNY: '¥',
  UAH: '₴',
  GBP: '£',
  GEL: '₾',
  AED: 'AED',
  CHF: 'Fr',
  JPY: '¥',
  AMD: '֏',
  UZS: 'сум',
  CAD: 'C$',
  AUD: 'A$',
  PLN: 'zł',
  ILS: '₪',
  INR: '₹',
  BRL: 'R$'
};

function formatCurrencyPrice(price, baseCurrency = 'RUB') {
  const p = parseFloat(price);
  if (isNaN(p)) return '—';

  const base = (baseCurrency || 'RUB').toUpperCase();
  const sym = CURRENCY_SYMBOLS[base] || base;
  const isPrefix = ['$', '€', '£', '¥', 'C$', 'A$'].includes(sym);

  let formattedNum = '';
  if (p >= 100000000) {
    formattedNum = (p / 1000000).toFixed(1) + 'M';
  } else if (p >= 1000) {
    formattedNum = p.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
  } else if (p >= 1) {
    formattedNum = p.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  } else if (p >= 0.001) {
    formattedNum = p.toFixed(4);
  } else {
    formattedNum = p.toFixed(8).replace(/0+$/, '');
  }

  return isPrefix ? `${sym}${formattedNum}` : `${formattedNum} ${sym}`;
}

function formatCryptoPrice(price) {
  return formatCurrencyPrice(price, 'USD');
}

let cbrFiatDataCache = null;
let cbrFiatDataTime = 0;
async function loadCbrFiatRates() {
  const now = Date.now();
  if (cbrFiatDataCache && (now - cbrFiatDataTime < 15 * 60 * 1000)) {
    return cbrFiatDataCache;
  }
  try {
    const res = await fetch('https://www.cbr-xml-daily.ru/daily_json.js');
    if (res.ok) {
      const data = await res.json();
      if (data && data.Valute) {
        cbrFiatDataCache = data.Valute;
        cbrFiatDataTime = now;
        return cbrFiatDataCache;
      }
    }
  } catch (e) {}
  return cbrFiatDataCache || {};
}

async function validateCurrencyOrCrypto(query, baseCurrency = 'RUB') {
  const q = (query || '').trim();
  if (!q) return { found: false };
  const upper = q.toUpperCase();
  const base = (baseCurrency || 'RUB').toUpperCase();

  const valutes = await loadCbrFiatRates();

  const getRubRate = (code) => {
    const isEn = getLanguage() === 'en';
    if (code === 'RUB') return { rate: 1.0, prev: 1.0, name: isEn ? 'Russian Ruble' : 'Российский рубль' };
    if (valutes[code]) {
      const v = valutes[code];
      const rate = v.Value / v.Nominal;
      const prev = (v.Previous || v.Value) / v.Nominal;
      const baseEntry = BASE_CURRENCIES.find(b => b.code === code);
      const name = baseEntry ? (isEn ? baseEntry.nameEn : baseEntry.nameRu) : v.Name;
      return { rate, prev, name };
    }
    return null;
  };

  const baseInfo = getRubRate(base) || { rate: 1.0, prev: 1.0, name: base };
  const baseRate = baseInfo.rate || 1.0;
  const basePrev = baseInfo.prev || 1.0;

  const usdInfo = getRubRate('USD') || { rate: 96.0, prev: 96.0, name: getLanguage() === 'en' ? 'US Dollar' : 'Доллар США' };
  const usdRate = usdInfo.rate || 96.0;
  const usdPrev = usdInfo.prev || 96.0;

  // 1. Check RUB
  if (upper === 'RUB' || q.toLowerCase() === 'рубль' || q.toLowerCase() === 'рубли' || q.toLowerCase() === 'ruble') {
    const curRate = 1.0 / baseRate;
    const prevRate = 1.0 / basePrev;
    const diff = curRate - prevRate;
    const pct = prevRate > 0 ? ((diff / prevRate) * 100).toFixed(1) : '0.0';
    return {
      found: true,
      type: 'fiat',
      code: 'RUB',
      name: getLanguage() === 'en' ? 'Russian Ruble' : 'Российский рубль',
      val: formatCurrencyPrice(curRate, base),
      delta: `${diff >= 0 ? '+' : ''}${pct}%`,
      up: diff >= 0
    };
  }

  // 2. Check CBR Fiat
  if (valutes[upper]) {
    const v = valutes[upper];
    const fiat = getRubRate(upper);
    const curRate = fiat.rate / baseRate;
    const prevRate = fiat.prev / basePrev;
    const diff = curRate - prevRate;
    const pct = prevRate > 0 ? ((diff / prevRate) * 100).toFixed(1) : '0.0';
    return {
      found: true,
      type: 'fiat',
      code: v.CharCode,
      name: fiat.name,
      val: formatCurrencyPrice(curRate, base),
      delta: `${diff >= 0 ? '+' : ''}${pct}%`,
      up: diff >= 0
    };
  }

  // Search by name match in CBR Fiat
  const lowerQ = q.toLowerCase();
  for (const code of Object.keys(valutes)) {
    const v = valutes[code];
    const baseEntry = BASE_CURRENCIES.find(b => b.code === code);
    const matchesName = v.Name.toLowerCase().includes(lowerQ) ||
      (baseEntry && (baseEntry.nameEn.toLowerCase().includes(lowerQ) || baseEntry.nameRu.toLowerCase().includes(lowerQ))) ||
      v.CharCode.toLowerCase() === lowerQ;
    if (matchesName) {
      const fiat = getRubRate(code);
      const curRate = fiat.rate / baseRate;
      const prevRate = fiat.prev / basePrev;
      const diff = curRate - prevRate;
      const pct = prevRate > 0 ? ((diff / prevRate) * 100).toFixed(1) : '0.0';
      return {
        found: true,
        type: 'fiat',
        code: v.CharCode,
        name: fiat.name,
        val: formatCurrencyPrice(curRate, base),
        delta: `${diff >= 0 ? '+' : ''}${pct}%`,
        up: diff >= 0
      };
    }
  }

  // 3. Check Crypto on Binance
  const usdInBase = usdRate / baseRate;
  const usdPrevInBase = usdPrev / basePrev;

  if (upper === 'USDT' || upper === 'USD') {
    const curRate = usdInBase;
    const prevRate = usdPrevInBase;
    const diff = curRate - prevRate;
    const pct = prevRate > 0 ? ((diff / prevRate) * 100).toFixed(1) : '0.0';
    return {
      found: true,
      type: 'crypto',
      code: upper,
      name: upper === 'USDT' ? 'Tether USD' : 'USD Dollar',
      val: formatCurrencyPrice(curRate, base),
      delta: `${diff >= 0 ? '+' : ''}${pct}%`,
      up: diff >= 0
    };
  }

  try {
    const res = await fetch(`https://api.binance.com/api/v3/ticker/24hr?symbol=${encodeURIComponent(upper + 'USDT')}`);
    if (res.ok) {
      const data = await res.json();
      if (data && data.lastPrice) {
        const lastPrice = parseFloat(data.lastPrice);
        const changePct = parseFloat(data.priceChangePercent || 0);

        const curRate = lastPrice * usdInBase;
        const prevRate = (lastPrice / (1 + changePct / 100)) * usdPrevInBase;
        const diff = curRate - prevRate;
        const netPct = prevRate > 0 ? ((diff / prevRate) * 100).toFixed(1) : changePct.toFixed(1);

        return {
          found: true,
          type: 'crypto',
          code: upper,
          name: upper,
          val: formatCurrencyPrice(curRate, base),
          delta: `${parseFloat(netPct) >= 0 ? '+' : ''}${netPct}%`,
          up: parseFloat(netPct) >= 0
        };
      }
    }
  } catch (e) {}

  return { found: false };
}

let ratesMemoryCache = {}; // `${baseCurrency}_${code}` -> { val, delta, up, name, time }

async function fetchLiveRates(items = ['USD', 'EUR', 'BTC'], baseCurrency = 'RUB') {
  const result = {};
  const base = (baseCurrency || 'RUB').toUpperCase();
  const neededCrypto = [];
  const now = Date.now();

  const valutes = await loadCbrFiatRates();

  const getRubRate = (code) => {
    const isEn = getLanguage() === 'en';
    if (code === 'RUB') return { rate: 1.0, prev: 1.0, name: isEn ? 'Russian Ruble' : 'Российский рубль' };
    if (valutes[code]) {
      const v = valutes[code];
      const rate = v.Value / v.Nominal;
      const prev = (v.Previous || v.Value) / v.Nominal;
      const baseEntry = BASE_CURRENCIES.find(b => b.code === code);
      const name = baseEntry ? (isEn ? baseEntry.nameEn : baseEntry.nameRu) : v.Name;
      return { rate, prev, name };
    }
    return null;
  };

  const baseInfo = getRubRate(base) || { rate: 1.0, prev: 1.0, name: base };
  const baseRate = baseInfo.rate || 1.0;
  const basePrev = baseInfo.prev || 1.0;

  const usdInfo = getRubRate('USD') || { rate: 96.0, prev: 96.0, name: getLanguage() === 'en' ? 'US Dollar' : 'Доллар США' };
  const usdRate = usdInfo.rate || 96.0;
  const usdPrev = usdInfo.prev || 96.0;

  const usdInBase = usdRate / baseRate;
  const usdPrevInBase = usdPrev / basePrev;

  const lang = getLanguage();
  items.forEach(token => {
    const cacheKey = `${base}_${token}_${lang}`;
    const cached = ratesMemoryCache[cacheKey];
    if (cached && (now - cached.time < 5 * 60 * 1000)) {
      result[token] = cached;
      return;
    }

    const fiat = getRubRate(token);
    if (fiat) {
      if (token === base) {
        const item = {
          val: formatCurrencyPrice(1.0, base),
          delta: '0.0%',
          up: true,
          name: fiat.name,
          time: now
        };
        ratesMemoryCache[cacheKey] = item;
        result[token] = item;
      } else {
        const curRate = fiat.rate / baseRate;
        const prevRate = fiat.prev / basePrev;
        const diff = curRate - prevRate;
        const pct = prevRate > 0 ? ((diff / prevRate) * 100).toFixed(1) : '0.0';
        const item = {
          val: formatCurrencyPrice(curRate, base),
          delta: `${diff >= 0 ? '+' : ''}${pct}%`,
          up: diff >= 0,
          name: fiat.name,
          time: now
        };
        ratesMemoryCache[cacheKey] = item;
        result[token] = item;
      }
    } else {
      neededCrypto.push(token);
    }
  });

  // Fetch Crypto from Binance
  if (neededCrypto.length > 0) {
    if (neededCrypto.length === 1) {
      const sym = neededCrypto[0];
      if (sym === 'USDT' || sym === 'USD') {
        const curRate = usdInBase;
        const prevRate = usdPrevInBase;
        const diff = curRate - prevRate;
        const pct = prevRate > 0 ? ((diff / prevRate) * 100).toFixed(1) : '0.0';
        const item = {
          val: formatCurrencyPrice(curRate, base),
          delta: `${diff >= 0 ? '+' : ''}${pct}%`,
          up: diff >= 0,
          name: sym === 'USDT' ? 'Tether USD' : 'USD Dollar',
          time: now
        };
        ratesMemoryCache[`${base}_${sym}_${lang}`] = item;
        result[sym] = item;
      } else {
        try {
          const res = await fetch(`https://api.binance.com/api/v3/ticker/24hr?symbol=${encodeURIComponent(sym + 'USDT')}`);
          if (res.ok) {
            const data = await res.json();
            const lastPrice = parseFloat(data.lastPrice);
            const changePct = parseFloat(data.priceChangePercent || 0);

            const curRate = lastPrice * usdInBase;
            const prevRate = (lastPrice / (1 + changePct / 100)) * usdPrevInBase;
            const diff = curRate - prevRate;
            const netPct = prevRate > 0 ? ((diff / prevRate) * 100).toFixed(1) : changePct.toFixed(1);

            const item = {
              val: formatCurrencyPrice(curRate, base),
              delta: `${parseFloat(netPct) >= 0 ? '+' : ''}${netPct}%`,
              up: parseFloat(netPct) >= 0,
              name: sym,
              time: now
            };
            ratesMemoryCache[`${base}_${sym}_${lang}`] = item;
            result[sym] = item;
          }
        } catch (e) {}
      }
    } else {
      const querySymbols = neededCrypto.filter(s => s !== 'USDT' && s !== 'USD').map(s => s + 'USDT');
      if (neededCrypto.includes('USDT') || neededCrypto.includes('USD')) {
        const sym = neededCrypto.includes('USDT') ? 'USDT' : 'USD';
        const curRate = usdInBase;
        const prevRate = usdPrevInBase;
        const diff = curRate - prevRate;
        const pct = prevRate > 0 ? ((diff / prevRate) * 100).toFixed(1) : '0.0';
        const item = {
          val: formatCurrencyPrice(curRate, base),
          delta: `${diff >= 0 ? '+' : ''}${pct}%`,
          up: diff >= 0,
          name: sym === 'USDT' ? 'Tether USD' : 'USD Dollar',
          time: now
        };
        ratesMemoryCache[`${base}_${sym}_${lang}`] = item;
        result[sym] = item;
      }
      if (querySymbols.length > 0) {
        try {
          const res = await fetch(`https://api.binance.com/api/v3/ticker/24hr?symbols=${encodeURIComponent(JSON.stringify(querySymbols))}`);
          if (res.ok) {
            const arr = await res.json();
            if (Array.isArray(arr)) {
              arr.forEach(data => {
                const sym = data.symbol.replace('USDT', '');
                const lastPrice = parseFloat(data.lastPrice);
                const changePct = parseFloat(data.priceChangePercent || 0);

                const curRate = lastPrice * usdInBase;
                const prevRate = (lastPrice / (1 + changePct / 100)) * usdPrevInBase;
                const diff = curRate - prevRate;
                const netPct = prevRate > 0 ? ((diff / prevRate) * 100).toFixed(1) : changePct.toFixed(1);

                const item = {
                  val: formatCurrencyPrice(curRate, base),
                  delta: `${parseFloat(netPct) >= 0 ? '+' : ''}${netPct}%`,
                  up: parseFloat(netPct) >= 0,
                  name: sym,
                  time: now
                };
                ratesMemoryCache[`${base}_${sym}_${lang}`] = item;
                result[sym] = item;
              });
            }
          }
        } catch (e) {}
      }
    }
  }

  // Fallbacks if network fails or asset not found
  items.forEach(tok => {
    if (!result[tok]) {
      result[tok] = ratesMemoryCache[`${base}_${tok}_${lang}`] || { val: '—', delta: '0%', up: true, name: tok };
    }
  });

  return result;
}

// ========================================================
// TOAST NOTIFICATIONS
// ========================================================
let toastTimeout;
function showToast(message) {
  const toast = document.getElementById('toast');
  if (!toast) return;

  toast.textContent = message;
  toast.classList.remove('hidden');

  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => {
    toast.classList.add('hidden');
  }, 2600);
}
